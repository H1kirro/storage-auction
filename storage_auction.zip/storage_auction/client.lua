local S, Me = nil, { cash = 0, spent = 0, items = 0, best = 0 }
local focused, inspecting, lobbyOpen, resultsOpen = false, false, false, false
local cam, camLocal, camFov = nil, { x = 0.0, y = -2.2 }, 55.0
local LotProps, PropInfo = {}, {}      -- uid -> entity / label
local TarpDraw = {}                    -- uid -> накидка (малюється скриптом)
local Blockers = {}                    -- невидимі стінки навколо лоту
local lotId, shellGz = nil, nil
local autoInspected = {}
local hoverUid = nil
local Npcs, Labels = {}, {}
local blips = { lobby = nil, lot = nil, lotKey = nil, far = nil, farKey = nil }
local travelVeh = nil
local myId = GetPlayerServerId(PlayerId())
local debugOn = false

-- ===== Допоміжне =====
local function ui(action, data) SendNUIMessage({ action = action, data = data }) end

local function toast(msg, t) ui('toast', { msg = msg, type = t or 'info' }) end

local function money(n)
    local s = tostring(math.floor(n or 0))
    s = s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    return '$' .. s
end

local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

local function curLoc()
    if not S or not S.round or S.round < 1 or not S.locIdx or S.locIdx < 1 then return nil end
    return Config.Rounds[S.round].locations[S.locIdx]
end

-- Земля під точкою. Пробуємо знизу (z + 3), щоб НЕ попасти на дах будівлі над нами.
local function groundZ(x, y, z)
    local found, gz = GetGroundZFor_3dCoord(x, y, z + 3.0, false)
    if found and math.abs(gz - z) <= 4.0 then return gz end
    return z
end

local function resolveGz(loc)
    local found, gz = GetGroundZFor_3dCoord(loc.coords.x, loc.coords.y, loc.coords.z + 3.0, false)
    if found and math.abs(gz - loc.coords.z) <= 4.0 then return gz end
    return nil
end

local function Draw3D(coords, text)
    SetDrawOrigin(coords.x, coords.y, coords.z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 230)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function helpText(msg)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

local function openFocus() focused = true SetNuiFocus(true, true) end
local function closeFocus() focused = false SetNuiFocus(false, false) end

local function resolveModel(name, isVeh)
    local list = { name }
    for _, a in ipairs(Config.ModelAlt[name] or {}) do list[#list + 1] = a end
    for _, m in ipairs(list) do
        local h = joaat(m)
        if IsModelInCdimage(h) and (not isVeh or IsModelAVehicle(h)) then return h end
    end
    return joaat(isVeh and 'panto' or 'prop_cs_cardbox_01')
end

-- ===== Іконки на мапі =====
local function makeBlip(x, y, z, B, name, route)
    local b = AddBlipForCoord(x, y, z)
    SetBlipSprite(b, B.sprite)
    SetBlipColour(b, B.colour)
    SetBlipScale(b, B.scale or 1.0)
    SetBlipAsShortRange(b, false)
    if route then SetBlipRoute(b, true) end
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(name)
    EndTextCommandSetBlipName(b)
    return b
end

local function setLobbyBlip(on)
    if on and not blips.lobby then
        local Lb = Config.Lobby
        local b = makeBlip(Lb.coords.x, Lb.coords.y, Lb.coords.z, Config.Blips.lobby, L('blip_lobby'), false)
        SetBlipAsShortRange(b, true)
        blips.lobby = b
    elseif not on and blips.lobby then
        RemoveBlip(blips.lobby)
        blips.lobby = nil
    end
end

local function clearLotBlips()
    if blips.lot then RemoveBlip(blips.lot) blips.lot = nil end
    if blips.lotRadius then RemoveBlip(blips.lotRadius) blips.lotRadius = nil end
    if blips.far then RemoveBlip(blips.far) blips.far = nil end
    blips.lotKey, blips.farKey = nil, nil
end

-- Точка контейнерів (інша іконка, ніж у самої гри) + колекціонер
local function updateBlips()
    local loc = curLoc()
    if not S or not loc or (S.state ~= 'travel' and S.state ~= 'round') then
        if blips.lot then
            clearLotBlips()
            DeleteWaypoint()
        end
        return
    end
    local R = Config.Rounds[S.round]
    local key = ('%d:%d:%s'):format(S.round, S.locIdx, S.state)
    if blips.lotKey ~= key then
        if blips.lot then RemoveBlip(blips.lot) end
        if blips.lotRadius then RemoveBlip(blips.lotRadius) end
        local B = R.bonus and Config.Blips.garage or Config.Blips.lot
        local name = L(R.bonus and 'blip_garage' or 'blip_lot', loc.name)
        blips.lot = makeBlip(loc.coords.x, loc.coords.y, loc.coords.z, B, name, S.state == 'travel')
        if S.state == 'travel' then
            blips.lotRadius = AddBlipForRadius(loc.coords.x, loc.coords.y, loc.coords.z, Config.ArrivalRadius)
            SetBlipColour(blips.lotRadius, B.colour)
            SetBlipAlpha(blips.lotRadius, 110)
            SetNewWaypoint(loc.coords.x, loc.coords.y)
        else
            blips.lotRadius = nil
            DeleteWaypoint()
        end
        blips.lotKey = key
    end
    local fkey = ('%d:%d'):format(S.round, S.locIdx)
    if S.state == 'round' and blips.farKey ~= fkey then
        if blips.far then RemoveBlip(blips.far) end
        local p = GetFarPos(loc)
        blips.far = makeBlip(p.x, p.y, p.z, Config.Blips.far, L('blip_far', S.farName or '', Config.FarBuyerMult), false)
        blips.farKey = fkey
    elseif S.state ~= 'round' and blips.far then
        RemoveBlip(blips.far)
        blips.far, blips.farKey = nil, nil
    end
end

-- ===== NPC =====
local function spawnNpc(key, model, x, y, z, heading, scenario, label)
    if Npcs[key] and DoesEntityExist(Npcs[key]) then return end
    local m = joaat(model)
    if not IsModelInCdimage(m) then m = joaat('a_m_m_business_01') end
    lib.requestModel(m)
    local ped = CreatePed(0, m, x, y, z, heading, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    if scenario then TaskStartScenarioInPlace(ped, scenario, 0, true) end
    FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(m)
    Npcs[key] = ped
    Labels[key] = label
end

local function clearNpc(key)
    if Npcs[key] then
        if DoesEntityExist(Npcs[key]) then DeleteEntity(Npcs[key]) end
        Npcs[key], Labels[key] = nil, nil
    end
end

local function manageNpcs()
    local ppos = GetEntityCoords(cache.ped)
    local loc = curLoc()
    if S and S.state == 'round' and loc and #(ppos - loc.coords) < 160.0 then
        local aw, bw = GetAuctioneerPos(loc), GetBuyerPos(loc)
        spawnNpc('auctioneer', Config.AuctioneerPed, aw.x, aw.y, groundZ(aw.x, aw.y, aw.z), loc.heading + 180.0, 'WORLD_HUMAN_CLIPBOARD', L('npc_auctioneer'))
        spawnNpc('buyer', Config.BuyerPed, bw.x, bw.y, groundZ(bw.x, bw.y, bw.z), loc.heading + 180.0, nil,
            L('npc_buyer', Config.LocalBuyerMult))
        local fp, fh = GetFarPos(loc)
        spawnNpc('far', Config.FarBuyerPed, fp.x, fp.y, groundZ(fp.x, fp.y, fp.z), fh, nil,
            L('npc_far', (S.farName or ''):upper(), Config.FarBuyerMult))
    else
        clearNpc('auctioneer')
        clearNpc('buyer')
        clearNpc('far')
    end
end

-- ===== Пропси лоту =====
local function clearLot()
    for _, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then
            SetEntityAsMissionEntity(ent, true, true)
            DeleteEntity(ent)
        end
    end
    for _, ent in ipairs(Blockers) do
        if DoesEntityExist(ent) then DeleteEntity(ent) end
    end
    LotProps, PropInfo, TarpDraw, Blockers = {}, {}, {}, {}
    hoverUid = nil
    lotId = nil
end

-- Невидимі стінки: усередину лоту зайти не можна.
local function buildBlockers(loc, lot)
    local model
    for _, m in ipairs(Config.BlockerModels) do
        local h = joaat(m)
        if IsModelInCdimage(h) then model = h break end
    end
    if not model then return end
    lib.requestModel(model)
    local mn, mx = GetModelDimensions(model)
    local ex, ey, ez = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
    local longX = ex >= ey
    local len = math.max(ex, ey, 0.4)
    local hgt = math.max(ez, 0.4)
    local cx, cy = (mn.x + mx.x) / 2, (mn.y + mx.y) / 2
    local Wd, Dp, Ht = LotDims(lot.kind, loc)
    local W = Wd / 2
    local layers = math.min(8, math.ceil((Ht + 0.6) / hgt))

    local function wall(x1, y1, x2, y2, alongX)
        local total = math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
        local n = math.max(1, math.ceil(total / (len * 0.92)))
        local heading = loc.heading + ((alongX == longX) and 0.0 or 90.0)
        for i = 1, n do
            local t = (i - 0.5) / n
            local w = LocalToWorld(loc, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
            for k = 0, layers - 1 do
                local z = shellGz - mn.z + k * hgt
                local obj = CreateObject(model, w.x, w.y, z, false, false, false)
                SetEntityHeading(obj, heading)
                local c = GetOffsetFromEntityInWorldCoords(obj, cx, cy, 0.0)
                SetEntityCoordsNoOffset(obj, w.x + (w.x - c.x), w.y + (w.y - c.y), z, false, false, false)
                FreezeEntityPosition(obj, true)
                SetEntityVisible(obj, false, false)
                SetEntityAlpha(obj, 0, false)
                Blockers[#Blockers + 1] = obj
            end
        end
    end

    wall(-W, 0.15, W, 0.15, true)                    -- перед (двері)
    if not loc.existing then
        wall(-W, Dp, W, Dp, true)                    -- задня стінка
        wall(-W, 0.15, -W, Dp, false)                -- ліва
        wall(W, 0.15, W, Dp, false)                  -- права
    end
    SetModelAsNoLongerNeeded(model)
end

local function spawnItem(it, loc)
    local w = LocalToWorld(loc, it.lx, it.ly)
    if it.t == 'tarp' then
        local col = Config.Tarp.colors[it.tc] or Config.Tarp.colors[1]
        TarpDraw[it.uid] = {
            x = w.x, y = w.y, z = shellGz, w = it.tw or 1.0, d = it.td or 1.0, h = it.th or 0.6,
            heading = loc.heading + it.heading, col = col,
        }
        PropInfo[it.uid] = it.label
        return
    end
    if it.t == 'car' then
        local model = resolveModel(it.model, true)
        lib.requestModel(model, 10000)
        local mn = GetModelDimensions(model)
        local veh = CreateVehicle(model, w.x, w.y, shellGz + 1.0, loc.heading + it.heading, false, false)
        SetEntityAsMissionEntity(veh, true, true)
        SetEntityCoordsNoOffset(veh, w.x, w.y, shellGz - mn.z + 0.03, false, false, false)
        SetEntityHeading(veh, loc.heading + it.heading)
        SetVehicleDoorsLocked(veh, 2)
        SetVehicleEngineOn(veh, false, true, true)
        SetVehicleDirtLevel(veh, 11.0)
        SetVehicleNumberPlateText(veh, 'STORAGE')
        SetVehicleUndriveable(veh, true)
        SetEntityInvincible(veh, true)
        FreezeEntityPosition(veh, true)
        SetModelAsNoLongerNeeded(model)
        LotProps[it.uid] = veh
        PropInfo[it.uid] = it.label
        return
    end
    local model = resolveModel(it.model)
    lib.requestModel(model)
    local mn = GetModelDimensions(model)
    local obj = CreateObject(model, w.x, w.y, shellGz - mn.z, false, false, false)
    SetEntityHeading(obj, loc.heading + it.heading)
    FreezeEntityPosition(obj, true)
    SetModelAsNoLongerNeeded(model)
    LotProps[it.uid] = obj
    PropInfo[it.uid] = it.label
end

local function removeProp(uid)
    if TarpDraw[uid] then
        TarpDraw[uid], PropInfo[uid] = nil, nil
        if hoverUid == uid then hoverUid = nil end
        return
    end
    local ent = LotProps[uid]
    LotProps[uid], PropInfo[uid] = nil, nil
    if not ent then return end
    if hoverUid == uid then
        hoverUid = nil
        if DoesEntityExist(ent) then SetEntityDrawOutline(ent, false) end
    end
    CreateThread(function()
        if not DoesEntityExist(ent) then return end
        local c = GetEntityCoords(ent)
        for i = 1, 12 do
            if not DoesEntityExist(ent) then return end
            SetEntityCoordsNoOffset(ent, c.x, c.y, c.z + i * 0.08, false, false, false)
            SetEntityAlpha(ent, 255 - i * 20, false)
            Wait(20)
        end
        SetEntityAsMissionEntity(ent, true, true)
        DeleteEntity(ent)
    end)
end

local SPAWN_DIST, DRAW_DIST = 110.0, 130.0   -- оболонка малюється ДАЛІ, ніж спавняться речі, тож «рентгена» не видно

local function ensureLot()
    local loc = curLoc()
    local lot = S and S.state == 'round' and S.lot or nil
    if not lot or not loc then
        if lotId then clearLot() end
        return
    end
    local dist = #(GetEntityCoords(cache.ped) - loc.coords)
    if dist > 200.0 then
        if lotId then clearLot() end
        return
    end
    if dist > SPAWN_DIST then return end
    RequestCollisionAtCoord(loc.coords.x, loc.coords.y, loc.coords.z)

    if lotId ~= lot.id then
        local gz = resolveGz(loc)
        if not gz then
            if dist > 45.0 then return end      -- чекаємо, поки підвантажиться земля
            gz = loc.coords.z
        end
        clearLot()
        lotId = lot.id
        shellGz = gz
        buildBlockers(loc, lot)
    end
    local want = {}
    for _, it in ipairs(lot.items) do
        want[it.uid] = true
        if not LotProps[it.uid] and not TarpDraw[it.uid] then spawnItem(it, loc) end
    end
    for uid in pairs(LotProps) do
        if not want[uid] then removeProp(uid) end
    end
    for uid in pairs(TarpDraw) do
        if not want[uid] then removeProp(uid) end
    end
end

-- ===== Малювання: оболонка + накидки =====
local function quad(a, b, c, d, col)
    DrawPoly(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z, col[1], col[2], col[3], 255)
    DrawPoly(a.x, a.y, a.z, c.x, c.y, c.z, b.x, b.y, b.z, col[1], col[2], col[3], 255)
    DrawPoly(a.x, a.y, a.z, c.x, c.y, c.z, d.x, d.y, d.z, col[1], col[2], col[3], 255)
    DrawPoly(a.x, a.y, a.z, d.x, d.y, d.z, c.x, c.y, c.z, col[1], col[2], col[3], 255)
end

local function shade(c, f)
    return { clamp(math.floor(c[1] * f), 0, 255), clamp(math.floor(c[2] * f), 0, 255), clamp(math.floor(c[3] * f), 0, 255) }
end

local function drawTarp(t, hot)
    local c = hot and shade(t.col, 1.45) or t.col
    local hw, hd = t.w / 2, t.d / 2
    local tw, td = hw * 0.42, hd * 0.42
    local h = math.rad(t.heading)
    local ch, sh = math.cos(h), math.sin(h)
    local function P(x, y, z) return vec3(t.x + x * ch - y * sh, t.y + x * sh + y * ch, t.z + z) end
    local b1, b2, b3, b4 = P(-hw, -hd, 0.0), P(hw, -hd, 0.0), P(hw, hd, 0.0), P(-hw, hd, 0.0)
    local t1, t2, t3, t4 = P(-tw, -td, t.h), P(tw, -td, t.h), P(tw, td, t.h), P(-tw, td, t.h)
    quad(b1, b2, t2, t1, shade(c, 0.85))
    quad(b2, b3, t3, t2, shade(c, 0.68))
    quad(b3, b4, t4, t3, shade(c, 0.9))
    quad(b4, b1, t1, t4, shade(c, 0.74))
    quad(t1, t2, t3, t4, shade(c, 1.12))
    local f = shade(c, 0.5)
    local m1, m2 = P(0.0, -hd, 0.0), P(0.0, 0.0, t.h)
    DrawLine(m1.x, m1.y, m1.z, m2.x, m2.y, m2.z, f[1], f[2], f[3], 255)
end

local function drawShell(loc, lot)
    local T = Config.LotTypes[lot.kind]
    local Wd, Dp, H = LotDims(lot.kind, loc)
    local W, D = Wd / 2, Dp
    local function P(lx, ly, lz)
        local w = LocalToWorld(loc, lx, ly)
        return vec3(w.x, w.y, shellGz + lz)
    end

    if not loc.existing then
        local oc = T.colors[lot.colorIdx] or T.colors[1]
        local ic = T.interior
        local dark = shade(oc, 0.65)

        -- зовні (різна яскравість граней — об'єм)
        quad(P(-W, 0, 0), P(-W, D, 0), P(-W, D, H), P(-W, 0, H), shade(oc, 0.88))
        quad(P(W, 0, 0), P(W, D, 0), P(W, D, H), P(W, 0, H), oc)
        quad(P(-W, D, 0), P(W, D, 0), P(W, D, H), P(-W, D, H), shade(oc, 0.78))
        quad(P(-W, 0, H), P(W, 0, H), P(W, D, H), P(-W, D, H), shade(oc, 1.12))
        -- внутрішня сторона
        local i = 0.08
        quad(P(-W + i, 0, 0.04), P(-W + i, D - i, 0.04), P(-W + i, D - i, H - i), P(-W + i, 0, H - i), ic)
        quad(P(W - i, 0, 0.04), P(W - i, D - i, 0.04), P(W - i, D - i, H - i), P(W - i, 0, H - i), shade(ic, 0.95))
        quad(P(-W + i, D - i, 0.04), P(W - i, D - i, 0.04), P(W - i, D - i, H - i), P(-W + i, D - i, H - i), shade(ic, 0.85))
        quad(P(-W + i, 0, H - i), P(W - i, 0, H - i), P(W - i, D - i, H - i), P(-W + i, D - i, H - i), shade(ic, 1.1))
        quad(P(-W + i, 0, 0.04), P(W - i, 0, 0.04), P(W - i, D - i, 0.04), P(-W + i, D - i, 0.04), shade(ic, 0.62))

        -- рама спереду
        if T.posts then
            quad(P(-W, -0.01, 0), P(-W + 0.16, -0.01, 0), P(-W + 0.16, -0.01, H), P(-W, -0.01, H), dark)
            quad(P(W - 0.16, -0.01, 0), P(W, -0.01, 0), P(W, -0.01, H), P(W - 0.16, -0.01, H), dark)
            quad(P(-W, -0.01, H - 0.2), P(W, -0.01, H - 0.2), P(W, -0.01, H), P(-W, -0.01, H), dark)
            quad(P(-W, -0.01, 0), P(W, -0.01, 0), P(W, -0.01, 0.1), P(-W, -0.01, 0.1), dark)
        else
            quad(P(-W, -0.01, H - 0.3), P(W, -0.01, H - 0.3), P(W, -0.01, H), P(-W, -0.01, H), dark)
        end
        -- смуги / «логотип» на бортах
        if T.band then
            local lo = shade(oc, 0.7)
            local logo = shade(oc, 1.35)
            quad(P(-W - 0.012, 0.2, 0.0), P(-W - 0.012, D - 0.2, 0.0), P(-W - 0.012, D - 0.2, 0.3), P(-W - 0.012, 0.2, 0.3), lo)
            quad(P(W + 0.012, 0.2, 0.0), P(W + 0.012, D - 0.2, 0.0), P(W + 0.012, D - 0.2, 0.3), P(W + 0.012, 0.2, 0.3), lo)
            quad(P(W + 0.012, D * 0.3, H * 0.4), P(W + 0.012, D * 0.7, H * 0.4), P(W + 0.012, D * 0.7, H * 0.75), P(W + 0.012, D * 0.3, H * 0.75), logo)
            quad(P(-W - 0.012, D * 0.3, H * 0.4), P(-W - 0.012, D * 0.7, H * 0.4), P(-W - 0.012, D * 0.7, H * 0.75), P(-W - 0.012, D * 0.3, H * 0.75), shade(oc, 1.2))
        end
        -- відкриті стулки дверей
        if T.doors then
            quad(P(-W, 0, 0), P(-W, 0, H), P(-W - 0.5, -1.15, H), P(-W - 0.5, -1.15, 0), oc)
            quad(P(W, 0, 0), P(W, 0, H), P(W + 0.5, -1.15, H), P(W + 0.5, -1.15, 0), oc)
            local a, b = P(-W - 0.25, -0.58, 0.2), P(-W - 0.25, -0.58, H - 0.2)
            DrawLine(a.x, a.y, a.z, b.x, b.y, b.z, dark[1], dark[2], dark[3], 255)
            local c, d = P(W + 0.25, -0.58, 0.2), P(W + 0.25, -0.58, H - 0.2)
            DrawLine(c.x, c.y, c.z, d.x, d.y, d.z, dark[1], dark[2], dark[3], 255)
        end
        -- гофра
        if T.ribs then
            local y = 0.4
            while y < D - 0.2 do
                local a, b = P(-W - 0.02, y, 0.05), P(-W - 0.02, y, H - 0.05)
                DrawLine(a.x, a.y, a.z, b.x, b.y, b.z, dark[1], dark[2], dark[3], 255)
                local c, d = P(W + 0.02, y, 0.05), P(W + 0.02, y, H - 0.05)
                DrawLine(c.x, c.y, c.z, d.x, d.y, d.z, dark[1], dark[2], dark[3], 255)
                y = y + 0.4
            end
        end
        for n = 1, T.lights do
            local p = P(0, D * n / (T.lights + 1), H - 0.3)
            DrawLightWithRange(p.x, p.y, p.z, 255, 235, 200, T.lightRange, 6.0)
        end
    else
        -- гараж, що вже є на мапі: лише підсвічуємо вміст
        for n = 1, T.lights do
            local p = P(0, D * n / (T.lights + 1), H - 0.3)
            DrawLightWithRange(p.x, p.y, p.z, 255, 235, 200, T.lightRange, 5.0)
        end
    end

    for uid, t in pairs(TarpDraw) do drawTarp(t, hoverUid == uid) end

    Draw3D(P(0, -0.3, H + 0.6), L('lot_label', S.lotIdx, S.lotCount, T.label:upper()))
end

CreateThread(function()
    while true do
        local lot = S and S.state == 'round' and S.lot or nil
        local loc = curLoc()
        if lot and loc and shellGz and lotId == lot.id and #(GetEntityCoords(cache.ped) - loc.coords) < DRAW_DIST then
            drawShell(loc, lot)
            Wait(0)
        else
            Wait(300)
        end
    end
end)

-- підписи NPC
CreateThread(function()
    while true do
        local any = false
        local ppos = GetEntityCoords(cache.ped)
        for key, ped in pairs(Npcs) do
            if Labels[key] and DoesEntityExist(ped) then
                local pc = GetEntityCoords(ped)
                if #(ppos - pc) < 14.0 then
                    any = true
                    Draw3D(pc + vec3(0.0, 0.0, 1.15), Labels[key])
                end
            end
        end
        Wait(any and 0 or 300)
    end
end)

-- ===== Машина для поїздки (швидка) =====
RegisterNetEvent('storage:spawnCar', function(modelName)
    if not Config.SpawnTravelVehicle then return end
    CreateThread(function()
        local model = joaat(modelName)
        if not IsModelInCdimage(model) or not IsModelAVehicle(model) then return end
        lib.requestModel(model, 10000)

        if travelVeh and DoesEntityExist(travelVeh) then
            SetEntityAsMissionEntity(travelVeh, true, true)
            DeleteVehicle(travelVeh)
        end
        local ped = PlayerPedId()
        local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 5.0, 0.0)
        local spawn, heading = pos, GetEntityHeading(ped)
        local ok, node, nodeH = GetClosestVehicleNodeWithHeading(pos.x, pos.y, pos.z, 1, 3.0, 0)
        if ok and #(node - pos) < 30.0 then spawn, heading = node, nodeH end

        local veh = CreateVehicle(model, spawn.x, spawn.y, spawn.z, heading, true, false)
        SetEntityAsMissionEntity(veh, true, true)
        SetVehicleOnGroundProperly(veh)
        SetVehicleDirtLevel(veh, 8.0)
        SetVehicleNumberPlateText(veh, ('WARS%03d'):format(math.random(0, 999)))
        if Config.CarPower and Config.CarPower > 0 then SetVehicleEnginePowerMultiplier(veh, Config.CarPower) end
        if Config.CarTorque and Config.CarTorque > 1.0 then SetVehicleEngineTorqueMultiplier(veh, Config.CarTorque) end
        TaskWarpPedIntoVehicle(ped, veh, -1)
        SetModelAsNoLongerNeeded(model)
        travelVeh = veh
        if Config.OnTravelVehicle then Config.OnTravelVehicle(veh, GetVehicleNumberPlateText(veh)) end
        toast(L('car_ready'), 'success')
    end)
end)

-- ===== Режим огляду (переможець розбирає лот) =====
local function updateCam()
    local loc, lot = curLoc(), S and S.lot
    if not cam or not loc or not lot then return end
    local Wd, Dp = LotDims(lot.kind, loc)
    camLocal.x = clamp(camLocal.x, -Wd / 2 + 0.3, Wd / 2 - 0.3)
    camLocal.y = clamp(camLocal.y, -4.0, Dp * 0.7)
    local w = LocalToWorld(loc, camLocal.x, camLocal.y)
    SetCamCoord(cam, w.x, w.y, (shellGz or w.z) + 1.55)
    SetCamRot(cam, -12.0, 0.0, loc.heading + 0.0, 2)
    SetCamFov(cam, camFov)
end

local function setHover(uid)
    if hoverUid == uid then return end
    local old = hoverUid and LotProps[hoverUid]
    if old and DoesEntityExist(old) then SetEntityDrawOutline(old, false) end
    hoverUid = uid
    local ent = uid and LotProps[uid]
    if ent and DoesEntityExist(ent) then
        SetEntityDrawOutlineColor(255, 183, 3, 255)
        SetEntityDrawOutline(ent, true)
    end
end

local function startInspect()
    if inspecting then return end
    inspecting = true
    FreezeEntityPosition(PlayerPedId(), true)
    cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    camLocal, camFov = { x = 0.0, y = -2.2 }, 55.0
    updateCam()
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 800, true, true)
    openFocus()
    ui('inspect', { on = true })
end

local function stopInspect()
    if not inspecting then return end
    inspecting = false
    setHover(nil)
    RenderScriptCams(false, true, 600, true, true)
    local c = cam
    cam = nil
    CreateThread(function()
        Wait(700)
        if c then DestroyCam(c, false) end
    end)
    FreezeEntityPosition(PlayerPedId(), false)
    closeFocus()
    ui('inspect', { on = false })
end

-- Вибір курсором: найближчий предмет/накидка, чия проєкційна сфера містить курсор.
local function pickAt(nx, ny)
    if not cam then return nil end
    local w, h = GetActiveScreenResolution()
    local camPos = GetCamCoord(cam)
    local yaw = math.rad(GetCamRot(cam, 2).z)
    local right = vec3(math.cos(yaw), math.sin(yaw), 0.0)
    local best, bd = nil, 1e9

    local function test(uid, c, r)
        local on, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
        if not on then return end
        local on2, sx2 = GetScreenCoordFromWorldCoord(c.x + right.x * r, c.y + right.y * r, c.z)
        local rpx = on2 and math.abs(sx2 - sx) * w or 40.0
        local dx, dy = (nx - sx) * w, (ny - sy) * h
        if dx * dx + dy * dy <= rpx * rpx then
            local d = #(c - camPos)
            if d < bd then best, bd = uid, d end
        end
    end

    for uid, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then
            local mn, mx = GetModelDimensions(GetEntityModel(ent))
            local size = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z)
            local c = GetOffsetFromEntityInWorldCoords(ent, (mn.x + mx.x) / 2, (mn.y + mx.y) / 2, (mn.z + mx.z) / 2)
            test(uid, c, size * 0.5 * 0.75)
        end
    end
    for uid, t in pairs(TarpDraw) do
        test(uid, vec3(t.x, t.y, t.z + t.h * 0.4), math.max(t.w, t.d) * 0.55)
    end
    return best
end

RegisterNUICallback('hover', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    setHover(uid)
    cb({ label = uid and PropInfo[uid] or nil })
end)

RegisterNUICallback('pick', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    if not uid then return cb({}) end
    local ok, item, revealed, jackpot = lib.callback.await('storage:pickup', false, uid)
    if ok then
        PlaySoundFrontend(-1, 'PICK_UP', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        if jackpot then PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', true) end
    end
    cb({ ok = ok, label = item and item.label, value = item and item.value, revealed = revealed or 0, jackpot = jackpot and true or false })
end)

RegisterNUICallback('cam', function(d, cb)
    if inspecting then
        camLocal.x = camLocal.x + (d.dx or 0) * 0.35
        camLocal.y = camLocal.y + (d.dy or 0) * 0.35
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('fov', function(d, cb)
    if inspecting then
        camFov = clamp(camFov + (d.d or 0) * 3.0, 30.0, 70.0)
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('done', function(_, cb)
    lib.callback.await('storage:finishLoot', false)
    stopInspect()
    cb({})
end)

-- ===== Лобі / продаж / загальні колбеки UI =====
RegisterNUICallback('uiReady', function(_, cb)
    cb({ L = Locales[Config.Locale] and Locales[Config.Locale].ui or Locales.ru.ui, skipKey = Config.SkipKey })
end)

local function openLobby()
    local info = lib.callback.await('storage:lobbyInfo', false)
    lobbyOpen = true
    openFocus()
    ui('lobby', { info = info })
end

local function openSell(which)
    local inv = lib.callback.await('storage:getInv', false, which)
    if not inv then return toast(L('buyer_far'), 'error') end
    openFocus()
    ui('sell', { which = which, inv = inv })
end

RegisterNUICallback('close', function(_, cb)
    if inspecting then
        stopInspect()
    else
        lobbyOpen, resultsOpen = false, false
        closeFocus()
    end
    ui('close')
    cb({})
end)

RegisterNUICallback('lobbyJoin', function(_, cb)
    local ok, msg = lib.callback.await('storage:join', false)
    toast(msg, ok and 'success' or 'error')
    cb({ ok = ok })
end)

RegisterNUICallback('lobbyLeave', function(_, cb)
    lib.callback.await('storage:leave', false)
    lobbyOpen = false
    closeFocus()
    ui('close')
    toast(L('left_match'))
    cb({})
end)

RegisterNUICallback('lobbyStart', function(_, cb)
    local ok, msg = lib.callback.await('storage:start', false)
    if not ok and msg then toast(msg, 'error') end
    cb({ ok = ok })
end)

RegisterNUICallback('setContainers', function(d, cb)
    lib.callback.await('storage:setContainers', false, d.round, d.value)
    cb({})
end)

RegisterNUICallback('leaderboard', function(_, cb)
    cb({ rows = lib.callback.await('storage:leaderboard', false) or {} })
end)

RegisterNUICallback('sell', function(d, cb)
    local ok, paid = lib.callback.await('storage:sell', false, d.which, d.uid)
    if ok then toast(L('sold_for', math.floor(paid)), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)

RegisterNUICallback('sellAll', function(d, cb)
    local ok, paid = lib.callback.await('storage:sellAll', false, d.which)
    if ok then toast(L('sold_all', math.floor(paid)), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)

-- ===== Пропуск етапу =====
local function doSkip()
    if not S or S.state ~= 'round' or not S.canSkip then return end
    local ok, msg = lib.callback.await('storage:skip', false)
    if msg then toast(msg, ok and 'success' or 'error') end
    return ok
end

RegisterNUICallback('skip', function(d, cb)
    local ok = doSkip()
    local inv = d and d.which and lib.callback.await('storage:getInv', false, d.which) or nil
    cb({ ok = ok, inv = inv })
end)

RegisterCommand('storage_skip', function()
    if focused or inspecting then return end
    CreateThread(doSkip)
end, false)
RegisterKeyMapping('storage_skip', L('key_skip'), 'keyboard', Config.SkipKey)

-- ===== Події від сервера =====
local function sendState()
    if not S then return end
    local loc = curLoc()
    local iReady = false
    for _, s in ipairs(S.ready or {}) do if s == myId then iReady = true end end
    ui('state', {
        state = S.state, phase = S.phase, round = S.round, rounds = S.rounds, remaining = S.remaining, bonus = S.bonus,
        lotIdx = S.lotIdx, lotCount = S.lotCount, steps = S.steps, bid = S.bid,
        kind = S.lot and S.lot.kind, kindLabel = S.kindLabel, startPrice = S.lot and S.lot.startPrice,
        owner = S.lotOwnerName, mine = (S.lotOwner == myId), lead = (S.bid and S.bid.bidder == myId),
        locName = loc and loc.name,
        canSkip = S.canSkip, readyN = #(S.ready or {}), total = S.total or 0, iReady = iReady,
    })
end

RegisterNetEvent('storage:snapshot', function(snap)
    local prev = S
    S = snap
    updateBlips()
    if prev and snap.phase == 'bidding' and prev.bid and snap.bid.amount ~= prev.bid.amount then
        PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    end
    if prev and prev.phase == 'bidding' and snap.phase == 'looting' then
        PlaySoundFrontend(-1, 'PURCHASE', 'HUD_LIQUOR_STORE_SOUNDSET', true)
    end
    if lobbyOpen and snap.state ~= 'lobby' and snap.state ~= 'idle' then
        lobbyOpen = false
        closeFocus()
        ui('close')
    end
    sendState()
end)

RegisterNetEvent('storage:me', function(me)
    Me = me
    ui('me', me)
end)

RegisterNetEvent('storage:toast', function(msg, t) toast(msg, t) end)

RegisterNetEvent('storage:lobbyUpdate', function(info) ui('lobbyUpdate', { info = info }) end)

RegisterNetEvent('storage:joinable', function(on) setLobbyBlip(on) end)

RegisterNetEvent('storage:results', function(res)
    resultsOpen = true
    if inspecting then stopInspect() end
    openFocus()
    ui('results', res)
end)

RegisterNetEvent('storage:reset', function()
    S = nil
    Me = { cash = 0, spent = 0, items = 0, best = 0 }
    lobbyOpen = false
    if inspecting then stopInspect() end
    if not resultsOpen then closeFocus() end
    clearLot()
    clearNpc('auctioneer'); clearNpc('buyer'); clearNpc('far')
    clearLotBlips()
    DeleteWaypoint()
    if travelVeh and DoesEntityExist(travelVeh) and GetPedInVehicleSeat(travelVeh, -1) ~= PlayerPedId() then
        SetEntityAsMissionEntity(travelVeh, true, true)
        DeleteVehicle(travelVeh)
    end
    travelVeh = nil
    ui('reset')
end)

-- ===== Ставки: клавіші 1-4 =====
CreateThread(function()
    local keys = { 157, 158, 160, 164 }
    local last = 0
    while true do
        if S and S.state == 'round' and S.phase == 'bidding' and not focused and not inspecting then
            for i, k in ipairs(keys) do
                DisableControlAction(0, k, true)
                if IsDisabledControlJustPressed(0, k) and GetGameTimer() - last > 250 then
                    last = GetGameTimer()
                    CreateThread(function()
                        local ok, msg = lib.callback.await('storage:bid', false, i)
                        if not ok and msg then toast(msg, 'error') end
                    end)
                end
            end
            Wait(0)
        else
            Wait(250)
        end
    end
end)

-- ===== NPC лобі, іконка лобі =====
CreateThread(function()
    local Lb = Config.Lobby
    spawnNpc('lobby', Lb.ped, Lb.coords.x, Lb.coords.y, Lb.coords.z - 1.0, Lb.coords.w, nil, L('npc_lobby'))
    Wait(1500)
    setLobbyBlip(lib.callback.await('storage:isJoinable', false) and true or false)
end)

-- ===== Повільний цикл: речі, NPC, автоогляд, дистанція =====
CreateThread(function()
    while true do
        Wait(500)
        ensureLot()
        manageNpcs()

        if S and S.state == 'round' and S.phase == 'looting' and S.lotOwner == myId and S.lot then
            if not inspecting and not autoInspected[S.lot.id] and lotId == S.lot.id and next(LotProps) then
                autoInspected[S.lot.id] = true
                startInspect()
            end
        elseif inspecting then
            stopInspect()
        end

        local loc = curLoc()
        if S and S.state == 'travel' and loc then
            ui('dist', { m = math.floor(#(GetEntityCoords(cache.ped) - loc.coords)) })
            if S.reported ~= S.round and #(GetEntityCoords(cache.ped) - loc.coords) < Config.ArrivalRadius then
                S.reported = S.round
                TriggerServerEvent('storage:arrived')
            end
        end
    end
end)

-- ===== Взаємодія (E) =====
CreateThread(function()
    while true do
        local sleep = 500
        if not focused and not inspecting then
            local ppos = GetEntityCoords(cache.ped)
            local target, text
            if #(ppos - Config.Lobby.coords.xyz) < 2.5 then
                target, text = 'lobby', L('help_lobby')
            end
            if Npcs.buyer and DoesEntityExist(Npcs.buyer) and #(ppos - GetEntityCoords(Npcs.buyer)) < 2.8 then
                target, text = 'local', L('help_sell')
            end
            if Npcs.far and DoesEntityExist(Npcs.far) and #(ppos - GetEntityCoords(Npcs.far)) < 2.8 then
                target, text = 'far', L('help_sell_far', Config.FarBuyerMult)
            end
            local loc = curLoc()
            if not target and S and S.phase == 'looting' and S.lotOwner == myId and loc and #(ppos - loc.coords) < 60.0 then
                target, text = 'inspect', L('help_inspect')
            end
            if target then
                sleep = 0
                helpText(text)
                if IsControlJustReleased(0, 38) then
                    CreateThread(function()
                        if target == 'lobby' then openLobby()
                        elseif target == 'inspect' then startInspect()
                        else openSell(target) end
                    end)
                end
            end
        end
        Wait(sleep)
    end
end)

-- ===== Спавн при вході на сервер: біля початку гри (лобі) =====
local joinSpawned = false
local function joinSpawn()
    if joinSpawned or not Config.JoinSpawn or not Config.JoinSpawn.enabled then return end
    joinSpawned = true
    local c = Config.JoinSpawn.coords or Config.Lobby.coords
    local r = Config.JoinSpawn.radius or 3.5
    local ang = math.random() * math.pi * 2
    local x, y = c.x + math.cos(ang) * r, c.y + math.sin(ang) * r
    local ped = PlayerPedId()
    RequestCollisionAtCoord(x, y, c.z)
    local z = c.z
    local found, gz = GetGroundZFor_3dCoord(x, y, c.z + 2.0, false)
    if found then z = gz end
    SetEntityCoordsNoOffset(ped, x, y, z + 0.1, false, false, false)
    SetEntityHeading(ped, (c.w or 0.0) + 180.0)
end

AddEventHandler('playerSpawned', function()
    CreateThread(function() Wait(800) joinSpawn() end)
end)
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    CreateThread(function() Wait(1500) joinSpawn() end)
end)
RegisterNetEvent('esx:playerLoaded', function()
    CreateThread(function() Wait(1500) joinSpawn() end)
end)

-- ===== Адмін-інструменти для налаштування координат (потрібне ACE storage.admin) =====
local function isAdmin()
    local ok = lib.callback.await('storage:isAdmin', false)
    if not ok then toast(L('admin_no'), 'error') end
    return ok
end

-- /storagepos — стань В ДВЕРЯХ і дивись ВСЕРЕДИНУ лоту: виведе готовий рядок для config.lua
RegisterCommand('storagepos', function()
    if not isAdmin() then return end
    local p = GetEntityCoords(PlayerPedId())
    local h = GetEntityHeading(PlayerPedId())
    local line = ('{ name = \'Новая точка\', coords = vec3(%.1f, %.1f, %.1f), heading = %.1f },'):format(p.x, p.y, p.z - 1.0, h)
    print(line)
    pcall(function() lib.setClipboard(line) end)
    toast(line, 'success')
end, false)

-- /storagetp <раунд> <номер локації>
RegisterCommand('storagetp', function(_, args)
    if not isAdmin() then return end
    local R = Config.Rounds[tonumber(args[1]) or 0]
    local loc = R and R.locations[tonumber(args[2]) or 1]
    if not loc then return toast('/storagetp <round> <index>', 'error') end
    local w = LocalToWorld(loc, 0.0, -10.0)
    RequestCollisionAtCoord(w.x, w.y, loc.coords.z)
    SetEntityCoords(PlayerPedId(), w.x, w.y, loc.coords.z + 1.0, false, false, false, false)
    SetEntityHeading(PlayerPedId(), loc.heading)
end, false)

-- /storagedebug — малює габарити лотів усіх локацій. Зелений = рівно, червоний = нерівно / земля не знайдена.
local dbgCache = {}
local function dbgFootprint(R, loc)
    local W, D = 2.4, 6.0
    for k in pairs(R.kinds) do
        local T = Config.LotTypes[k]
        if T then
            local w, d = LotDims(k, loc)
            W, D = math.max(W, w), math.max(D, d)
        end
    end
    if loc.kind then W, D = LotDims(loc.kind, loc) end
    return W, D
end

RegisterCommand('storagedebug', function()
    if not isAdmin() then return end
    debugOn = not debugOn
    toast(debugOn and 'storagedebug ON' or 'storagedebug OFF')
end, false)

CreateThread(function()
    while true do
        if not debugOn then
            Wait(500)
        else
            local ppos = GetEntityCoords(PlayerPedId())
            for ri, R in ipairs(Config.Rounds) do
                for li, loc in ipairs(R.locations) do
                    if #(ppos - loc.coords) < 400.0 then
                        local key = ri * 100 + li
                        local c = dbgCache[key]
                        if not c or GetGameTimer() - c.t > 1500 then
                            local W, D = dbgFootprint(R, loc)
                            local zmin, zmax, miss = 1e9, -1e9, 0
                            for ix = -1, 1 do
                                for iy = 0, 4 do
                                    local w = LocalToWorld(loc, ix * W / 2, iy * D / 4)
                                    local f, gz = GetGroundZFor_3dCoord(w.x, w.y, loc.coords.z + 3.0, false)
                                    if f then zmin, zmax = math.min(zmin, gz), math.max(zmax, gz) else miss = miss + 1 end
                                end
                            end
                            local ok = miss == 0 and (zmax - zmin) <= 0.8 and math.abs(zmax - loc.coords.z) <= 2.0
                            c = { t = GetGameTimer(), W = W, D = D, ok = ok, zmin = zmin, zmax = zmax, miss = miss }
                            dbgCache[key] = c
                        end
                        local r, g, b = 60, 220, 90
                        if not c.ok then r, g, b = 255, 70, 70 end
                        local z = loc.coords.z + 0.2
                        local pts = {
                            LocalToWorld(loc, -c.W / 2, 0.0), LocalToWorld(loc, c.W / 2, 0.0),
                            LocalToWorld(loc, c.W / 2, c.D), LocalToWorld(loc, -c.W / 2, c.D),
                        }
                        for i = 1, 4 do
                            local a, bb = pts[i], pts[i % 4 + 1]
                            DrawLine(a.x, a.y, z, bb.x, bb.y, z, r, g, b, 255)
                            DrawLine(a.x, a.y, z, a.x, a.y, z + 3.0, r, g, b, 255)
                        end
                        local lbl = ('%d.%d %s  [%.1f..%.1f]%s'):format(ri, li, loc.name, c.zmin == 1e9 and 0 or c.zmin, c.zmax == -1e9 and 0 or c.zmax,
                            c.miss > 0 and ('  no-ground:' .. c.miss) or '')
                        Draw3D(vec3(loc.coords.x, loc.coords.y, z + 3.5), lbl)
                        -- місця продажу
                        local fp = GetFarPos(loc)
                        local bp, ap = GetBuyerPos(loc), GetAuctioneerPos(loc)
                        DrawLine(fp.x, fp.y, z, fp.x, fp.y, z + 2.0, 80, 160, 255, 255)
                        DrawLine(bp.x, bp.y, z, bp.x, bp.y, z + 2.0, 255, 220, 80, 255)
                        DrawLine(ap.x, ap.y, z, ap.x, ap.y, z + 2.0, 255, 255, 255, 255)
                    end
                end
            end
            Wait(0)
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if inspecting then
        RenderScriptCams(false, false, 0, true, true)
        FreezeEntityPosition(PlayerPedId(), false)
    end
    SetNuiFocus(false, false)
    clearLot()
    for k in pairs(Npcs) do clearNpc(k) end
    clearLotBlips()
    if blips.lobby then RemoveBlip(blips.lobby) end
end)
