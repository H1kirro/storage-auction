local S, Me = nil, { cash = 0, spent = 0, items = 0, best = 0 }
local Lang = Config.Language
local focused, inspecting, lobbyOpen, resultsOpen = false, false, false, false
local cam, camLocal, camFov = nil, { x = 0.0, y = -2.2 }, 55.0
local LotProps, PropInfo = {}, {}          -- uid -> entity / label
local ShellProps = {}
local lotId, shellGz, shellFront, lotFy = nil, nil, -0.6, 1.0
local autoInspected = {}
local hoverEnt = nil
local Npcs, Labels = {}, {}
local blips = { lobby = nil, lot = nil, radius = nil, lotKey = nil, routeOn = false, far = nil, farKey = nil }
local travelVeh = nil
local myId = GetPlayerServerId(PlayerId())

-- ===== Helpers =====
local function ui(action, data)
    data = data or {}
    data.lang = Lang
    SendNUIMessage({ action = action, data = data })
end

local function toast(msg, t) ui('toast', { msg = msg, type = t or 'info' }) end

local function money(n)
    local s = tostring(math.floor(n or 0))
    s = s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    return '$' .. s
end

local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

local function curLoc()
    if S and S.testLoc then return S.testLoc end
    if not S or not S.round or S.round < 1 or not S.locIdx or S.locIdx < 1 then return nil end
    return Config.Rounds[S.round].locations[S.locIdx]
end

-- Never probe from high above (that could land on a roof): start 2 m above the configured ground.
local function groundZ(x, y, z)
    local found, gz = GetGroundZFor_3dCoord(x, y, z + 2.0, false)
    if found and math.abs(gz - z) < 3.0 then return gz end
    return z
end

local function Draw3D(coords, text)
    SetDrawOrigin(coords.x, coords.y, coords.z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 230)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function helpText(msg)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

local function openFocus() focused = true SetNuiFocus(true, true) end
local function closeFocus() focused = false SetNuiFocus(false, false) end

local function makeBlip(x, y, z, cfg, name, scale, shortRange)
    local b = AddBlipForCoord(x, y, z)
    SetBlipSprite(b, cfg.sprite)
    SetBlipColour(b, cfg.colour)
    SetBlipScale(b, scale or 0.9)
    SetBlipAsShortRange(b, shortRange and true or false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(name)
    EndTextCommandSetBlipName(b)
    return b
end

-- ===== Blips =====
local function setLobbyBlip(on)
    if on and not blips.lobby then
        local c = Config.Lobby.coords
        blips.lobby = makeBlip(c.x, c.y, c.z, Config.Blips.lobby, T(Lang, 'blip_lobby'), 0.8, true)
    elseif not on and blips.lobby then
        RemoveBlip(blips.lobby)
        blips.lobby = nil
    end
end

local function refreshBlips()
    local active = S and (S.state == 'travel' or S.state == 'round')
    local loc = active and curLoc() or nil
    local key = loc and (S.round .. ':' .. S.locIdx) or nil

    if blips.lotKey ~= key then
        if blips.lot then RemoveBlip(blips.lot) blips.lot = nil end
        if blips.radius then RemoveBlip(blips.radius) blips.radius = nil end
        if blips.far then RemoveBlip(blips.far) blips.far = nil end
        if blips.routeOn then DeleteWaypoint() blips.routeOn = false end
        blips.lotKey, blips.farKey = key, nil
        if loc then
            local cfg = S.bonus and Config.Blips.bonus or Config.Blips.lot
            local name = T(Lang, S.bonus and 'blip_bonus' or 'blip_lot')
            blips.lot = makeBlip(loc.coords.x, loc.coords.y, loc.coords.z, cfg, name, 1.1, false)
            if S.state == 'travel' then
                SetBlipRoute(blips.lot, true)
                SetNewWaypoint(loc.coords.x, loc.coords.y)
                blips.routeOn = true
                blips.radius = AddBlipForRadius(loc.coords.x, loc.coords.y, loc.coords.z, Config.ArrivalRadius)
                SetBlipColour(blips.radius, cfg.colour)
                SetBlipAlpha(blips.radius, 110)
            end
            local cpos = GetCollectorPos(loc)
            blips.far = makeBlip(cpos.x, cpos.y, cpos.z, Config.Blips.collector, T(Lang, 'blip_collector', Config.FarBuyerMult), 0.9, false)
        end
    end

    if blips.lot and S and S.state == 'round' and blips.routeOn then
        SetBlipRoute(blips.lot, false)
        DeleteWaypoint()
        blips.routeOn = false
        if blips.radius then RemoveBlip(blips.radius) blips.radius = nil end
    end
end

local function clearBlips()
    S = nil
    refreshBlips()
end

-- ===== NPCs =====
local function spawnNpc(key, model, x, y, z, heading, scenario, label)
    if Npcs[key] and DoesEntityExist(Npcs[key]) then return end
    local m = joaat(model)
    if not IsModelInCdimage(m) then m = joaat('a_m_m_business_01') end
    lib.requestModel(m)
    local ped = CreatePed(0, m, x, y, z, heading, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    if scenario then TaskStartScenarioInPlace(ped, scenario, 0, true) end
    FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(m)
    Npcs[key], Labels[key] = ped, label
end

local function clearNpc(key)
    if Npcs[key] then
        if DoesEntityExist(Npcs[key]) then DeleteEntity(Npcs[key]) end
        Npcs[key], Labels[key] = nil, nil
    end
end

local function manageNpcs()
    local ppos = GetEntityCoords(cache.ped)
    local loc = curLoc()
    local inRound = S and S.state == 'round' and loc
    if inRound and #(ppos - loc.coords) < 170.0 then
        local a, b = Config.Layout.auctioneer, Config.Layout.buyer
        local aw = LocalToWorld(loc, a.x, a.y)
        local bw = LocalToWorld(loc, b.x, b.y)
        spawnNpc('auctioneer', Config.AuctioneerPed, aw.x, aw.y, groundZ(aw.x, aw.y, aw.z), loc.heading + 180.0,
            'WORLD_HUMAN_CLIPBOARD', T(Lang, 'npc_auctioneer'))
        spawnNpc('buyer', Config.BuyerPed, bw.x, bw.y, groundZ(bw.x, bw.y, bw.z), loc.heading + 180.0, nil,
            T(Lang, 'npc_buyer', Config.LocalBuyerMult))
    else
        clearNpc('auctioneer')
        clearNpc('buyer')
    end

    local active = S and (S.state == 'travel' or S.state == 'round') and loc
    if active then
        local cpos, ch = GetCollectorPos(loc)
        if #(ppos - cpos) < 170.0 then
            spawnNpc('far', Config.FarBuyerPed, cpos.x, cpos.y, groundZ(cpos.x, cpos.y, cpos.z), ch, nil,
                T(Lang, 'npc_collector', Config.FarBuyerMult))
        else
            clearNpc('far')
        end
    else
        clearNpc('far')
    end
end

-- ===== Lot: real prop shell + items =====
local function clearShell()
    for _, e in ipairs(ShellProps) do
        if DoesEntityExist(e) then DeleteEntity(e) end
    end
    ShellProps = {}
end

local function clearLot()
    for _, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then DeleteEntity(ent) end
    end
    LotProps, PropInfo = {}, {}
    clearShell()
    lotId = nil
    lotFy = 1.0
end

-- Places a solid prop so its bounding box centre lands on local (tx, ty) and its bottom on baseZ.
-- alongForward = the model's long side runs into the lot (true) or across it (false).
local function placeBox(model, tx, ty, alongForward, loc, baseZ, visible)
    local mn, mx = GetModelDimensions(model)
    local dx, dy = mx.x - mn.x, mx.y - mn.y
    local yLong = dy >= dx
    local off
    if alongForward then off = yLong and 0.0 or 90.0 else off = yLong and -90.0 or 0.0 end
    local eh = loc.heading + off
    local r = math.rad(eh)
    local cx, cy = (mn.x + mx.x) / 2, (mn.y + mx.y) / 2
    local ox = cx * math.cos(r) - cy * math.sin(r)
    local oy = cx * math.sin(r) + cy * math.cos(r)
    local tw = LocalToWorld(loc, tx, ty)
    local obj = CreateObject(model, tw.x - ox, tw.y - oy, baseZ - mn.z, false, false, false)
    SetEntityHeading(obj, eh)
    FreezeEntityPosition(obj, true)
    SetEntityCollision(obj, true, true)
    if not visible then SetEntityVisible(obj, false, false) end
    ShellProps[#ShellProps + 1] = obj
    return obj
end

local function firstValidModel(list, startIdx)
    local n = #list
    for i = 0, n - 1 do
        local h = joaat(list[((startIdx - 1 + i) % n) + 1])
        if IsModelInCdimage(h) then return h end
    end
end

local function buildShell(loc, lot)
    clearShell()
    lotFy, shellFront = 1.0, -0.3
    local d = lot.dims

    if lot.kind == 'container' then
        local model = firstValidModel(Config.ContainerModels, lot.modelIdx or 1)
        if not model then
            print('^1[storage_auction] no valid model in Config.ContainerModels^0')
            return
        end
        lib.requestModel(model)
        local mn, mx = GetModelDimensions(model)
        local dx, dy = mx.x - mn.x, mx.y - mn.y
        local len, sh = math.max(dx, dy), math.min(dx, dy)
        lotFy = clamp((len - 0.8) / d.depth, 0.3, 1.0)
        local D, W = d.depth * lotFy, d.width
        placeBox(model, -(W / 2 + sh / 2), D / 2, true, loc, shellGz, true)
        placeBox(model, (W / 2 + sh / 2), D / 2, true, loc, shellGz, true)
        placeBox(model, 0.0, D / 2 + len / 2 + sh / 2, false, loc, shellGz, true)
        placeBox(model, 0.0, D / 2 - len / 2 - sh / 2, false, loc, shellGz, false)   -- invisible wall: nobody walks in
        shellFront = D / 2 - len / 2
        SetModelAsNoLongerNeeded(model)
    else
        local model = firstValidModel(Config.GarageBarrierModels, 1)
        if model then
            lib.requestModel(model)
            local mn, mx = GetModelDimensions(model)
            local len = math.max(mx.x - mn.x, mx.y - mn.y)
            local hgt = mx.z - mn.z
            local count = math.max(1, math.ceil((d.width + 1.0) / len))
            for layer = 0, (Config.GarageBarrierLayers or 2) - 1 do
                for i = 1, count do
                    local tx = -(count * len) / 2 + (i - 0.5) * len
                    placeBox(model, tx, -0.3, false, loc, shellGz + layer * hgt, false)
                end
            end
            SetModelAsNoLongerNeeded(model)
        end
        if Config.GarageDoor and Config.GarageDoor.open then Config.GarageDoor.open(loc) end
    end
end

local function spawnItem(it, loc)
    local model = joaat(it.model)
    local w = LocalToWorld(loc, it.lx, it.ly * lotFy)
    local ent
    if it.isVehicle then
        if not IsModelInCdimage(model) or not IsModelAVehicle(model) then model = joaat('asea') end
        lib.requestModel(model)
        ent = CreateVehicle(model, w.x, w.y, shellGz + 0.5, loc.heading + it.heading, false, false)
        SetEntityAsMissionEntity(ent, true, true)
        SetVehicleOnGroundProperly(ent)
        SetVehicleDoorsLocked(ent, 10)
        SetVehicleEngineOn(ent, false, true, true)
        SetVehicleUndriveable(ent, true)
        SetEntityInvincible(ent, true)
        FreezeEntityPosition(ent, true)
    else
        if not IsModelInCdimage(model) then model = joaat('prop_cs_cardbox_01') end
        lib.requestModel(model)
        ent = CreateObject(model, w.x, w.y, shellGz + 0.3, false, false, false)
        SetEntityHeading(ent, loc.heading + it.heading)
        PlaceObjectOnGroundProperly(ent)
        FreezeEntityPosition(ent, true)
    end
    SetModelAsNoLongerNeeded(model)
    LotProps[it.uid] = ent
    PropInfo[it.uid] = it.label
end

local function removeProp(uid)
    local ent = LotProps[uid]
    LotProps[uid], PropInfo[uid] = nil, nil
    if not ent then return end
    if hoverEnt == ent then hoverEnt = nil end
    CreateThread(function()
        if not DoesEntityExist(ent) then return end
        local c = GetEntityCoords(ent)
        for i = 1, 12 do
            SetEntityCoordsNoOffset(ent, c.x, c.y, c.z + i * 0.08, false, false, false)
            SetEntityAlpha(ent, 255 - i * 20, false)
            Wait(20)
        end
        DeleteEntity(ent)
    end)
end

local function ensureLot()
    local loc = curLoc()
    local lot = S and S.state == 'round' and S.lot or nil
    if not lot or not loc then
        if lotId then clearLot() end
        return
    end
    local dist = #(GetEntityCoords(cache.ped) - loc.coords)
    if dist > 240.0 then
        if lotId then clearLot() end
        return
    end
    if dist > 160.0 then return end

    if lotId ~= lot.id then
        clearLot()
        lotId = lot.id
        shellGz = groundZ(loc.coords.x, loc.coords.y, loc.coords.z)
        buildShell(loc, lot)
    end
    local want = {}
    for _, it in ipairs(lot.items) do
        want[it.uid] = true
        if not LotProps[it.uid] then spawnItem(it, loc) end
    end
    for uid in pairs(LotProps) do
        if not want[uid] then removeProp(uid) end
    end
end

-- Lights inside the lot + the sign above the entrance
CreateThread(function()
    while true do
        local lot = S and S.state == 'round' and S.lot or nil
        local loc = curLoc()
        if lot and loc and shellGz and lotId == lot.id and #(GetEntityCoords(cache.ped) - loc.coords) < 90.0 then
            local D = lot.dims.depth * lotFy
            for n = 1, 2 do
                local p = LocalToWorld(loc, 0.0, D * n / 3)
                DrawLightWithRange(p.x, p.y, shellGz + 2.3, 255, 235, 205, 9.0, 4.0)
            end
            local sp = LocalToWorld(loc, 0.0, shellFront - 0.3)
            Draw3D(vec3(sp.x, sp.y, shellGz + 3.3),
                T(Lang, 'sign_lot', S.lotIdx or 1, S.lotCount or 1, (lot.variantName or '') .. ' - ' .. (lot.themeName or '')))
            Wait(0)
        else
            Wait(300)
        end
    end
end)

-- NPC labels
CreateThread(function()
    while true do
        local any = false
        local ppos = GetEntityCoords(cache.ped)
        for key, ped in pairs(Npcs) do
            if Labels[key] and DoesEntityExist(ped) then
                local pc = GetEntityCoords(ped)
                if #(ppos - pc) < 14.0 then
                    any = true
                    Draw3D(pc + vec3(0.0, 0.0, 1.15), Labels[key])
                end
            end
        end
        Wait(any and 0 or 300)
    end
end)

-- ===== Travel vehicle =====
RegisterNetEvent('storage:spawnCar', function(modelName)
    if not Config.SpawnTravelVehicle then return end
    CreateThread(function()
        local model = joaat(modelName)
        if not IsModelInCdimage(model) or not IsModelAVehicle(model) then return end
        lib.requestModel(model, 10000)

        if travelVeh and DoesEntityExist(travelVeh) then
            SetEntityAsMissionEntity(travelVeh, true, true)
            DeleteVehicle(travelVeh)
        end
        local ped = PlayerPedId()
        local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 5.0, 0.0)
        local spawn, heading = pos, GetEntityHeading(ped)
        local ok, node, nodeH = GetClosestVehicleNodeWithHeading(pos.x, pos.y, pos.z, 1, 3.0, 0)
        if ok and #(node - pos) < 30.0 then spawn, heading = node, nodeH end

        local veh = CreateVehicle(model, spawn.x, spawn.y, spawn.z, heading, true, false)
        SetEntityAsMissionEntity(veh, true, true)
        SetVehicleOnGroundProperly(veh)
        SetVehicleNumberPlateText(veh, ('WARS%03d'):format(math.random(0, 999)))
        TaskWarpPedIntoVehicle(ped, veh, -1)
        SetModelAsNoLongerNeeded(model)
        travelVeh = veh
        if Config.OnTravelVehicle then Config.OnTravelVehicle(veh, GetVehicleNumberPlateText(veh)) end
        toast(T(Lang, 'ride_here'), 'success')
    end)
end)

-- ===== Inspect mode (winner takes things out of the lot) =====
local function updateCam()
    local loc, lot = curLoc(), S and S.lot
    if not cam or not loc or not lot then return end
    camLocal.x = clamp(camLocal.x, -lot.dims.width / 2 - 0.5, lot.dims.width / 2 + 0.5)
    camLocal.y = clamp(camLocal.y, -3.5, lot.dims.depth * lotFy * 0.7)
    local w = LocalToWorld(loc, camLocal.x, camLocal.y)
    SetCamCoord(cam, w.x, w.y, (shellGz or w.z) + 1.55)
    SetCamRot(cam, -12.0, 0.0, loc.heading + 0.0, 2)
    SetCamFov(cam, camFov)
end

local function setHover(ent)
    if hoverEnt == ent then return end
    if hoverEnt and DoesEntityExist(hoverEnt) then SetEntityDrawOutline(hoverEnt, false) end
    hoverEnt = ent
    if ent and DoesEntityExist(ent) then
        SetEntityDrawOutlineColor(255, 183, 3, 255)
        SetEntityDrawOutline(ent, true)
    end
end

local function startInspect()
    if inspecting then return end
    inspecting = true
    FreezeEntityPosition(PlayerPedId(), true)
    cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    camLocal, camFov = { x = 0.0, y = -2.2 }, 55.0
    updateCam()
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 800, true, true)
    openFocus()
    ui('inspect', { on = true })
end

local function stopInspect()
    if not inspecting then return end
    inspecting = false
    setHover(nil)
    RenderScriptCams(false, true, 600, true, true)
    local c = cam
    cam = nil
    CreateThread(function()
        Wait(700)
        if c then DestroyCam(c, false) end
    end)
    FreezeEntityPosition(PlayerPedId(), false)
    closeFocus()
    ui('inspect', { on = false })
end

-- Screen-space picking: nearest prop whose projected bounding sphere contains the cursor.
local function pickAt(nx, ny)
    if not cam then return nil end
    local w, h = GetActiveScreenResolution()
    local camPos = GetCamCoord(cam)
    local yaw = math.rad(GetCamRot(cam, 2).z)
    local right = vec3(math.cos(yaw), math.sin(yaw), 0.0)
    local best, bd = nil, 1e9
    for uid, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then
            local mn, mx = GetModelDimensions(GetEntityModel(ent))
            local size = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z)
            local r = size * 0.5 * 0.75
            local c = GetOffsetFromEntityInWorldCoords(ent, (mn.x + mx.x) / 2, (mn.y + mx.y) / 2, (mn.z + mx.z) / 2)
            local on, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
            if on then
                local on2, sx2 = GetScreenCoordFromWorldCoord(c.x + right.x * r, c.y + right.y * r, c.z)
                local rpx = on2 and math.abs(sx2 - sx) * w or 40.0
                local dx, dy = (nx - sx) * w, (ny - sy) * h
                if dx * dx + dy * dy <= rpx * rpx then
                    local d = #(c - camPos)
                    if d < bd then best, bd = uid, d end
                end
            end
        end
    end
    return best
end

RegisterNUICallback('hover', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    setHover(uid and LotProps[uid] or nil)
    cb({ label = uid and PropInfo[uid] or nil })
end)

RegisterNUICallback('pick', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    if not uid then return cb({}) end
    local ok, item, revealed = lib.callback.await('storage:pickup', false, uid)
    if ok then PlaySoundFrontend(-1, 'PICK_UP', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
    cb({ ok = ok, label = item and item.label, value = item and item.value, revealed = revealed or 0 })
end)

RegisterNUICallback('cam', function(d, cb)
    if inspecting then
        camLocal.x = camLocal.x + (d.dx or 0) * 0.35
        camLocal.y = camLocal.y + (d.dy or 0) * 0.35
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('fov', function(d, cb)
    if inspecting then
        camFov = clamp(camFov + (d.d or 0) * 3.0, 30.0, 70.0)
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('done', function(_, cb)
    lib.callback.await('storage:finishLoot', false)
    stopInspect()
    cb({})
end)

-- ===== Lobby / sell / generic UI callbacks =====
local function openLobby()
    local info = lib.callback.await('storage:lobbyInfo', false)
    Lang = info.lang or Lang
    lobbyOpen = true
    openFocus()
    ui('lobby', { info = info })
end

local function openSell(which)
    local inv = lib.callback.await('storage:getInv', false, which)
    if not inv then return toast(T(Lang, 'buyer_far'), 'error') end
    openFocus()
    ui('sell', { which = which, inv = inv })
end

RegisterNUICallback('close', function(_, cb)
    if inspecting then
        stopInspect()
    else
        lobbyOpen, resultsOpen = false, false
        closeFocus()
    end
    ui('close')
    cb({})
end)

RegisterNUICallback('lobbyJoin', function(_, cb)
    local ok, msg = lib.callback.await('storage:join', false)
    toast(msg, ok and 'success' or 'error')
    cb({ ok = ok })
end)

RegisterNUICallback('lobbyLeave', function(_, cb)
    lib.callback.await('storage:leave', false)
    lobbyOpen = false
    closeFocus()
    ui('close')
    toast(T(Lang, 'left_match'))
    cb({})
end)

RegisterNUICallback('lobbyStart', function(_, cb)
    local ok, msg = lib.callback.await('storage:start', false)
    if not ok and msg then toast(msg, 'error') end
    cb({ ok = ok })
end)

RegisterNUICallback('setContainers', function(d, cb)
    lib.callback.await('storage:setContainers', false, d.round, d.value)
    cb({})
end)

RegisterNUICallback('setLang', function(d, cb)
    lib.callback.await('storage:setLang', false, d.lang)
    cb({})
end)

RegisterNUICallback('leaderboard', function(_, cb)
    cb({ rows = lib.callback.await('storage:leaderboard', false) or {} })
end)

RegisterNUICallback('sell', function(d, cb)
    local ok, paid = lib.callback.await('storage:sell', false, d.which, d.uid)
    if ok then toast(T(Lang, 'sold_one', money(paid)), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)

RegisterNUICallback('sellAll', function(d, cb)
    local ok, paid = lib.callback.await('storage:sellAll', false, d.which)
    if ok then toast(T(Lang, 'sold_all', money(paid)), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)

RegisterNUICallback('skipSell', function(_, cb)
    lib.callback.await('storage:skipSell', false)
    cb({})
end)

-- ===== Events from the server =====
local function sendState()
    if not S or S.testLoc then return end
    local loc = curLoc()
    ui('state', {
        state = S.state, phase = S.phase, round = S.round, roundNo = S.roundNo, roundsTotal = S.roundsTotal, bonus = S.bonus,
        remaining = S.remaining, lotIdx = S.lotIdx, lotCount = S.lotCount, steps = S.steps, bid = S.bid,
        kindName = S.lot and S.lot.variantName, themeName = S.lot and S.lot.themeName,
        startPrice = S.lot and S.lot.startPrice,
        owner = S.lotOwnerName, mine = (S.lotOwner == myId), lead = (S.bid and S.bid.bidder == myId),
        locName = loc and LocName(loc, Lang), ready = S.ready, playersTotal = S.playersTotal,
    })
end

RegisterNetEvent('storage:snapshot', function(snap)
    local prev = S
    S = snap
    Lang = snap.lang or Lang
    refreshBlips()
    if prev and snap.phase == 'bidding' and prev.bid and snap.bid.amount ~= prev.bid.amount then
        PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    end
    if prev and prev.phase == 'bidding' and snap.phase == 'looting' then
        PlaySoundFrontend(-1, 'PURCHASE', 'HUD_LIQUOR_STORE_SOUNDSET', true)
    end
    if lobbyOpen and snap.state ~= 'lobby' and snap.state ~= 'idle' then
        lobbyOpen = false
        closeFocus()
        ui('close')
    end
    sendState()
end)

RegisterNetEvent('storage:me', function(me)
    Me = me
    ui('me', me)
end)

RegisterNetEvent('storage:toast', function(msg, t) toast(msg, t) end)

RegisterNetEvent('storage:lobbyUpdate', function(info)
    Lang = info.lang or Lang
    ui('lobbyUpdate', { info = info })
end)

RegisterNetEvent('storage:joinable', function(on) setLobbyBlip(on) end)

RegisterNetEvent('storage:results', function(res)
    resultsOpen = true
    Lang = res.lang or Lang
    if inspecting then stopInspect() end
    openFocus()
    ui('results', res)
end)

RegisterNetEvent('storage:reset', function()
    Me = { cash = 0, spent = 0, items = 0, best = 0 }
    lobbyOpen = false
    if inspecting then stopInspect() end
    if not resultsOpen then closeFocus() end
    clearLot()
    clearNpc('auctioneer'); clearNpc('buyer'); clearNpc('far')
    clearBlips()
    if travelVeh and DoesEntityExist(travelVeh) and GetPedInVehicleSeat(travelVeh, -1) ~= PlayerPedId() then
        SetEntityAsMissionEntity(travelVeh, true, true)
        DeleteVehicle(travelVeh)
    end
    travelVeh = nil
    ui('reset')
end)

-- ===== Keys: 1-4 bid, G skip selling =====
CreateThread(function()
    local keys = { 157, 158, 160, 164 }
    local last = 0
    while true do
        if S and not S.testLoc and S.state == 'round' and not focused and not inspecting
            and (S.phase == 'bidding' or S.phase == 'final') then
            if S.phase == 'bidding' then
                for i, k in ipairs(keys) do
                    DisableControlAction(0, k, true)
                    if IsDisabledControlJustPressed(0, k) and GetGameTimer() - last > 250 then
                        last = GetGameTimer()
                        CreateThread(function()
                            local ok, msg = lib.callback.await('storage:bid', false, i)
                            if not ok and msg then toast(msg, 'error') end
                        end)
                    end
                end
            else
                if IsControlJustPressed(0, 47) and GetGameTimer() - last > 500 then
                    last = GetGameTimer()
                    CreateThread(function() lib.callback.await('storage:skipSell', false) end)
                end
            end
            Wait(0)
        else
            Wait(250)
        end
    end
end)

-- ===== Lobby ped + blip + joinable state =====
CreateThread(function()
    local L = Config.Lobby
    spawnNpc('lobby', L.ped, L.coords.x, L.coords.y, L.coords.z - 1.0, L.coords.w, nil, T(Lang, 'npc_lobby'))
    Wait(1500)
    setLobbyBlip(lib.callback.await('storage:isJoinable', false) and true or false)
end)

-- ===== Spawn next to the game start when joining the server =====
local spawnDone = false
local function teleportToLobby()
    if spawnDone or not Config.SpawnAtLobby then return end
    spawnDone = true
    CreateThread(function()
        Wait(600)
        local ped = PlayerPedId()
        local s = Config.Lobby.spawn
        RequestCollisionAtCoord(s.x, s.y, s.z)
        SetEntityCoords(ped, s.x, s.y, s.z, false, false, false, false)
        SetEntityHeading(ped, s.w)
        local t = GetGameTimer() + 3000
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < t do Wait(50) end
    end)
end
AddEventHandler('playerSpawned', teleportToLobby)
RegisterNetEvent('esx:onPlayerSpawn', teleportToLobby)
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', teleportToLobby)

-- ===== Slow loop: props, NPCs, auto inspect, distance, arrival =====
CreateThread(function()
    while true do
        Wait(500)
        ensureLot()
        manageNpcs()

        if S and S.state == 'round' and S.phase == 'looting' and S.lotOwner == myId and S.lot and not S.testLoc then
            if not inspecting and not autoInspected[S.lot.id] and lotId == S.lot.id and next(LotProps) then
                autoInspected[S.lot.id] = true
                startInspect()
            end
        elseif inspecting then
            stopInspect()
        end

        local loc = curLoc()
        if S and S.state == 'travel' and loc then
            local d = #(GetEntityCoords(cache.ped) - loc.coords)
            ui('dist', { m = math.floor(d) })
            if S.reported ~= S.round and d < Config.ArrivalRadius then
                S.reported = S.round
                TriggerServerEvent('storage:arrived')
            end
        end
    end
end)

-- ===== Interaction (E) =====
CreateThread(function()
    while true do
        local sleep = 500
        if not focused and not inspecting then
            local ppos = GetEntityCoords(cache.ped)
            local target, text
            if #(ppos - Config.Lobby.coords.xyz) < 2.5 then
                target, text = 'lobby', T(Lang, 'help_lobby')
            end
            if Npcs.buyer and DoesEntityExist(Npcs.buyer) and #(ppos - GetEntityCoords(Npcs.buyer)) < 2.8 then
                target, text = 'local', T(Lang, 'help_sell')
            end
            if Npcs.far and DoesEntityExist(Npcs.far) and #(ppos - GetEntityCoords(Npcs.far)) < 2.8 then
                target, text = 'far', T(Lang, 'help_collector', Config.FarBuyerMult)
            end
            local loc = curLoc()
            if not target and S and not S.testLoc and S.phase == 'looting' and S.lotOwner == myId and loc and #(ppos - loc.coords) < 60.0 then
                target, text = 'inspect', T(Lang, 'help_inspect')
            end
            if target then
                sleep = 0
                helpText(text)
                if IsControlJustReleased(0, 38) then
                    CreateThread(function()
                        if target == 'lobby' then openLobby()
                        elseif target == 'inspect' then startInspect()
                        else openSell(target) end
                    end)
                end
            end
        end
        Wait(sleep)
    end
end)

-- ===== Helper / admin commands =====
RegisterCommand('storagecoords', function()
    if not Config.DebugCommands then return end
    local ped = PlayerPedId()
    local c, h = GetEntityCoords(ped), GetEntityHeading(ped)
    local line = ('coords = vec3(%.2f, %.2f, %.2f), heading = %.1f'):format(c.x, c.y, c.z - 1.0, h)
    print(line)
    toast(line, 'info')
    lib.setClipboard(line)
end, false)

-- Checks the footprint of a container lot in front of you (door = where you stand, facing INTO the lot)
RegisterCommand('storagecheck', function()
    if not Config.DebugCommands then return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local gz0 = c.z - 1.0
    local loc = { coords = vec3(c.x, c.y, gz0), heading = GetEntityHeading(ped) }
    local minZ, maxZ, overhead, nogr = 999.0, -999.0, 0, 0
    for ix = -2, 2 do
        for iy = 0, 6 do
            local w = LocalToWorld(loc, ix * 2.1, iy * 2.8 - 3.0)
            local found, gz = GetGroundZFor_3dCoord(w.x, w.y, gz0 + 2.0, false)
            if found then
                minZ, maxZ = math.min(minZ, gz), math.max(maxZ, gz)
            else
                nogr = nogr + 1
            end
            local h = StartExpensiveSynchronousShapeTestLosProbe(w.x, w.y, gz0 + 0.8, w.x, w.y, gz0 + 25.0, 1, ped, 4)
            local _, hit = GetShapeTestResult(h)
            if hit and hit ~= 0 then overhead = overhead + 1 end
        end
    end
    local flat = (maxZ - minZ) <= 1.0
    local ok = flat and overhead == 0 and nogr == 0
    local msg
    if Lang == 'ru' then
        msg = ok and 'Место подходит: ровно и открыто.' or
            ('ПЛОХОЕ место: перепад высот %.1f м, препятствий сверху: %d, без земли: %d'):format(maxZ - minZ, overhead, nogr)
    else
        msg = ok and 'Spot is OK: flat and open.' or
            ('BAD spot: height range %.1f m, overhead hits: %d, no ground: %d'):format(maxZ - minZ, overhead, nogr)
    end
    print(msg)
    toast(msg, ok and 'success' or 'error')
end, false)

RegisterCommand('storagetest', function(_, args)
    if not Config.DebugCommands then return end
    local ped = PlayerPedId()
    local c = GetOffsetFromEntityInWorldCoords(ped, 0.0, 4.0, 0.0)
    TriggerServerEvent('storage:testLot', tonumber(args[1]) or 1, args[2] or 'container',
        { x = c.x, y = c.y, z = c.z - 1.0 }, GetEntityHeading(ped))
end, false)

RegisterNetEvent('storage:testLot', function(d)
    clearLot()
    Lang = d.lang or Lang
    S = {
        state = 'round', phase = 'preview', round = d.round, roundNo = 1, roundsTotal = 1, locIdx = 1, lotIdx = 1, lotCount = 1,
        lot = d.lot, bid = { amount = d.lot.startPrice }, steps = {}, remaining = 3600, lang = d.lang,
        testLoc = { coords = vec3(d.coords.x, d.coords.y, d.coords.z), heading = d.heading, name = 'Test', ru = 'Тест' },
    }
end)

RegisterCommand('storagetestend', function()
    if S and S.testLoc then
        S = nil
        clearLot()
        clearNpc('auctioneer'); clearNpc('buyer'); clearNpc('far')
    end
end, false)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if inspecting then
        RenderScriptCams(false, false, 0, true, true)
        FreezeEntityPosition(PlayerPedId(), false)
    end
    SetNuiFocus(false, false)
    clearLot()
    for k in pairs(Npcs) do clearNpc(k) end
    clearBlips()
    if blips.lobby then RemoveBlip(blips.lobby) end
end)
