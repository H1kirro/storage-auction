local S, endLocal = nil, 0
local Me = { cash = 0, spent = 0, items = 0, best = 0 }
local Props, StoragePos = {}, {}
local propsSpawned, propsRound = false, nil
local buyerPed, buyerPos = nil, nil
local travelBlips = {}
local promptKey = nil
local reportedRound = nil
local myId = GetPlayerServerId(PlayerId())

-- ===== Helpers =====
local function notify(msg, t) lib.notify({ description = msg, type = t or 'inform' }) end

local function money(n)
    local s = tostring(math.floor(n or 0))
    s = s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    return '$' .. s
end

local function curLoc()
    if not S or not S.round or S.round < 1 then return nil end
    return Config.Rounds[S.round].locations[S.locIdx]
end

local function groundZ(x, y, z)
    local found, gz = GetGroundZFor_3dCoord(x, y, z + 100.0, false)
    if found then return gz end
    return z
end

local function Draw3D(coords, text)
    SetDrawOrigin(coords.x, coords.y, coords.z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 220)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function hudText(x, y, text, scale)
    SetTextFont(4)
    SetTextScale(scale, scale)
    SetTextColour(255, 255, 255, 235)
    SetTextOutline()
    SetTextProportional(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

local function clock(sec) return ('%d:%02d'):format(sec // 60, sec % 60) end

-- ===== Props & buyer =====
local function deleteProps()
    for _, obj in pairs(Props) do
        if DoesEntityExist(obj) then DeleteEntity(obj) end
    end
    Props, StoragePos = {}, {}
    if buyerPed and DoesEntityExist(buyerPed) then DeleteEntity(buyerPed) end
    buyerPed, buyerPos = nil, nil
    propsSpawned, propsRound = false, nil
end

local function spawnProps()
    local loc = curLoc()
    if not loc or not S.storages then return end
    propsSpawned, propsRound = true, S.round

    local model = joaat(Config.Props[S.round] or 'prop_cs_cardbox_01')
    if not IsModelInCdimage(model) then model = joaat('prop_cs_cardbox_01') end
    lib.requestModel(model)

    local count = #S.storages
    for i = 1, count do
        local pos = GetLayoutPos(loc, i, count)
        local gz = groundZ(pos.x, pos.y, pos.z)
        local obj = CreateObject(model, pos.x, pos.y, gz, false, false, false)
        SetEntityHeading(obj, loc.heading)
        PlaceObjectOnGroundProperly(obj)
        FreezeEntityPosition(obj, true)
        Props[i] = obj
        StoragePos[i] = GetEntityCoords(obj)
    end
    SetModelAsNoLongerNeeded(model)

    local bp = GetBuyerPos(loc)
    local bz = groundZ(bp.x, bp.y, bp.z)
    local bm = joaat(Config.BuyerPed)
    lib.requestModel(bm)
    buyerPed = CreatePed(0, bm, bp.x, bp.y, bz, loc.heading, false, true)
    SetEntityInvincible(buyerPed, true)
    SetBlockingOfNonTemporaryEvents(buyerPed, true)
    FreezeEntityPosition(buyerPed, true)
    SetModelAsNoLongerNeeded(bm)
    buyerPos = vec3(bp.x, bp.y, bz)
end

-- ===== Travel blips =====
local function clearTravelBlips()
    for _, b in ipairs(travelBlips) do RemoveBlip(b) end
    travelBlips = {}
    DeleteWaypoint()
end

local function startTravelBlips()
    if #travelBlips > 0 then return end
    local loc = curLoc()
    if not loc then return end
    local b = AddBlipForCoord(loc.coords.x, loc.coords.y, loc.coords.z)
    SetBlipSprite(b, 478)
    SetBlipColour(b, 5)
    SetBlipScale(b, 1.0)
    SetBlipRoute(b, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Storage Wars: ' .. loc.name)
    EndTextCommandSetBlipName(b)
    local r = AddBlipForRadius(loc.coords.x, loc.coords.y, loc.coords.z, Config.ArrivalRadius)
    SetBlipColour(r, 5)
    SetBlipAlpha(r, 120)
    travelBlips = { b, r }
    SetNewWaypoint(loc.coords.x, loc.coords.y)
end

-- ===== Events from server =====
RegisterNetEvent('storage:snapshot', function(snap)
    S = snap
    endLocal = GetGameTimer() + (snap.remaining or 0) * 1000
    if snap.state == 'travel' then startTravelBlips() else clearTravelBlips() end
    if snap.state ~= 'round' then deleteProps() end
    if snap.state == 'round' and propsSpawned and propsRound ~= snap.round then deleteProps() end
end)

RegisterNetEvent('storage:me', function(me) Me = me end)

RegisterNetEvent('storage:reset', function()
    S = nil
    Me = { cash = 0, spent = 0, items = 0, best = 0 }
    reportedRound = nil
    deleteProps()
    clearTravelBlips()
end)

RegisterNetEvent('storage:results', function(res)
    local lines = {}
    if res.bestItem then
        lines[#lines + 1] = ('**Best find:** %s sold %s for %s'):format(res.bestItem.name, res.bestItem.label, money(res.bestItem.value))
    else
        lines[#lines + 1] = '**Best find:** nobody sold anything'
    end
    if res.bigSpender then
        lines[#lines + 1] = ('**Biggest spender:** %s (%s)'):format(res.bigSpender.name, money(res.bigSpender.spent))
    else
        lines[#lines + 1] = '**Biggest spender:** nobody bought anything'
    end
    lines[#lines + 1] = '---'
    for i, e in ipairs(res.standings) do
        lines[#lines + 1] = ('%d. %s - cash %s | spent %s | best sale %s'):format(i, e.name, money(e.cash), money(e.spent), money(e.best))
    end
    lines[#lines + 1] = ('*Unsold items were liquidated at %d%%.*'):format(math.floor(Config.LiquidationRate * 100))
    lib.alertDialog({ header = 'Match finished!', content = table.concat(lines, '  \n'), centered = true, size = 'lg' })
end)

-- ===== Menus =====
local function showItems(header, items)
    local lines, total = {}, 0
    for _, it in ipairs(items) do
        lines[#lines + 1] = ('- %s (worth about %s)'):format(it.label, money(it.value))
        total = total + it.value
    end
    if #lines == 0 then lines[1] = 'Nothing here.' end
    lib.alertDialog({ header = header, content = table.concat(lines, '  \n') .. ('  \n\nTotal value: %s'):format(money(total)), centered = true })
end

local function doAction(kind, id)
    if not lib.callback.await('storage:begin', false, kind, id) then
        return notify('You cannot do that right now.', 'error')
    end
    local isOpen = kind == 'open'
    local ok = lib.progressBar({
        duration = isOpen and Config.OpenTimeMs or Config.SearchTimeMs,
        label = isOpen and 'Opening the storage...' or 'Searching for hidden compartments...',
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = { scenario = 'PROP_HUMAN_BUM_BIN' },
    })
    if not ok then return end
    local success, found = lib.callback.await('storage:finish', false, kind, id)
    if not success then return notify('Something went wrong.', 'error') end
    if isOpen then
        showItems('You opened the storage!', found)
    elseif #found == 0 then
        notify('You searched everywhere but found nothing hidden.', 'inform')
    else
        showItems('A hidden compartment!', found)
    end
end

local function openStorageMenu(i)
    local s = S and S.storages and S.storages[i]
    if not s then return end

    local seen = {}
    for _, it in ipairs(s.preview) do seen[#seen + 1] = ('%s (~%s)'):format(it.label, money(it.est)) end
    local options = {
        { title = 'What you can see', description = (#seen > 0 and table.concat(seen, ' | ') or 'Nothing visible') .. '  -  ' .. s.teaser, icon = 'eye', readOnly = true },
    }

    if not s.owner then
        options[#options + 1] = {
            title = ('Buy for %s'):format(money(s.price)), icon = 'gavel',
            onSelect = function()
                local ok, msg = lib.callback.await('storage:buy', false, i)
                notify(msg, ok and 'success' or 'error')
            end,
        }
    elseif s.owner == myId then
        if not s.opened then
            options[#options + 1] = { title = 'Open storage', icon = 'box-open', onSelect = function() doAction('open', i) end }
        elseif not s.searched then
            options[#options + 1] = { title = 'Search for hidden compartments', description = 'Takes time. There might be nothing.', icon = 'magnifying-glass', onSelect = function() doAction('search', i) end }
        else
            options[#options + 1] = { title = 'Nothing left to do here', readOnly = true }
        end
    else
        options[#options + 1] = { title = ('Owned by %s'):format(s.ownerName), icon = 'user', readOnly = true }
    end

    lib.registerContext({ id = 'storage_menu', title = ('Storage #%d'):format(i), options = options })
    lib.showContext('storage_menu')
end

local function openBuyerMenu()
    local inv = lib.callback.await('storage:getInv', false)
    if not inv then return notify('The buyer is too far away.', 'error') end

    local options = {}
    if #inv.items == 0 then
        options[1] = { title = 'You have nothing to sell', readOnly = true }
    else
        local total = 0
        for _, it in ipairs(inv.items) do total = total + it.offer end
        options[1] = {
            title = ('Sell everything - %s'):format(money(total)), icon = 'sack-dollar',
            onSelect = function()
                local ok, paid = lib.callback.await('storage:sellAll', false)
                if ok then notify(('Sold everything for %s.'):format(money(paid)), 'success') end
            end,
        }
        for _, it in ipairs(inv.items) do
            options[#options + 1] = {
                title = ('%s - %s'):format(it.label, money(it.offer)), icon = 'tag',
                onSelect = function()
                    local ok, paid = lib.callback.await('storage:sell', false, it.uid)
                    if ok then notify(('Sold for %s.'):format(money(paid)), 'success') end
                    openBuyerMenu()
                end,
            }
        end
    end
    lib.registerContext({ id = 'storage_buyer', title = ('Buyer (offers x%.2f)'):format(inv.mult), options = options })
    lib.showContext('storage_buyer')
end

local function openLeaderboard()
    local rows = lib.callback.await('storage:leaderboard', false) or {}
    local options = {}
    if #rows == 0 then options[1] = { title = 'No matches played yet', readOnly = true } end
    for i, r in ipairs(rows) do
        options[#options + 1] = {
            title = ('%d. %s'):format(i, r.name),
            description = ('Titles: %d | Best find ever: %s | Matches: %d'):format(
                (tonumber(r.best_wins) or 0) + (tonumber(r.spender_wins) or 0), money(tonumber(r.best_ever) or 0), tonumber(r.matches) or 0),
            readOnly = true,
        }
    end
    lib.registerContext({ id = 'storage_lb', title = 'Leaderboard', menu = 'storage_lobby', options = options })
    lib.showContext('storage_lb')
end

local function openLobbyMenu()
    local info = lib.callback.await('storage:lobbyInfo', false)
    local status
    if info.state == 'idle' then
        status = 'No match yet. Be the first to join!'
    elseif info.state == 'lobby' then
        status = ('Lobby: %d/%d players. %s'):format(info.players, info.max,
            info.countdown and ('Starting in ' .. info.countdown .. 's') or ('Needs ' .. info.min .. ' to start'))
    else
        status = 'A match is in progress.'
    end

    local options = {
        { title = status, description = ('3 rounds. Everyone starts with %s.%s'):format(money(info.startMoney), info.fee > 0 and (' Entry fee: ' .. money(info.fee)) or ''), icon = 'circle-info', readOnly = true },
    }
    if not info.joined and (info.state == 'idle' or info.state == 'lobby') then
        options[#options + 1] = {
            title = 'Join the match', icon = 'right-to-bracket',
            onSelect = function()
                local ok, msg = lib.callback.await('storage:join', false)
                notify(msg, ok and 'success' or 'error')
            end,
        }
    elseif info.joined then
        options[#options + 1] = {
            title = info.state == 'lobby' and 'Leave the lobby' or 'Leave the match (forfeit)', icon = 'right-from-bracket',
            onSelect = function() lib.callback.await('storage:leave', false) notify('You left the match.') end,
        }
    end
    options[#options + 1] = { title = 'Leaderboard', icon = 'trophy', onSelect = openLeaderboard }

    lib.registerContext({ id = 'storage_lobby', title = 'Storage Wars', options = options })
    lib.showContext('storage_lobby')
end

-- ===== Lobby ped & blip =====
CreateThread(function()
    local L = Config.Lobby
    local model = joaat(L.ped)
    lib.requestModel(model)
    local ped = CreatePed(0, model, L.coords.x, L.coords.y, L.coords.z - 1.0, L.coords.w, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(model)

    local blip = AddBlipForCoord(L.coords.x, L.coords.y, L.coords.z)
    SetBlipSprite(blip, L.blip.sprite)
    SetBlipColour(blip, L.blip.colour)
    SetBlipScale(blip, 0.8)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(L.blip.text)
    EndTextCommandSetBlipName(blip)
end)

-- ===== Props lifecycle + arrival report (once per second) =====
CreateThread(function()
    while true do
        Wait(1000)
        local loc = curLoc()
        if S and loc then
            local dist = #(GetEntityCoords(cache.ped) - loc.coords)
            if S.state == 'round' then
                if propsSpawned and propsRound ~= S.round then deleteProps() end
                if dist < 150.0 and not propsSpawned then
                    spawnProps()
                elseif dist > 220.0 and propsSpawned then
                    deleteProps()
                end
            elseif S.state == 'travel' and reportedRound ~= S.round and dist < Config.ArrivalRadius then
                reportedRound = S.round
                TriggerServerEvent('storage:arrived')
            end
        elseif propsSpawned then
            deleteProps()
        end
    end
end)

-- ===== HUD =====
CreateThread(function()
    while true do
        if S and (S.state == 'travel' or S.state == 'round') then
            local left = math.max(0, (endLocal - GetGameTimer()) // 1000)
            local loc = curLoc()
            hudText(0.015, 0.28, ('ROUND %d / %d'):format(S.round, S.rounds), 0.55)
            if S.state == 'travel' then
                hudText(0.015, 0.31, ('Drive to: %s'):format(loc and loc.name or '?'), 0.4)
                hudText(0.015, 0.335, ('Time to arrive: %s'):format(clock(left)), 0.4)
            else
                hudText(0.015, 0.31, ('Time left: %s'):format(clock(left)), 0.4)
            end
            hudText(0.015, 0.36, ('Cash: %s'):format(money(Me.cash)), 0.45)
            hudText(0.015, 0.385, ('Spent: %s'):format(money(Me.spent)), 0.38)
            hudText(0.015, 0.405, ('Items to sell: %d'):format(Me.items), 0.38)
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- ===== Interaction loop (E) =====
CreateThread(function()
    while true do
        local sleep = 500
        local ppos = GetEntityCoords(cache.ped)
        local target, text

        if #(ppos - Config.Lobby.coords.xyz) < 2.5 then
            target, text = { kind = 'lobby' }, '[E] Storage Wars'
        end

        if S and S.state == 'round' and propsSpawned then
            sleep = 250
            local best, bd = nil, 2.3
            for i, pos in pairs(StoragePos) do
                local d = #(ppos - pos)
                if d < 14.0 then
                    sleep = 0
                    local s = S.storages[i]
                    if s then
                        local label = s.owner and ('#%d  SOLD - %s'):format(i, s.ownerName) or ('#%d  %s'):format(i, money(s.price))
                        Draw3D(pos + vec3(0.0, 0.0, 1.1), label)
                    end
                end
                if d < bd then best, bd = i, d end
            end
            if best then target, text = { kind = 'storage', id = best }, ('[E] Storage #%d'):format(best) end
            if buyerPos and #(ppos - buyerPos) < 2.8 then
                target, text = { kind = 'buyer' }, '[E] Sell items'
            end
        end

        local key = target and (target.kind .. (target.id or '')) or nil
        if key ~= promptKey then
            promptKey = key
            if key then lib.showTextUI(text) else lib.hideTextUI() end
        end

        if target then
            sleep = 0
            if IsControlJustReleased(0, 38) then
                CreateThread(function()
                    if target.kind == 'lobby' then openLobbyMenu()
                    elseif target.kind == 'storage' then openStorageMenu(target.id)
                    elseif target.kind == 'buyer' then openBuyerMenu() end
                end)
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    deleteProps()
    clearTravelBlips()
    lib.hideTextUI()
end)
