local currentAuction = nil
local spawnedProps = {}
local spawnedVehicle = nil
local barrierProp = nil
local isSaleActive = false

-- Spawn Blips & Join Setup
Citizen.CreateThread(function()
    local spawn = Config.SpawnPointOnJoin
    SetEntityCoords(PlayerPedId(), spawn.x, spawn.y, spawn.z, false, false, false, true)
    SetEntityHeading(PlayerPedId(), spawn.w)

    for _, loc in ipairs(Config.Locations) do
        local blip = AddBlipForCoord(loc.coords.x, loc.coords.y, loc.coords.z)
        SetBlipSprite(blip, Config.Blip.Sprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, Config.Blip.Scale)
        SetBlipColour(blip, Config.Blip.Color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(loc.label)
        EndTextCommandSetBlipName(blip)
    end
end)

-- UI Display Event
RegisterNetEvent('storage_auction:client:startAuction', function(data)
    currentAuction = data
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openAuction",
        title = data.type == 'garage' and Shared.Lang.bonus_auction_title or Shared.Lang.auction_title,
        label = data.label,
        currentBid = data.currentBid or 0,
        bidder = data.bidderName or Shared.Lang.no_bids,
        timeLeft = data.timeLeft or Config.AuctionTimer
    })
    
    -- Clear and setup props/barriers
    ClearAuctionScene()
    SetupAuctionScene(data)
end)

RegisterNetEvent('storage_auction:client:updateBid', function(newBid, bidderName)
    SendNUIMessage({
        action = "updateBid",
        currentBid = newBid,
        bidder = bidderName
    })
end)

RegisterNetEvent('storage_auction:client:endAuction', function(winnerName, isWinner)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "closeAuction" })
    
    if barrierProp then
        DeleteEntity(barrierProp)
        barrierProp = nil
    end

    if isWinner then
        isSaleActive = true
        TriggerEvent('chat:addMessage', { args = { '^2[Аукцион]', 'Вы выиграли этот лот! Продайте вещи в точке рядом.' } })
    end
end)

function ClearAuctionScene()
    for _, prop in ipairs(spawnedProps) do
        if DoesEntityExist(prop) then DeleteEntity(prop) end
    end
    spawnedProps = {}
    if DoesEntityExist(spawnedVehicle) then DeleteEntity(spawnedVehicle) end
    spawnedVehicle = nil
    if DoesEntityExist(barrierProp) then DeleteEntity(barrierProp) end
    barrierProp = nil
end

function SetupAuctionScene(data)
    -- Collision Barrier preventing players from entering container/garage
    local barrierHash = `prop_worklight_03b` -- Solid invisible collision barrier prop
    RequestModel(barrierHash)
    while not HasModelLoaded(barrierHash) do Wait(10) end
    
    barrierProp = CreateObject(barrierHash, data.coords.x + data.barrierOffset.x, data.coords.y + data.barrierOffset.y, data.coords.z, false, false, false)
    SetEntityVisible(barrierProp, false, false)
    FreezeEntityPosition(barrierProp, true)

    -- Spawn Fast Vehicle if exists
    if data.hasVehicle and data.vehicleModel then
        RequestModel(data.vehicleModel)
        while not HasModelLoaded(data.vehicleModel) do Wait(10) end
        spawnedVehicle = CreateVehicle(data.vehicleModel, data.vehiclePos.x, data.vehiclePos.y, data.vehiclePos.z, data.vehiclePos.w, false, false)
        FreezeEntityPosition(spawnedVehicle, true)
        Shared.FastVehicleUpgrades(spawnedVehicle)
    end

    -- Spawn Closet/Cabinet Cover if active (super lucky secret)
    if data.hasCloset then
        local closetModel = Shared.ClosetProps[math.random(#Shared.ClosetProps)]
        RequestModel(closetModel)
        while not HasModelLoaded(closetModel) do Wait(10) end
        local closet = CreateObject(closetModel, data.coords.x, data.coords.y, data.coords.z, false, false, false)
        FreezeEntityPosition(closet, true)
        table.insert(spawnedProps, closet)
    end

    -- Random Covers (Tarp) over 30-50% items
    if data.hasCover and math.random(1, 100) > 40 then
        local tarpModel = Shared.CoverProps[math.random(#Shared.CoverProps)]
        RequestModel(tarpModel)
        while not HasModelLoaded(tarpModel) do Wait(10) end
        local tarp = CreateObject(tarpModel, data.coords.x + 0.5, data.coords.y + 0.5, data.coords.z + 0.2, false, false, false)
        FreezeEntityPosition(tarp, true)
        table.insert(spawnedProps, tarp)
    end
end

-- NUI Callbacks
RegisterNUICallback('placeBid', function(data, cb)
    TriggerServerEvent('storage_auction:server:placeBid', data.amount)
    cb('ok')
end)

RegisterNUICallback('skipSale', function(data, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "closeAuction" })
    TriggerServerEvent('storage_auction:server:playerSkipped')
    cb('ok')
end)
