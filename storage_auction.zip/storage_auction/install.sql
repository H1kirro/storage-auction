CREATE TABLE IF NOT EXISTS `storage_auctions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `winner_identifier` varchar(50) DEFAULT NULL,
  `winning_bid` int(11) NOT NULL DEFAULT 0,
  `location_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
