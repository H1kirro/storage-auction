fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'storage_auction'
description 'Storage Wars: 3-round multiplayer storage auction match'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'shared.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

client_script 'client.lua'

dependencies {
    'ox_lib',
    'oxmysql'
}
