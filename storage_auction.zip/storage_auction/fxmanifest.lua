fx_version 'cerulean'
game 'gta5'

name 'storage_auction'
author 'GTA FiveM Storage Auction'
description 'Storage Auction System with Garages, Speed Tuned Cars, Covers, Collision Barriers and RU UI'
version '2.0.0'

ui_page 'html/index.html'

shared_scripts {
    'shared.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}
