-- ===== Optional framework bridge (entry fee + prizes only) =====
local ESX, QBCore
if Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
end

local Bridge = {}

function Bridge.Remove(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return true end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if not p or p.getMoney() < amount then return false end
        p.removeMoney(amount)
        return true
    end
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return false end
    return p.Functions.RemoveMoney(Config.QBAccount, amount, 'storage-wars-entry')
end

function Bridge.Add(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if p then p.addMoney(amount) end
    else
        local p = QBCore.Functions.GetPlayer(src)
        if p then p.Functions.AddMoney(Config.QBAccount, amount, 'storage-wars-prize') end
    end
end

-- ===== State =====
local Match
local lotCounter = 0
local lastJoinable = nil
local startTravel, finishMatch, startLot, goBetween -- forward declarations

local function newMatch()
    local containers = {}
    for i, R in ipairs(Config.Rounds) do containers[i] = R.containers end
    return {
        state = 'idle',          -- idle | lobby | travel | round | ended
        players = {},
        host = nil,
        settings = { containers = containers },
        round = 0, locIdx = 0, loc = nil, farIdx = 1,
        phase = nil,             -- preview | bidding | looting | between | final
        endsAt = 0,
        lotIdx = 0, lot = nil,
        bid = { amount = 0 },
    }
end
Match = newMatch()

local function notify(src, msg, nType)
    TriggerClientEvent('storage:toast', src, msg, nType or 'info')
end

local function notifyAll(msg, nType)
    for src in pairs(Match.players) do notify(src, msg, nType) end
end

local function playerCount()
    local n = 0
    for _ in pairs(Match.players) do n = n + 1 end
    return n
end

local function dist2D(src, pos)
    if not Config.ServerDistanceChecks then return 0.0 end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return 1e9 end
    local c = GetEntityCoords(ped)
    return #(vec2(c.x, c.y) - vec2(pos.x, pos.y))
end

local function getLicense(src)
    return GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
end

local function updateJoinable()
    local j = (Match.state == 'idle' or Match.state == 'lobby')
    if j ~= lastJoinable then
        lastJoinable = j
        TriggerClientEvent('storage:joinable', -1, j)
    end
end

local function replaceMatch()
    Match = newMatch()
    updateJoinable()
end

-- ===== Lobby =====
local function lobbyInfo(src)
    local list = {}
    for s, p in pairs(Match.players) do
        list[#list + 1] = { name = p.name, host = (s == Match.host) }
    end
    return {
        state = Match.state, players = list, count = #list,
        min = Config.MinPlayers, max = Config.MaxPlayers,
        joined = Match.players[src] ~= nil, isHost = (Match.host == src),
        fee = Config.EntryFee, startMoney = Config.StartMoney,
        rounds = #Config.Rounds, containers = Match.settings.containers,
        maxContainers = Config.MaxContainers,
    }
end

local function pushLobby()
    for src in pairs(Match.players) do
        TriggerClientEvent('storage:lobbyUpdate', src, lobbyInfo(src))
    end
end

-- ===== Lot generation =====
local function pickTier()
    local total = 0
    for _, t in ipairs(Config.Tiers) do total = total + t.chance end
    local r = math.random() * total
    for _, t in ipairs(Config.Tiers) do
        r = r - t.chance
        if r <= 0 then return t end
    end
    return Config.Tiers[1]
end

local function pickKind(kinds)
    local total = 0
    for _, w in pairs(kinds) do total = total + w end
    local r = math.random() * total
    for k, w in pairs(kinds) do
        r = r - w
        if r <= 0 then return k end
    end
    return next(kinds)
end

local function rollLoot(tier, rareOnly)
    local total, weights = 0, {}
    for i, item in ipairs(Config.Loot) do
        local w
        if rareOnly then
            w = item.rare and item.weight or 0
        else
            w = item.weight * (item.rare and tier.luck or 1.0)
        end
        weights[i] = w
        total = total + w
    end
    local r = math.random() * total
    for i, item in ipairs(Config.Loot) do
        if weights[i] > 0 then
            r = r - weights[i]
            if r <= 0 then return item end
        end
    end
    return Config.Loot[1]
end

local function buildLot(roundIdx)
    local R = Config.Rounds[roundIdx]
    local kind = pickKind(R.kinds)
    local T = Config.LotTypes[kind]
    local cols, rows = GetGrid(kind)
    local tier = pickTier()

    lotCounter = lotCounter + 1
    local lot = {
        id = lotCounter, kind = kind, colorIdx = math.random(#T.colors), tier = tier.name,
        items = {}, owner = nil, ownerName = nil,
    }

    local occ, uid = {}, 0
    local function free(c, r)
        return c >= 1 and c <= cols and r >= 1 and r <= rows and not occ[c * 100 + r]
    end
    local function add(entry, c, r, hiddenBy)
        uid = uid + 1
        local lx, ly = GetSlotPos(kind, c, r)
        local value = math.floor((entry.min + math.random() * (entry.max - entry.min)) * R.valueScale)
        local it = {
            uid = uid, label = entry.label, model = entry.model, value = value,
            lx = lx + (math.random() - 0.5) * 0.2, ly = ly + (math.random() - 0.5) * 0.2,
            heading = math.random(0, 359) + 0.0,
            hiddenBy = hiddenBy, revealed = (hiddenBy == nil), picked = false,
        }
        occ[c * 100 + r] = true
        lot.items[#lot.items + 1] = it
        return it
    end

    -- valuables hidden directly behind a cover prop
    local pairsN = math.floor(math.random(R.hiddenMin, R.hiddenMax) * tier.hiddenMul + 0.5)
    for _ = 1, pairsN do
        for _ = 1, 25 do
            local c, r = math.random(cols), math.random(math.max(1, rows - 1))
            if free(c, r) and free(c, r + 1) then
                local cover = add(Config.Covers[math.random(#Config.Covers)], c, r, nil)
                add(rollLoot(tier, true), c, r + 1, cover.uid)
                break
            end
        end
    end

    -- normal items in random free slots
    local slots = {}
    for c = 1, cols do
        for r = 1, rows do
            if free(c, r) then slots[#slots + 1] = { c, r } end
        end
    end
    for i = #slots, 2, -1 do
        local j = math.random(i)
        slots[i], slots[j] = slots[j], slots[i]
    end
    local count = math.min(math.random(R.itemsMin, R.itemsMax), #slots)
    for i = 1, count do
        add(rollLoot(tier, false), slots[i][1], slots[i][2], nil)
    end

    local sp = R.startMin + math.random() * (R.startMax - R.startMin)
    lot.startPrice = math.max(50, math.floor(sp / 50 + 0.5) * 50)
    return lot
end

-- ===== Sync to clients =====
local function lotPublic()
    local lot = Match.lot
    local list = {}
    for _, it in ipairs(lot.items) do
        if it.revealed and not it.picked then
            list[#list + 1] = { uid = it.uid, model = it.model, label = it.label, lx = it.lx, ly = it.ly, heading = it.heading }
        end
    end
    return { id = lot.id, kind = lot.kind, colorIdx = lot.colorIdx, startPrice = lot.startPrice, items = list }
end

local function broadcast()
    updateJoinable()
    local R = Config.Rounds[Match.round]
    local snap = {
        state = Match.state, phase = Match.phase, round = Match.round, rounds = #Config.Rounds,
        remaining = math.max(0, Match.endsAt - os.time()),
        locIdx = Match.locIdx, farIdx = Match.farIdx, lotIdx = Match.lotIdx,
        lotCount = Match.round > 0 and Match.settings.containers[Match.round] or 0,
        steps = R and R.steps or {},
        bid = { amount = Match.bid.amount, bidder = Match.bid.bidder, bidderName = Match.bid.bidderName },
    }
    local ph = Match.phase
    if Match.state == 'round' and Match.lot and (ph == 'preview' or ph == 'bidding' or ph == 'looting') then
        snap.lot = lotPublic()
        snap.lotOwner = Match.lot.owner
        snap.lotOwnerName = Match.lot.ownerName
    end
    for src in pairs(Match.players) do TriggerClientEvent('storage:snapshot', src, snap) end
end

local function syncMe(src)
    local p = Match.players[src]
    if p then
        TriggerClientEvent('storage:me', src, { cash = p.cash, spent = p.spent, items = #p.items, best = p.bestSold })
    end
end

local function syncAllMe()
    for src in pairs(Match.players) do syncMe(src) end
end

-- ===== Match flow =====
local function resetMatch()
    for src in pairs(Match.players) do TriggerClientEvent('storage:reset', src) end
    replaceMatch()
end

startTravel = function(n)
    local R = Config.Rounds[n]
    Match.state = 'travel'
    Match.round = n
    Match.phase = nil
    Match.lot = nil
    Match.lotIdx = 0
    Match.bid = { amount = 0 }
    Match.locIdx = math.random(#R.locations)
    Match.loc = R.locations[Match.locIdx]
    Match.farIdx = math.random(#Config.FarBuyers)
    Match.endsAt = os.time() + R.travelSeconds
    for src, p in pairs(Match.players) do
        p.arrived = false
        if Config.SpawnTravelVehicle then
            TriggerClientEvent('storage:spawnCar', src, Config.TravelVehicles[math.random(#Config.TravelVehicles)])
        end
    end
    broadcast()
    syncAllMe()
    notifyAll(('Round %d: drive to %s. The round starts when everyone has arrived.'):format(n, Match.loc.name), 'success')
    notifyAll(('The %s (pays x%.1f) is marked on your map.'):format(Config.FarBuyers[Match.farIdx].name, Config.FarBuyerMult))
end

startLot = function(i)
    Match.lotIdx = i
    Match.lot = buildLot(Match.round)
    Match.phase = 'preview'
    Match.bid = { amount = Match.lot.startPrice }
    Match.endsAt = os.time() + Config.Auction.previewSeconds
    broadcast()
end

local function beginRound()
    Match.state = 'round'
    startLot(1)
end

local function toBidding()
    Match.phase = 'bidding'
    Match.endsAt = os.time() + Config.Auction.firstBidSeconds
    broadcast()
end

goBetween = function()
    Match.phase = 'between'
    Match.endsAt = os.time() + Config.Auction.betweenSeconds
    broadcast()
end

local function goFinal()
    Match.phase = 'final'
    Match.lot = nil
    Match.endsAt = os.time() + Config.Auction.finalSellSeconds
    broadcast()
    notifyAll('Final call! Sell your loot before the round ends.', 'success')
end

local function closeBidding()
    local b = Match.bid
    local winner = b.bidder and Match.players[b.bidder]
    if winner and winner.cash >= b.amount then
        winner.cash = winner.cash - b.amount
        winner.spent = winner.spent + b.amount
        Match.lot.owner = b.bidder
        Match.lot.ownerName = winner.name
        Match.phase = 'looting'
        Match.endsAt = os.time() + Config.Auction.lootSeconds
        syncMe(b.bidder)
        broadcast()
        notifyAll(('%s won the lot for $%d!'):format(winner.name, b.amount), 'success')
    else
        notifyAll('No bids. The lot is withdrawn.')
        goBetween()
    end
end

local function nextLot()
    if Match.lotIdx < Match.settings.containers[Match.round] then
        startLot(Match.lotIdx + 1)
    else
        goFinal()
    end
end

local function endRound()
    if Match.round < #Config.Rounds then
        startTravel(Match.round + 1)
    else
        finishMatch()
    end
end

local function startMatch()
    for _, p in pairs(Match.players) do
        p.cash = Config.StartMoney
        p.spent, p.soldTotal, p.bestSold, p.bestLabel = 0, 0, 0, nil
        p.items = {}
    end
    startTravel(1)
end

finishMatch = function()
    Match.state = 'ended'
    Match.phase = nil
    Match.lot = nil
    Match.endsAt = os.time() + Config.ResultsSeconds

    local list, bestWinner, spenderWinner = {}, nil, nil
    for src, p in pairs(Match.players) do
        local liquidated = 0
        for _, it in ipairs(p.items) do
            liquidated = liquidated + math.floor(it.value * Config.LiquidationRate)
        end
        p.cash = p.cash + liquidated
        p.items = {}
        local e = {
            src = src, license = p.license, name = p.name, cash = p.cash, spent = p.spent,
            soldTotal = p.soldTotal, bestSold = p.bestSold, bestLabel = p.bestLabel, liquidated = liquidated,
        }
        list[#list + 1] = e
        if e.bestSold > 0 and (not bestWinner or e.bestSold > bestWinner.bestSold) then bestWinner = e end
        if e.spent > 0 and (not spenderWinner or e.spent > spenderWinner.spent) then spenderWinner = e end
    end
    table.sort(list, function(a, b) return a.cash > b.cash end)

    for _, e in ipairs(list) do
        MySQL.insert([[INSERT INTO storage_results
            (license, name, spent, final_cash, sold_total, best_item_label, best_item_value, won_best_item, won_big_spender)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)]],
            { e.license, e.name, e.spent, e.cash, e.soldTotal, e.bestLabel, e.bestSold,
              (bestWinner == e) and 1 or 0, (spenderWinner == e) and 1 or 0 })
    end

    if bestWinner then Bridge.Add(bestWinner.src, Config.Prizes.bestItem) end
    if spenderWinner then Bridge.Add(spenderWinner.src, Config.Prizes.bigSpender) end

    local res = { standings = {}, liquidation = math.floor(Config.LiquidationRate * 100) }
    if bestWinner then
        res.bestItem = { name = bestWinner.name, label = bestWinner.bestLabel, value = bestWinner.bestSold }
    end
    if spenderWinner then
        res.bigSpender = { name = spenderWinner.name, spent = spenderWinner.spent }
    end
    for _, e in ipairs(list) do
        res.standings[#res.standings + 1] = {
            name = e.name, cash = e.cash, spent = e.spent, best = e.bestSold, liquidated = e.liquidated,
        }
    end

    broadcast()
    for src in pairs(Match.players) do TriggerClientEvent('storage:results', src, res) end

    SetTimeout(Config.ResultsSeconds * 1000, function()
        if Match.state == 'ended' then resetMatch() end
    end)
end

local function lootRemaining(lot)
    for _, it in ipairs(lot.items) do
        if not it.picked and it.revealed then return true end
        if not it.picked and not it.revealed then
            -- hidden item whose cover is still there counts as remaining
            return true
        end
    end
    return false
end

CreateThread(function()
    math.randomseed(os.time())
    while true do
        Wait(1000)
        local now = os.time()
        if Match.state == 'travel' then
            local all = true
            for _, p in pairs(Match.players) do
                if not p.arrived then all = false break end
            end
            if all or now >= Match.endsAt then beginRound() end
        elseif Match.state == 'round' then
            local ph = Match.phase
            if ph == 'looting' and Match.lot and not Match.players[Match.lot.owner] then
                goBetween()
            elseif now >= Match.endsAt then
                if ph == 'preview' then toBidding()
                elseif ph == 'bidding' then closeBidding()
                elseif ph == 'looting' then goBetween()
                elseif ph == 'between' then nextLot()
                elseif ph == 'final' then endRound() end
            end
        end
    end
end)

local function removePlayer(src, refund)
    local p = Match.players[src]
    if not p then return end
    if refund and Match.state == 'lobby' then Bridge.Add(src, p.paid) end
    Match.players[src] = nil
    if Match.host == src then Match.host = next(Match.players) end
    if next(Match.players) == nil and Match.state ~= 'ended' then
        replaceMatch()
    else
        pushLobby()
    end
end

AddEventHandler('playerDropped', function()
    removePlayer(source, false)
end)

-- ===== Lobby callbacks =====
lib.callback.register('storage:isJoinable', function()
    return Match.state == 'idle' or Match.state == 'lobby'
end)

lib.callback.register('storage:lobbyInfo', function(src)
    return lobbyInfo(src)
end)

lib.callback.register('storage:join', function(src)
    if Match.state ~= 'idle' and Match.state ~= 'lobby' then return false, 'A match is already running.' end
    if Match.players[src] then return false, 'You already joined.' end
    if playerCount() >= Config.MaxPlayers then return false, 'The lobby is full.' end
    if not Bridge.Remove(src, Config.EntryFee) then return false, 'You cannot afford the entry fee.' end

    Match.players[src] = {
        name = GetPlayerName(src), license = getLicense(src), paid = Config.EntryFee,
        cash = 0, spent = 0, items = {}, nextUid = 0, soldTotal = 0, bestSold = 0, bestLabel = nil, arrived = false,
    }
    if not Match.host then Match.host = src end
    Match.state = 'lobby'
    updateJoinable()
    pushLobby()
    return true, 'You joined the lobby.'
end)

lib.callback.register('storage:leave', function(src)
    if not Match.players[src] then return false end
    removePlayer(src, true)
    TriggerClientEvent('storage:reset', src)
    return true
end)

lib.callback.register('storage:setContainers', function(src, round, value)
    if Match.host ~= src or Match.state ~= 'lobby' then return false end
    round = math.floor(tonumber(round) or 0)
    value = math.floor(tonumber(value) or 0)
    if round < 1 or round > #Config.Rounds then return false end
    Match.settings.containers[round] = math.max(1, math.min(Config.MaxContainers, value))
    pushLobby()
    return true
end)

lib.callback.register('storage:start', function(src)
    if Match.host ~= src or Match.state ~= 'lobby' then return false, 'Only the host can start the match.' end
    if playerCount() < Config.MinPlayers then
        return false, ('You need at least %d players.'):format(Config.MinPlayers)
    end
    startMatch()
    return true
end)

lib.callback.register('storage:leaderboard', function()
    return MySQL.query.await([[SELECT MAX(name) AS name, COUNT(*) AS matches,
        SUM(won_best_item) AS best_wins, SUM(won_big_spender) AS spender_wins, MAX(best_item_value) AS best_ever
        FROM storage_results GROUP BY license
        ORDER BY (SUM(won_best_item) + SUM(won_big_spender)) DESC, best_ever DESC LIMIT 10]])
end)

-- ===== Travel =====
RegisterNetEvent('storage:arrived', function()
    local src = source
    local p = Match.players[src]
    if not p or Match.state ~= 'travel' or p.arrived then return end
    if dist2D(src, Match.loc.coords) > Config.ArrivalRadius + 40.0 then return end
    p.arrived = true
    notify(src, 'You arrived. Waiting for the others...', 'success')
end)

local carCooldown = {}
RegisterCommand('storagecar', function(src)
    if src == 0 then return end
    if not Match.players[src] or Match.state ~= 'travel' then return end
    local now = os.time()
    if carCooldown[src] and now - carCooldown[src] < 45 then
        return notify(src, 'Wait a bit before requesting another car.', 'error')
    end
    carCooldown[src] = now
    TriggerClientEvent('storage:spawnCar', src, Config.TravelVehicles[math.random(#Config.TravelVehicles)])
end, false)

-- ===== Auction =====
local function containerCenter()
    local depth = Config.LotTypes[Match.lot.kind].depth
    return LocalToWorld(Match.loc, 0.0, depth / 2)
end

lib.callback.register('storage:bid', function(src, stepIdx)
    local p = Match.players[src]
    if not p or Match.state ~= 'round' or Match.phase ~= 'bidding' or not Match.lot then
        return false, 'Bidding is not open.'
    end
    local R = Config.Rounds[Match.round]
    local step = R.steps[math.floor(tonumber(stepIdx) or 0)]
    if not step then return false end
    if dist2D(src, containerCenter()) > Config.Auction.bidRadius then
        return false, 'You are too far from the auction.'
    end
    if Match.bid.bidder == src then return false, 'You already have the highest bid.' end

    local base = Match.bid.bidder and Match.bid.amount or Match.lot.startPrice
    local amount = base + step
    if amount > p.cash then return false, 'Not enough money.' end

    Match.bid = { amount = amount, bidder = src, bidderName = p.name }
    Match.endsAt = math.max(Match.endsAt, os.time() + Config.Auction.resetSeconds)
    broadcast()
    return true
end)

local function addItem(p, it)
    p.nextUid = p.nextUid + 1
    p.items[#p.items + 1] = { uid = p.nextUid, label = it.label, value = it.value }
end

lib.callback.register('storage:pickup', function(src, uid)
    local p = Match.players[src]
    local lot = Match.lot
    if not p or Match.state ~= 'round' or Match.phase ~= 'looting' or not lot or lot.owner ~= src then
        return false
    end
    uid = math.floor(tonumber(uid) or 0)
    local item
    for _, it in ipairs(lot.items) do
        if it.uid == uid and it.revealed and not it.picked then item = it break end
    end
    if not item then return false end

    item.picked = true
    addItem(p, item)

    local revealed = 0
    for _, h in ipairs(lot.items) do
        if h.hiddenBy == uid and not h.revealed then
            h.revealed = true
            revealed = revealed + 1
        end
    end

    syncMe(src)
    if not lootRemaining(lot) then Match.endsAt = os.time() + 1 end
    broadcast()
    return true, { label = item.label, value = item.value }, revealed
end)

lib.callback.register('storage:finishLoot', function(src)
    if Match.state == 'round' and Match.phase == 'looting' and Match.lot and Match.lot.owner == src then
        Match.endsAt = os.time()
        return true
    end
    return false
end)

-- ===== Selling =====
local function buyerPos(which)
    if which == 'far' then
        local fb = Config.FarBuyers[Match.farIdx]
        return fb and fb.coords
    end
    if Match.loc then return LocalToWorld(Match.loc, Config.Layout.buyer.x, Config.Layout.buyer.y) end
end

local function canTrade(src, which)
    if which ~= 'far' and which ~= 'local' then return false end
    if Match.state ~= 'round' and Match.state ~= 'travel' then return false end
    if which == 'local' and Match.state ~= 'round' then return false end
    local pos = buyerPos(which)
    if not pos then return false end
    return dist2D(src, pos) <= Config.InteractRadius + 3.0
end

local function multFor(which)
    return which == 'far' and Config.FarBuyerMult or Config.LocalBuyerMult
end

local function registerSale(p, it, mult)
    local price = math.floor(it.value * mult)
    p.cash = p.cash + price
    p.soldTotal = p.soldTotal + price
    if price > p.bestSold then
        p.bestSold, p.bestLabel = price, it.label
    end
    if price >= Config.BigSaleAnnounce then
        notifyAll(('%s sold %s for $%d!'):format(p.name, it.label, price), 'success')
    end
    return price
end

lib.callback.register('storage:getInv', function(src, which)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return nil end
    local mult = multFor(which)
    local out = {}
    for _, it in ipairs(p.items) do
        out[#out + 1] = { uid = it.uid, label = it.label, offer = math.floor(it.value * mult) }
    end
    local title = which == 'far' and Config.FarBuyers[Match.farIdx].name or 'Local buyer'
    return { items = out, mult = mult, title = title }
end)

lib.callback.register('storage:sell', function(src, which, uid)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return false end
    uid = tonumber(uid)
    for i, it in ipairs(p.items) do
        if it.uid == uid then
            table.remove(p.items, i)
            local price = registerSale(p, it, multFor(which))
            syncMe(src)
            return true, price
        end
    end
    return false
end)

lib.callback.register('storage:sellAll', function(src, which)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return false end
    local total = 0
    local mult = multFor(which)
    for _, it in ipairs(p.items) do total = total + registerSale(p, it, mult) end
    p.items = {}
    syncMe(src)
    return true, total
end)
