local activeAuction = nil
local bids = {}
local readyPlayers = {}

RegisterCommand('startauction', function(source, args)
    local locId = tonumber(args[1]) or 1
    local location = Config.Locations[locId]
    if not location then return end

    activeAuction = {
        id = location.id,
        label = location.label,
        type = location.type,
        currentBid = 1000,
        bidder = nil,
        bidderName = "Нет",
        timeLeft = Config.AuctionTimer,
        coords = location.coords,
        barrierOffset = location.barrierOffset,
        hasVehicle = location.hasVehicle,
        vehicleModel = location.vehicleModel,
        vehiclePos = location.vehiclePos,
        hasCover = location.hasCover,
        hasCloset = location.hasCloset
    }

    TriggerClientEvent('storage_auction:client:startAuction', -1, activeAuction)

    Citizen.CreateThread(function()
        while activeAuction and activeAuction.timeLeft > 0 do
            Wait(1000)
            activeAuction.timeLeft = activeAuction.timeLeft - 1
        end

        if activeAuction then
            local winner = activeAuction.bidder
            local winnerName = activeAuction.bidderName
            for _, pid in ipairs(GetPlayers()) do
                local isWinner = (tonumber(pid) == winner)
                TriggerClientEvent('storage_auction:client:endAuction', pid, winnerName, isWinner)
            end
            activeAuction = nil
        end
    end)
end, true)

RegisterNetEvent('storage_auction:server:placeBid', function(amount)
    local src = source
    if not activeAuction then return end
    
    local name = GetPlayerName(src)
    if amount > activeAuction.currentBid then
        activeAuction.currentBid = amount
        activeAuction.bidder = src
        activeAuction.bidderName = name
        TriggerClientEvent('storage_auction:client:updateBid', -1, amount, name)
    end
end)

RegisterNetEvent('storage_auction:server:playerSkipped', function()
    local src = source
    readyPlayers[src] = true
    
    local allReady = true
    for _, pid in ipairs(GetPlayers()) do
        if not readyPlayers[pid] then
            allReady = false
            break
        end
    end

    if allReady and activeAuction then
        activeAuction.timeLeft = 0
    end
end)
