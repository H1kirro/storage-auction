-- ===== Optional framework bridge (entry fee + prizes only) =====
local ESX, QBCore
if Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
end

local Bridge = {}

function Bridge.Remove(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return true end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if not p or p.getMoney() < amount then return false end
        p.removeMoney(amount)
        return true
    end
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return false end
    return p.Functions.RemoveMoney(Config.QBAccount, amount, 'storage-wars-entry')
end

function Bridge.Add(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if p then p.addMoney(amount) end
    else
        local p = QBCore.Functions.GetPlayer(src)
        if p then p.Functions.AddMoney(Config.QBAccount, amount, 'storage-wars-prize') end
    end
end

-- ===== Match state =====
local Match

local function newMatch()
    return {
        state = 'idle',      -- idle | lobby | travel | round | ended
        players = {},
        round = 0,
        locIdx = 0,
        loc = nil,
        storages = {},
        buyerMult = 1.0,
        endsAt = 0,
        lobbyEndsAt = nil,
    }
end
Match = newMatch()

local function notify(src, msg, nType)
    TriggerClientEvent('ox_lib:notify', src, { description = msg, type = nType or 'inform' })
end

local function notifyAll(msg, nType)
    for src in pairs(Match.players) do notify(src, msg, nType) end
end

local function playerCount()
    local n = 0
    for _ in pairs(Match.players) do n = n + 1 end
    return n
end

local function dist2D(src, pos)
    if not Config.ServerDistanceChecks then return 0.0 end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return 1e9 end
    local c = GetEntityCoords(ped)
    return #(vec2(c.x, c.y) - vec2(pos.x, pos.y))
end

local function getLicense(src)
    return GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
end

-- ===== Loot generation =====
local function pickTier()
    local total = 0
    for _, t in ipairs(Config.Tiers) do total = total + t.chance end
    local r = math.random() * total
    for _, t in ipairs(Config.Tiers) do
        r = r - t.chance
        if r <= 0 then return t end
    end
    return Config.Tiers[1]
end

local function makeItem(tier, round, concealed)
    local total, weights = 0, {}
    for i, item in ipairs(Config.Loot) do
        local w = 0
        if concealed then
            w = item.rare and item.weight or 0
        else
            w = item.weight * (item.rare and tier.luck or 1.0)
        end
        weights[i] = w
        total = total + w
    end
    local r = math.random() * total
    local chosen = Config.Loot[1]
    for i, item in ipairs(Config.Loot) do
        r = r - weights[i]
        if r <= 0 and weights[i] > 0 then chosen = item break end
    end
    local value = math.floor((chosen.min + math.random() * (chosen.max - chosen.min)) * round.valueScale)
    local est = math.floor(value * (0.75 + math.random() * 0.5) / 10 + 0.5) * 10
    return { label = chosen.label, value = value, est = est }
end

local function buildStorages(n)
    local R = Config.Rounds[n]
    local count = math.max(3, math.min(20, math.random(R.storageMin, R.storageMax)))
    local list = {}
    for i = 1, count do
        local tier = pickTier()
        local price = R.priceMin + math.random() * (R.priceMax - R.priceMin)
        price = price * tier.priceMul * (1 + (math.random() * 2 - 1) * Config.PriceNoise)
        price = math.max(100, math.floor(price / 10 + 0.5) * 10)

        local items = {}
        for _ = 1, math.random(R.itemsMin, R.itemsMax) do
            items[#items + 1] = makeItem(tier, R, false)
        end
        local concealed = {}
        if math.random() < R.concealedChance then
            concealed[1] = makeItem(tier, R, true)
        end

        list[i] = {
            id = i, price = price, tier = tier.name,
            teaser = Config.Teasers[math.random(#Config.Teasers)],
            items = items, concealed = concealed,
            owner = nil, ownerName = nil, opened = false, searched = false,
        }
    end
    return list
end

-- ===== Sync to clients =====
local function storagePublic(s)
    local pv = {}
    for i = 1, math.min(Config.PreviewItems, #s.items) do
        pv[#pv + 1] = { label = s.items[i].label, est = s.items[i].est }
    end
    return {
        id = s.id, price = s.price, teaser = s.teaser, preview = pv,
        owner = s.owner, ownerName = s.ownerName, opened = s.opened, searched = s.searched,
    }
end

local function broadcast()
    local snap = {
        state = Match.state, round = Match.round, rounds = #Config.Rounds,
        remaining = math.max(0, Match.endsAt - os.time()),
        locIdx = Match.locIdx, buyerMult = Match.buyerMult, storages = {},
    }
    if Match.state == 'round' then
        for _, s in ipairs(Match.storages) do snap.storages[#snap.storages + 1] = storagePublic(s) end
    end
    for src in pairs(Match.players) do TriggerClientEvent('storage:snapshot', src, snap) end
end

local function syncMe(src)
    local p = Match.players[src]
    if p then
        TriggerClientEvent('storage:me', src, { cash = p.cash, spent = p.spent, items = #p.items, best = p.bestSold })
    end
end

local function syncAllMe()
    for src in pairs(Match.players) do syncMe(src) end
end

-- ===== Match flow =====
local function resetMatch()
    for src in pairs(Match.players) do TriggerClientEvent('storage:reset', src) end
    Match = newMatch()
end

local function startTravel(n)
    local R = Config.Rounds[n]
    Match.round = n
    Match.locIdx = math.random(#R.locations)
    Match.loc = R.locations[Match.locIdx]
    Match.storages = buildStorages(n)
    Match.buyerMult = math.floor((0.9 + math.random() * 0.25) * 100) / 100
    Match.state = 'travel'
    Match.endsAt = os.time() + R.travelSeconds
    for _, p in pairs(Match.players) do p.arrived = false end
    broadcast()
    syncAllMe()
    notifyAll(('Round %d: drive to %s! A waypoint has been set.'):format(n, Match.loc.name), 'success')
end

local function beginRound()
    Match.state = 'round'
    Match.endsAt = os.time() + Config.Rounds[Match.round].seconds
    broadcast()
    notifyAll(('Round %d started! %d storages are up for grabs.'):format(Match.round, #Match.storages), 'success')
end

local function finishMatch()
    Match.state = 'ended'
    Match.endsAt = os.time() + Config.ResultsSeconds

    local list, bestWinner, spenderWinner = {}, nil, nil
    for src, p in pairs(Match.players) do
        local liquidated = 0
        for _, it in ipairs(p.items) do
            liquidated = liquidated + math.floor(it.value * Config.LiquidationRate)
        end
        p.cash = p.cash + liquidated
        p.items = {}
        local e = {
            src = src, license = p.license, name = p.name, cash = p.cash, spent = p.spent,
            soldTotal = p.soldTotal, bestSold = p.bestSold, bestLabel = p.bestLabel, liquidated = liquidated,
        }
        list[#list + 1] = e
        if e.bestSold > 0 and (not bestWinner or e.bestSold > bestWinner.bestSold) then bestWinner = e end
        if e.spent > 0 and (not spenderWinner or e.spent > spenderWinner.spent) then spenderWinner = e end
    end
    table.sort(list, function(a, b) return a.cash > b.cash end)

    for _, e in ipairs(list) do
        MySQL.insert([[INSERT INTO storage_results
            (license, name, spent, final_cash, sold_total, best_item_label, best_item_value, won_best_item, won_big_spender)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)]],
            { e.license, e.name, e.spent, e.cash, e.soldTotal, e.bestLabel, e.bestSold,
              (bestWinner == e) and 1 or 0, (spenderWinner == e) and 1 or 0 })
    end

    if bestWinner then Bridge.Add(bestWinner.src, Config.Prizes.bestItem) end
    if spenderWinner then Bridge.Add(spenderWinner.src, Config.Prizes.bigSpender) end

    local res = { standings = {} }
    if bestWinner then
        res.bestItem = { name = bestWinner.name, label = bestWinner.bestLabel, value = bestWinner.bestSold }
    end
    if spenderWinner then
        res.bigSpender = { name = spenderWinner.name, spent = spenderWinner.spent }
    end
    for _, e in ipairs(list) do
        res.standings[#res.standings + 1] = {
            name = e.name, cash = e.cash, spent = e.spent, best = e.bestSold, liquidated = e.liquidated,
        }
    end

    broadcast()
    for src in pairs(Match.players) do TriggerClientEvent('storage:results', src, res) end

    SetTimeout(Config.ResultsSeconds * 1000, function()
        if Match.state == 'ended' then resetMatch() end
    end)
end

local function endRound()
    if Match.round < #Config.Rounds then
        startTravel(Match.round + 1)
    else
        finishMatch()
    end
end

local function startMatch()
    for _, p in pairs(Match.players) do
        p.cash = Config.StartMoney
        p.spent, p.soldTotal, p.bestSold, p.bestLabel = 0, 0, 0, nil
        p.items = {}
    end
    startTravel(1)
end

CreateThread(function()
    math.randomseed(os.time())
    while true do
        Wait(1000)
        local now = os.time()
        if Match.state == 'lobby' then
            if playerCount() >= Config.MinPlayers then
                if not Match.lobbyEndsAt then
                    Match.lobbyEndsAt = now + Config.LobbySeconds
                    notifyAll(('Enough players! The match starts in %d seconds.'):format(Config.LobbySeconds))
                end
                if now >= Match.lobbyEndsAt then startMatch() end
            else
                Match.lobbyEndsAt = nil
            end
        elseif Match.state == 'travel' then
            local all = true
            for _, p in pairs(Match.players) do
                if not p.arrived then all = false break end
            end
            if all or now >= Match.endsAt then beginRound() end
        elseif Match.state == 'round' then
            if now >= Match.endsAt then endRound() end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    if not Match.players[src] then return end
    Match.players[src] = nil
    if next(Match.players) == nil and Match.state ~= 'ended' then Match = newMatch() end
end)

-- ===== Lobby callbacks =====
lib.callback.register('storage:lobbyInfo', function(src)
    return {
        state = Match.state, players = playerCount(), min = Config.MinPlayers, max = Config.MaxPlayers,
        joined = Match.players[src] ~= nil, fee = Config.EntryFee, startMoney = Config.StartMoney,
        countdown = Match.lobbyEndsAt and math.max(0, Match.lobbyEndsAt - os.time()) or nil,
    }
end)

lib.callback.register('storage:join', function(src)
    if Match.state ~= 'idle' and Match.state ~= 'lobby' then return false, 'A match is already running.' end
    if Match.players[src] then return false, 'You already joined.' end
    if playerCount() >= Config.MaxPlayers then return false, 'The lobby is full.' end
    if not Bridge.Remove(src, Config.EntryFee) then return false, 'You cannot afford the entry fee.' end

    Match.players[src] = {
        name = GetPlayerName(src), license = getLicense(src), paid = Config.EntryFee,
        cash = 0, spent = 0, items = {}, nextUid = 0, soldTotal = 0, bestSold = 0, bestLabel = nil, arrived = false,
    }
    Match.state = 'lobby'
    notifyAll(('%s joined (%d/%d).'):format(GetPlayerName(src), playerCount(), Config.MaxPlayers))
    return true, 'You joined the lobby. Wait for the match to start.'
end)

lib.callback.register('storage:leave', function(src)
    local p = Match.players[src]
    if not p then return false end
    if Match.state == 'lobby' then Bridge.Add(src, p.paid) end
    Match.players[src] = nil
    TriggerClientEvent('storage:reset', src)
    if next(Match.players) == nil and Match.state ~= 'ended' then Match = newMatch() end
    return true
end)

lib.callback.register('storage:leaderboard', function()
    return MySQL.query.await([[SELECT MAX(name) AS name, COUNT(*) AS matches,
        SUM(won_best_item) AS best_wins, SUM(won_big_spender) AS spender_wins, MAX(best_item_value) AS best_ever
        FROM storage_results GROUP BY license
        ORDER BY (SUM(won_best_item) + SUM(won_big_spender)) DESC, best_ever DESC LIMIT 10]])
end)

-- ===== Match callbacks =====
RegisterNetEvent('storage:arrived', function()
    local src = source
    local p = Match.players[src]
    if not p or Match.state ~= 'travel' or p.arrived then return end
    if dist2D(src, Match.loc.coords) > Config.ArrivalRadius + 40.0 then return end
    p.arrived = true
    notify(src, 'You arrived. Waiting for the others...', 'success')
end)

local function getStorage(id)
    id = math.floor(tonumber(id) or 0)
    return Match.storages[id], id
end

lib.callback.register('storage:buy', function(src, id)
    local p = Match.players[src]
    if Match.state ~= 'round' or not p then return false, 'No round is running.' end
    local s, sid = getStorage(id)
    if not s or s.owner then return false, 'That storage is already sold.' end
    if dist2D(src, GetLayoutPos(Match.loc, sid, #Match.storages)) > Config.InteractRadius + 3.0 then
        return false, 'You are too far away.'
    end
    if p.cash < s.price then return false, 'Not enough money.' end

    s.owner, s.ownerName = src, p.name
    p.cash = p.cash - s.price
    p.spent = p.spent + s.price
    broadcast()
    syncMe(src)
    return true, ('Storage #%d is yours! Open it.'):format(sid)
end)

local function addItem(p, it)
    p.nextUid = p.nextUid + 1
    p.items[#p.items + 1] = { uid = p.nextUid, label = it.label, value = it.value }
end

lib.callback.register('storage:begin', function(src, kind, id)
    local p = Match.players[src]
    local s, sid = getStorage(id)
    if Match.state ~= 'round' or not p or not s or s.owner ~= src then return false end
    if kind == 'open' and s.opened then return false end
    if kind == 'search' and (not s.opened or s.searched) then return false end
    if kind ~= 'open' and kind ~= 'search' then return false end
    if dist2D(src, GetLayoutPos(Match.loc, sid, #Match.storages)) > Config.InteractRadius + 3.0 then return false end
    p.action = { kind = kind, id = sid, t = GetGameTimer() }
    return true
end)

lib.callback.register('storage:finish', function(src, kind, id)
    local p = Match.players[src]
    local a = p and p.action
    local s, sid = getStorage(id)
    if not a or a.kind ~= kind or a.id ~= sid or not s then return false end
    p.action = nil

    local need = (kind == 'open' and Config.OpenTimeMs or Config.SearchTimeMs) - 500
    if GetGameTimer() - a.t < need then return false end
    if Match.state ~= 'round' or s.owner ~= src then return false end

    local found = {}
    if kind == 'open' then
        if s.opened then return false end
        s.opened = true
        for _, it in ipairs(s.items) do
            addItem(p, it)
            found[#found + 1] = { label = it.label, value = it.value }
        end
    else
        if not s.opened or s.searched then return false end
        s.searched = true
        for _, it in ipairs(s.concealed) do
            addItem(p, it)
            found[#found + 1] = { label = it.label, value = it.value }
        end
    end
    broadcast()
    syncMe(src)
    return true, found
end)

-- ===== Selling =====
local function nearBuyer(src)
    if Match.state ~= 'round' or not Match.loc then return false end
    return dist2D(src, GetBuyerPos(Match.loc)) <= Config.InteractRadius + 3.0
end

local function registerSale(src, p, it)
    local price = math.floor(it.value * Match.buyerMult)
    p.cash = p.cash + price
    p.soldTotal = p.soldTotal + price
    if price > p.bestSold then
        p.bestSold, p.bestLabel = price, it.label
    end
    if price >= Config.BigSaleAnnounce then
        notifyAll(('%s just sold %s for $%d!'):format(p.name, it.label, price), 'success')
    end
    return price
end

lib.callback.register('storage:getInv', function(src)
    local p = Match.players[src]
    if not p or not nearBuyer(src) then return nil end
    local out = {}
    for _, it in ipairs(p.items) do
        out[#out + 1] = { uid = it.uid, label = it.label, offer = math.floor(it.value * Match.buyerMult) }
    end
    return { items = out, mult = Match.buyerMult }
end)

lib.callback.register('storage:sell', function(src, uid)
    local p = Match.players[src]
    if not p or not nearBuyer(src) then return false end
    uid = tonumber(uid)
    for i, it in ipairs(p.items) do
        if it.uid == uid then
            table.remove(p.items, i)
            local price = registerSale(src, p, it)
            syncMe(src)
            return true, price
        end
    end
    return false
end)

lib.callback.register('storage:sellAll', function(src)
    local p = Match.players[src]
    if not p or not nearBuyer(src) then return false end
    local total = 0
    for _, it in ipairs(p.items) do total = total + registerSale(src, p, it) end
    p.items = {}
    syncMe(src)
    return true, total
end)
