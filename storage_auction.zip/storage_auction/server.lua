-- ===== Optional framework bridge (entry fee + prizes only) =====
local ESX, QBCore
if Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
elseif Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
end

local Bridge = {}

function Bridge.Remove(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return true end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if not p or p.getMoney() < amount then return false end
        p.removeMoney(amount)
        return true
    end
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return false end
    return p.Functions.RemoveMoney(Config.QBAccount, amount, 'storage-wars-entry')
end

function Bridge.Add(src, amount)
    if amount <= 0 or Config.Framework == 'none' then return end
    if ESX then
        local p = ESX.GetPlayerFromId(src)
        if p then p.addMoney(amount) end
    else
        local p = QBCore.Functions.GetPlayer(src)
        if p then p.Functions.AddMoney(Config.QBAccount, amount, 'storage-wars-prize') end
    end
end

-- ===== State =====
local Match
local lotCounter = 0
local lastJoinable = nil
local startTravel, finishMatch, startLot, goBetween, endRound -- forward declarations

local function newMatch()
    local containers = {}
    for i, R in ipairs(Config.Rounds) do
        containers[i] = (#R.locations > 0) and R.containers or 0
    end
    return {
        state = 'idle',          -- idle | lobby | travel | round | ended
        players = {},
        host = nil,
        lang = Config.Language,
        settings = { containers = containers },
        round = 0, roundNo = 0, bonus = false, locIdx = 0, loc = nil,
        phase = nil,             -- preview | bidding | looting | between | final
        endsAt = 0, finalStart = 0,
        lotIdx = 0, lot = nil,
        bid = { amount = 0 },
    }
end
Match = newMatch()

local function L(key, ...) return T(Match.lang, key, ...) end

local function notify(src, msg, nType)
    TriggerClientEvent('storage:toast', src, msg, nType or 'info')
end

local function notifyAll(msg, nType)
    for src in pairs(Match.players) do notify(src, msg, nType) end
end

local function playerCount()
    local n = 0
    for _ in pairs(Match.players) do n = n + 1 end
    return n
end

local function dist2D(src, pos)
    if not Config.ServerDistanceChecks then return 0.0 end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return 1e9 end
    local c = GetEntityCoords(ped)
    return #(vec2(c.x, c.y) - vec2(pos.x, pos.y))
end

local function getLicense(src)
    return GetPlayerIdentifierByType(src, 'license') or ('src:' .. src)
end

local function isAdmin(src)
    return IsPlayerAceAllowed(src, 'command') or IsPlayerAceAllowed(src, 'storage.admin')
end

local function updateJoinable()
    local j = (Match.state == 'idle' or Match.state == 'lobby')
    if j ~= lastJoinable then
        lastJoinable = j
        TriggerClientEvent('storage:joinable', -1, j)
    end
end

local function replaceMatch()
    Match = newMatch()
    updateJoinable()
end

-- ===== Rounds helpers =====
local function roundActive(n)
    local R = Config.Rounds[n]
    return R ~= nil and #R.locations > 0 and (Match.settings.containers[n] or 0) > 0
end

local function activeCount()
    local c = 0
    for i = 1, #Config.Rounds do if roundActive(i) then c = c + 1 end end
    return c
end

local function roundNoOf(n)
    local c = 0
    for i = 1, n do if roundActive(i) then c = c + 1 end end
    return c
end

local function nextRound(from)
    for i = from + 1, #Config.Rounds do
        if roundActive(i) then return i end
    end
end

-- ===== Lobby =====
local function lobbyInfo(src)
    local list = {}
    for s, p in pairs(Match.players) do
        list[#list + 1] = { name = p.name, host = (s == Match.host) }
    end
    local rounds = {}
    for i, R in ipairs(Config.Rounds) do
        rounds[i] = {
            name = (Match.lang == 'ru') and R.nameRu or R.nameEn,
            count = Match.settings.containers[i],
            optional = R.optional and true or false,
            available = #R.locations > 0,
            bonus = R.bonus and true or false,
        }
    end
    return {
        state = Match.state, players = list, count = #list, lang = Match.lang,
        min = Config.MinPlayers, max = Config.MaxPlayers,
        joined = Match.players[src] ~= nil, isHost = (Match.host == src),
        fee = Config.EntryFee, startMoney = Config.StartMoney,
        rounds = rounds, maxContainers = Config.MaxContainers,
    }
end

local function pushLobby()
    for src in pairs(Match.players) do
        local info = lobbyInfo(src)
        TriggerClientEvent('storage:lobbyUpdate', src, info)
    end
end

-- ===== Lot generation =====
local function pickTier()
    local total = 0
    for _, t in ipairs(Config.Tiers) do total = total + t.chance end
    local r = math.random() * total
    for _, t in ipairs(Config.Tiers) do
        r = r - t.chance
        if r <= 0 then return t end
    end
    return Config.Tiers[1]
end

local function pickWeighted(list)
    local total = 0
    for _, v in ipairs(list) do total = total + (v.weight or 1) end
    local r = math.random() * total
    for i, v in ipairs(list) do
        r = r - (v.weight or 1)
        if r <= 0 then return v, i end
    end
    return list[1], 1
end

local function pickKind(kinds)
    local total = 0
    for _, w in pairs(kinds) do total = total + w end
    local r = math.random() * total
    for k, w in pairs(kinds) do
        r = r - w
        if r <= 0 then return k end
    end
    return next(kinds)
end

local function themeMult(theme, entry)
    local m = 1.0
    if entry.tags then
        for _, t in ipairs(entry.tags) do m = m * (theme.mult[t] or 1.0) end
    end
    return m
end

local function rollLoot(tier, theme, rareOnly)
    local total, weights = 0, {}
    for i, item in ipairs(Config.Loot) do
        local w
        if rareOnly then
            w = item.rare and item.weight or 0
        else
            w = item.weight * (item.rare and tier.luck or 1.0) * themeMult(theme, item)
        end
        weights[i] = w
        total = total + w
    end
    local r = math.random() * total
    for i, item in ipairs(Config.Loot) do
        if weights[i] > 0 then
            r = r - weights[i]
            if r <= 0 then return item end
        end
    end
    return Config.Loot[1]
end

local function buildLot(roundIdx, loc, forceKind)
    local R = Config.Rounds[roundIdx]
    local kind = forceKind or pickKind(R.kinds)

    local dims, variantName
    if kind == 'garage' then
        local g = Config.Garage
        dims = { width = loc.width or g.width, depth = loc.depth or g.depth, cell = g.cell }
        variantName = { en = g.en, ru = g.ru }
    else
        local v = pickWeighted(Config.Containers)
        dims = { width = v.width, depth = v.depth, cell = v.cell }
        variantName = { en = v.en, ru = v.ru }
    end
    local cols, rows = GetGrid(dims)
    local tier = pickTier()
    local theme, themeIdx = pickWeighted(Config.Themes)

    lotCounter = lotCounter + 1
    local lot = {
        id = lotCounter, kind = kind, dims = dims, variantName = variantName,
        themeIdx = themeIdx, modelIdx = math.random(#Config.ContainerModels),
        tier = tier.name, items = {}, owner = nil, ownerName = nil,
    }

    local occ, uid = {}, 0
    local function free(c, r)
        return c >= 1 and c <= cols and r >= 1 and r <= rows and not occ[c * 100 + r]
    end
    -- covers = list of uids that hide this item (nil = visible from the start)
    local function add(entry, c, r, covers, o)
        uid = uid + 1
        o = o or {}
        local lx, ly = GetSlotPos(dims, c, r)
        local value = math.floor((entry.min + math.random() * (entry.max - entry.min)) * (entry.noScale and 1 or R.valueScale))
        local it = {
            uid = uid, label = entry.label, ru = entry.ru, model = entry.model, value = value,
            isVehicle = entry.isVehicle and true or false,
            lx = o.lx or (lx + (math.random() - 0.5) * 0.2),
            ly = o.ly or (ly + (math.random() - 0.5) * 0.2),
            heading = o.heading or (math.random(0, 359) + 0.0),
            covers = nil, coverLeft = 0, revealed = (covers == nil), picked = false,
        }
        if covers then
            it.covers = {}
            for _, cu in ipairs(covers) do
                it.covers[cu] = true
                it.coverLeft = it.coverLeft + 1
            end
        end
        occ[c * 100 + r] = true
        lot.items[#lot.items + 1] = it
        return it
    end

    -- SUPER LUCKY: a whole car hidden behind a row of wardrobes at the back of the lot
    if rows >= 5 and #Config.Vehicles > 0 and math.random() < (R.carChance or 0) * tier.carMul then
        local coverRow = rows - 4
        local ok = true
        for c = 1, cols do
            for r = coverRow, rows do
                if not free(c, r) then ok = false end
            end
        end
        if ok then
            local covers = {}
            for c = 1, cols do
                local lx, ly = GetSlotPos(dims, c, coverRow)
                local cab = add(Config.Cabinets[math.random(#Config.Cabinets)], c, coverRow, nil, { lx = lx, ly = ly, heading = 0.0 })
                covers[#covers + 1] = cab.uid
            end
            local _, ly1 = GetSlotPos(dims, 1, coverRow + 1)
            local _, ly2 = GetSlotPos(dims, 1, rows)
            for c = 1, cols do
                for r = coverRow + 1, rows do occ[c * 100 + r] = true end
            end
            add(pickWeighted(Config.Vehicles), 1, coverRow + 1, covers, { lx = 0.0, ly = (ly1 + ly2) / 2, heading = 0.0 })
        end
    end

    -- valuables hidden directly behind a cover prop
    local pairsN = math.floor(math.random(R.hiddenMin, R.hiddenMax) * tier.hiddenMul + 0.5)
    for _ = 1, pairsN do
        for _ = 1, 25 do
            local c, r = math.random(cols), math.random(math.max(1, rows - 1))
            if free(c, r) and free(c, r + 1) then
                local cover = add(Config.Covers[math.random(#Config.Covers)], c, r, nil)
                add(rollLoot(tier, theme, true), c, r + 1, { cover.uid })
                break
            end
        end
    end

    -- normal items in random free slots, some of them under a tarp
    local slots = {}
    for c = 1, cols do
        for r = 1, rows do
            if free(c, r) then slots[#slots + 1] = { c, r } end
        end
    end
    for i = #slots, 2, -1 do
        local j = math.random(i)
        slots[i], slots[j] = slots[j], slots[i]
    end
    local count = math.min(math.random(R.itemsMin, R.itemsMax), #slots)
    for i = 1, count do
        local c, r = slots[i][1], slots[i][2]
        local entry = rollLoot(tier, theme, false)
        if #Config.Tarps > 0 and math.random() < (R.tarpChance or 0) then
            local lx, ly = GetSlotPos(dims, c, r)
            lx = lx + (math.random() - 0.5) * 0.2
            ly = ly + (math.random() - 0.5) * 0.2
            local tarp = add(Config.Tarps[math.random(#Config.Tarps)], c, r, nil, { lx = lx, ly = ly })
            add(entry, c, r, { tarp.uid }, { lx = lx, ly = ly })
        else
            add(entry, c, r, nil)
        end
    end

    local sp = R.startMin + math.random() * (R.startMax - R.startMin)
    lot.startPrice = math.max(50, math.floor(sp / 50 + 0.5) * 50)
    return lot
end

local function itemLabel(it, lang)
    return (lang == 'ru' and it.ru) or it.label
end

local function publicLot(lot, lang)
    local list = {}
    for _, it in ipairs(lot.items) do
        if it.revealed and not it.picked then
            list[#list + 1] = {
                uid = it.uid, model = it.model, label = itemLabel(it, lang),
                lx = it.lx, ly = it.ly, heading = it.heading, isVehicle = it.isVehicle,
            }
        end
    end
    return {
        id = lot.id, kind = lot.kind, dims = lot.dims, themeIdx = lot.themeIdx, modelIdx = lot.modelIdx,
        variantName = (lang == 'ru') and lot.variantName.ru or lot.variantName.en,
        themeName = (lang == 'ru') and Config.Themes[lot.themeIdx].ru or Config.Themes[lot.themeIdx].en,
        startPrice = lot.startPrice, items = list,
    }
end

-- ===== Sync to clients =====
local function readyCount()
    local n = 0
    for _, p in pairs(Match.players) do
        if p.ready or #p.items == 0 then n = n + 1 end
    end
    return n
end

local function broadcast()
    updateJoinable()
    local R = Config.Rounds[Match.round]
    local snap = {
        state = Match.state, phase = Match.phase, round = Match.round, lang = Match.lang,
        roundNo = Match.roundNo, roundsTotal = activeCount(), bonus = Match.bonus,
        remaining = math.max(0, Match.endsAt - os.time()),
        locIdx = Match.locIdx, lotIdx = Match.lotIdx,
        lotCount = Match.round > 0 and Match.settings.containers[Match.round] or 0,
        steps = R and R.steps or {},
        bid = { amount = Match.bid.amount, bidder = Match.bid.bidder, bidderName = Match.bid.bidderName },
        ready = readyCount(), playersTotal = playerCount(),
    }
    local ph = Match.phase
    if Match.state == 'round' and Match.lot and (ph == 'preview' or ph == 'bidding' or ph == 'looting') then
        snap.lot = publicLot(Match.lot, Match.lang)
        snap.lotOwner = Match.lot.owner
        snap.lotOwnerName = Match.lot.ownerName
    end
    for src in pairs(Match.players) do TriggerClientEvent('storage:snapshot', src, snap) end
end

local function syncMe(src)
    local p = Match.players[src]
    if p then
        TriggerClientEvent('storage:me', src, { cash = p.cash, spent = p.spent, items = #p.items, best = p.bestSold })
    end
end

local function syncAllMe()
    for src in pairs(Match.players) do syncMe(src) end
end

-- ===== Match flow =====
local function resetMatch()
    for src in pairs(Match.players) do TriggerClientEvent('storage:reset', src) end
    replaceMatch()
end

startTravel = function(n)
    local R = Config.Rounds[n]
    Match.state = 'travel'
    Match.round = n
    Match.roundNo = roundNoOf(n)
    Match.bonus = R.bonus and true or false
    Match.phase = nil
    Match.lot = nil
    Match.lotIdx = 0
    Match.bid = { amount = 0 }
    Match.locIdx = math.random(#R.locations)
    Match.loc = R.locations[Match.locIdx]
    Match.endsAt = os.time() + R.travelSeconds
    for src, p in pairs(Match.players) do
        p.arrived = false
        p.ready = false
        if Config.SpawnTravelVehicle then
            TriggerClientEvent('storage:spawnCar', src, Config.TravelVehicles[math.random(#Config.TravelVehicles)])
        end
    end
    broadcast()
    syncAllMe()
    local name = LocName(Match.loc, Match.lang)
    if Match.bonus then
        notifyAll(L('travel_bonus', name), 'success')
    else
        notifyAll(L('travel', Match.roundNo, name), 'success')
    end
    notifyAll(L('collector_hint', Config.FarBuyerMult))
end

startLot = function(i)
    Match.lotIdx = i
    Match.lot = buildLot(Match.round, Match.loc)
    Match.phase = 'preview'
    Match.bid = { amount = Match.lot.startPrice }
    Match.endsAt = os.time() + Config.Auction.previewSeconds
    broadcast()
end

local function beginRound()
    Match.state = 'round'
    startLot(1)
end

local function toBidding()
    Match.phase = 'bidding'
    Match.endsAt = os.time() + Config.Auction.firstBidSeconds
    broadcast()
end

goBetween = function()
    Match.phase = 'between'
    Match.endsAt = os.time() + Config.Auction.betweenSeconds
    broadcast()
end

local function goFinal()
    Match.phase = 'final'
    Match.lot = nil
    Match.finalStart = os.time()
    Match.endsAt = os.time() + Config.Auction.finalSellSeconds
    for _, p in pairs(Match.players) do p.ready = false end
    broadcast()
    notifyAll(L('final_call'), 'success')
end

local function closeBidding()
    local b = Match.bid
    local winner = b.bidder and Match.players[b.bidder]
    if winner and winner.cash >= b.amount then
        winner.cash = winner.cash - b.amount
        winner.spent = winner.spent + b.amount
        Match.lot.owner = b.bidder
        Match.lot.ownerName = winner.name
        Match.phase = 'looting'
        Match.endsAt = os.time() + Config.Auction.lootSeconds
        syncMe(b.bidder)
        broadcast()
        notifyAll(L('lot_won', winner.name, b.amount), 'success')
    else
        notifyAll(L('no_bids'))
        goBetween()
    end
end

local function nextLot()
    if Match.lotIdx < Match.settings.containers[Match.round] then
        startLot(Match.lotIdx + 1)
    else
        goFinal()
    end
end

endRound = function()
    local nxt = nextRound(Match.round)
    if nxt then
        startTravel(nxt)
    else
        finishMatch()
    end
end

local function startMatch()
    for _, p in pairs(Match.players) do
        p.cash = Config.StartMoney
        p.spent, p.soldTotal, p.bestSold, p.bestLabel = 0, 0, 0, nil
        p.items = {}
    end
    startTravel(nextRound(0))
end

finishMatch = function()
    Match.state = 'ended'
    Match.phase = nil
    Match.lot = nil
    Match.endsAt = os.time() + Config.ResultsSeconds

    local list, bestWinner, spenderWinner = {}, nil, nil
    for src, p in pairs(Match.players) do
        local liquidated = 0
        for _, it in ipairs(p.items) do
            liquidated = liquidated + math.floor(it.value * Config.LiquidationRate)
        end
        p.cash = p.cash + liquidated
        p.items = {}
        local e = {
            src = src, license = p.license, name = p.name, cash = p.cash, spent = p.spent,
            soldTotal = p.soldTotal, bestSold = p.bestSold, bestLabel = p.bestLabel, liquidated = liquidated,
        }
        list[#list + 1] = e
        if e.bestSold > 0 and (not bestWinner or e.bestSold > bestWinner.bestSold) then bestWinner = e end
        if e.spent > 0 and (not spenderWinner or e.spent > spenderWinner.spent) then spenderWinner = e end
    end
    table.sort(list, function(a, b) return a.cash > b.cash end)

    for _, e in ipairs(list) do
        MySQL.insert([[INSERT INTO storage_results
            (license, name, spent, final_cash, sold_total, best_item_label, best_item_value, won_best_item, won_big_spender)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)]],
            { e.license, e.name, e.spent, e.cash, e.soldTotal, e.bestLabel, e.bestSold,
              (bestWinner == e) and 1 or 0, (spenderWinner == e) and 1 or 0 })
    end

    if bestWinner then Bridge.Add(bestWinner.src, Config.Prizes.bestItem) end
    if spenderWinner then Bridge.Add(spenderWinner.src, Config.Prizes.bigSpender) end

    local res = { standings = {}, liquidation = math.floor(Config.LiquidationRate * 100), lang = Match.lang }
    if bestWinner then
        res.bestItem = { name = bestWinner.name, label = bestWinner.bestLabel, value = bestWinner.bestSold }
    end
    if spenderWinner then
        res.bigSpender = { name = spenderWinner.name, spent = spenderWinner.spent }
    end
    for _, e in ipairs(list) do
        res.standings[#res.standings + 1] = {
            name = e.name, cash = e.cash, spent = e.spent, best = e.bestSold, liquidated = e.liquidated,
        }
    end

    broadcast()
    for src in pairs(Match.players) do TriggerClientEvent('storage:results', src, res) end

    SetTimeout(Config.ResultsSeconds * 1000, function()
        if Match.state == 'ended' then resetMatch() end
    end)
end

local function lootRemaining(lot)
    for _, it in ipairs(lot.items) do
        if not it.picked then return true end
    end
    return false
end

local function allReady()
    if os.time() - Match.finalStart < Config.Auction.finalMinSeconds then return false end
    for _, p in pairs(Match.players) do
        if #p.items > 0 and not p.ready then return false end
    end
    return true
end

CreateThread(function()
    math.randomseed(os.time())
    while true do
        Wait(1000)
        local now = os.time()
        if Match.state == 'travel' then
            local all = true
            for _, p in pairs(Match.players) do
                if not p.arrived then all = false break end
            end
            if all or now >= Match.endsAt then beginRound() end
        elseif Match.state == 'round' then
            local ph = Match.phase
            if ph == 'looting' and Match.lot and not Match.players[Match.lot.owner] then
                goBetween()
            elseif ph == 'final' and (allReady() or now >= Match.endsAt) then
                endRound()
            elseif ph ~= 'final' and now >= Match.endsAt then
                if ph == 'preview' then toBidding()
                elseif ph == 'bidding' then closeBidding()
                elseif ph == 'looting' then goBetween()
                elseif ph == 'between' then nextLot() end
            end
        end
    end
end)

local function removePlayer(src, refund)
    local p = Match.players[src]
    if not p then return end
    if refund and Match.state == 'lobby' then Bridge.Add(src, p.paid) end
    Match.players[src] = nil
    if Match.host == src then Match.host = next(Match.players) end
    if next(Match.players) == nil and Match.state ~= 'ended' then
        replaceMatch()
    else
        pushLobby()
    end
end

AddEventHandler('playerDropped', function()
    removePlayer(source, false)
end)

-- ===== Lobby callbacks =====
lib.callback.register('storage:isJoinable', function()
    return Match.state == 'idle' or Match.state == 'lobby'
end)

lib.callback.register('storage:lobbyInfo', function(src)
    return lobbyInfo(src)
end)

lib.callback.register('storage:join', function(src)
    if Match.state ~= 'idle' and Match.state ~= 'lobby' then return false, L('join_running') end
    if Match.players[src] then return false, L('join_already') end
    if playerCount() >= Config.MaxPlayers then return false, L('join_full') end
    if not Bridge.Remove(src, Config.EntryFee) then return false, L('join_fee') end

    Match.players[src] = {
        name = GetPlayerName(src), license = getLicense(src), paid = Config.EntryFee,
        cash = 0, spent = 0, items = {}, nextUid = 0, soldTotal = 0, bestSold = 0, bestLabel = nil,
        arrived = false, ready = false,
    }
    if not Match.host then Match.host = src end
    Match.state = 'lobby'
    updateJoinable()
    pushLobby()
    return true, L('joined')
end)

lib.callback.register('storage:leave', function(src)
    if not Match.players[src] then return false end
    removePlayer(src, true)
    TriggerClientEvent('storage:reset', src)
    return true
end)

lib.callback.register('storage:setContainers', function(src, round, value)
    if Match.host ~= src or Match.state ~= 'lobby' then return false end
    round = math.floor(tonumber(round) or 0)
    value = math.floor(tonumber(value) or 0)
    local R = Config.Rounds[round]
    if not R or #R.locations == 0 then return false end
    local minV = R.optional and 0 or 1
    Match.settings.containers[round] = math.max(minV, math.min(Config.MaxContainers, value))
    pushLobby()
    return true
end)

lib.callback.register('storage:setLang', function(src, lang)
    if Match.host ~= src or Match.state ~= 'lobby' then return false end
    if lang ~= 'ru' and lang ~= 'en' then return false end
    Match.lang = lang
    pushLobby()
    return true
end)

lib.callback.register('storage:start', function(src)
    if Match.host ~= src or Match.state ~= 'lobby' then return false, L('only_host') end
    if playerCount() < Config.MinPlayers then return false, L('need_players', Config.MinPlayers) end
    if not nextRound(0) then return false, L('no_rounds') end
    startMatch()
    return true
end)

lib.callback.register('storage:leaderboard', function()
    return MySQL.query.await([[SELECT MAX(name) AS name, COUNT(*) AS matches,
        SUM(won_best_item) AS best_wins, SUM(won_big_spender) AS spender_wins, MAX(best_item_value) AS best_ever
        FROM storage_results GROUP BY license
        ORDER BY (SUM(won_best_item) + SUM(won_big_spender)) DESC, best_ever DESC LIMIT 10]])
end)

-- ===== Travel =====
RegisterNetEvent('storage:arrived', function()
    local src = source
    local p = Match.players[src]
    if not p or Match.state ~= 'travel' or p.arrived then return end
    if dist2D(src, Match.loc.coords) > Config.ArrivalRadius + 40.0 then return end
    p.arrived = true
    notify(src, L('arrived'), 'success')
end)

local carCooldown = {}
RegisterCommand('storagecar', function(src)
    if src == 0 then return end
    if not Match.players[src] or Match.state ~= 'travel' then return end
    local now = os.time()
    if carCooldown[src] and now - carCooldown[src] < 45 then
        return notify(src, L('car_wait'), 'error')
    end
    carCooldown[src] = now
    TriggerClientEvent('storage:spawnCar', src, Config.TravelVehicles[math.random(#Config.TravelVehicles)])
end, false)

-- ===== Auction =====
local function containerCenter()
    return LocalToWorld(Match.loc, 0.0, Match.lot.dims.depth / 2)
end

lib.callback.register('storage:bid', function(src, stepIdx)
    local p = Match.players[src]
    if not p or Match.state ~= 'round' or Match.phase ~= 'bidding' or not Match.lot then
        return false, L('bid_closed')
    end
    local R = Config.Rounds[Match.round]
    local step = R.steps[math.floor(tonumber(stepIdx) or 0)]
    if not step then return false end
    if dist2D(src, containerCenter()) > Config.Auction.bidRadius then return false, L('bid_far') end
    if Match.bid.bidder == src then return false, L('bid_leader') end

    local base = Match.bid.bidder and Match.bid.amount or Match.lot.startPrice
    local amount = base + step
    if amount > p.cash then return false, L('bid_cash') end

    Match.bid = { amount = amount, bidder = src, bidderName = p.name }
    Match.endsAt = math.max(Match.endsAt, os.time() + Config.Auction.resetSeconds)
    broadcast()
    return true
end)

local function addItem(p, it)
    p.nextUid = p.nextUid + 1
    p.items[#p.items + 1] = { uid = p.nextUid, label = it.label, ru = it.ru, value = it.value }
end

lib.callback.register('storage:pickup', function(src, uid)
    local p = Match.players[src]
    local lot = Match.lot
    if not p or Match.state ~= 'round' or Match.phase ~= 'looting' or not lot or lot.owner ~= src then
        return false
    end
    uid = math.floor(tonumber(uid) or 0)
    local item
    for _, it in ipairs(lot.items) do
        if it.uid == uid and it.revealed and not it.picked then item = it break end
    end
    if not item then return false end

    item.picked = true
    addItem(p, item)

    local revealed = 0
    for _, h in ipairs(lot.items) do
        if h.covers and h.covers[uid] then
            h.covers[uid] = nil
            h.coverLeft = h.coverLeft - 1
            if h.coverLeft <= 0 and not h.revealed then
                h.revealed = true
                revealed = revealed + 1
            end
        end
    end

    syncMe(src)
    if not lootRemaining(lot) then Match.endsAt = os.time() + 1 end
    broadcast()
    return true, { label = itemLabel(item, Match.lang), value = item.value }, revealed
end)

lib.callback.register('storage:finishLoot', function(src)
    if Match.state == 'round' and Match.phase == 'looting' and Match.lot and Match.lot.owner == src then
        Match.endsAt = os.time()
        return true
    end
    return false
end)

lib.callback.register('storage:skipSell', function(src)
    local p = Match.players[src]
    if not p or Match.state ~= 'round' or Match.phase ~= 'final' then return false end
    p.ready = true
    notify(src, L('ready_skip'))
    broadcast()
    return true
end)

-- ===== Selling =====
local function buyerPos(which)
    if not Match.loc then return nil end
    if which == 'far' then
        local pos = GetCollectorPos(Match.loc)
        return pos
    end
    return LocalToWorld(Match.loc, Config.Layout.buyer.x, Config.Layout.buyer.y)
end

local function canTrade(src, which)
    if which ~= 'far' and which ~= 'local' then return false end
    if Match.state ~= 'round' and Match.state ~= 'travel' then return false end
    if which == 'local' and Match.state ~= 'round' then return false end
    local pos = buyerPos(which)
    if not pos then return false end
    return dist2D(src, pos) <= Config.InteractRadius + 3.0
end

local function multFor(which)
    return which == 'far' and Config.FarBuyerMult or Config.LocalBuyerMult
end

local function registerSale(p, it, mult)
    local price = math.floor(it.value * mult)
    p.cash = p.cash + price
    p.soldTotal = p.soldTotal + price
    if price > p.bestSold then
        p.bestSold, p.bestLabel = price, itemLabel(it, Match.lang)
    end
    if price >= Config.BigSaleAnnounce then
        notifyAll(L('sold_big', p.name, itemLabel(it, Match.lang), price), 'success')
    end
    return price
end

lib.callback.register('storage:getInv', function(src, which)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return nil end
    local mult = multFor(which)
    local out = {}
    for _, it in ipairs(p.items) do
        out[#out + 1] = { uid = it.uid, label = itemLabel(it, Match.lang), offer = math.floor(it.value * mult) }
    end
    return {
        items = out, mult = mult,
        title = which == 'far' and L('buyer_collector') or L('buyer_local'),
        canSkip = Match.phase == 'final',
    }
end)

lib.callback.register('storage:sell', function(src, which, uid)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return false end
    uid = tonumber(uid)
    for i, it in ipairs(p.items) do
        if it.uid == uid then
            table.remove(p.items, i)
            local price = registerSale(p, it, multFor(which))
            syncMe(src)
            return true, price
        end
    end
    return false
end)

lib.callback.register('storage:sellAll', function(src, which)
    local p = Match.players[src]
    if not p or not canTrade(src, which) then return false end
    local total = 0
    local mult = multFor(which)
    for _, it in ipairs(p.items) do total = total + registerSale(p, it, mult) end
    p.items = {}
    syncMe(src)
    return true, total
end)

-- ===== Admin test: show a generated lot at your position (does not touch the real match) =====
RegisterNetEvent('storage:testLot', function(round, kind, coords, heading)
    local src = source
    if not Config.DebugCommands or not isAdmin(src) then return notify(src, L('admin_only'), 'error') end
    round = math.max(1, math.min(#Config.Rounds, math.floor(tonumber(round) or 1)))
    kind = (kind == 'garage') and 'garage' or 'container'
    local loc = { coords = vec3(coords.x, coords.y, coords.z), heading = (heading or 0.0) + 0.0 }
    local lot = buildLot(round, loc, kind)
    TriggerClientEvent('storage:testLot', src, {
        lot = publicLot(lot, Config.Language), round = round, heading = loc.heading,
        coords = { x = loc.coords.x, y = loc.coords.y, z = loc.coords.z }, lang = Config.Language,
    })
    notify(src, T(Config.Language, 'test_on'), 'success')
end)
