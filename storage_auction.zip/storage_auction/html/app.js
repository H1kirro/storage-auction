const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'storage_auction';
const money = n => '$' + Math.floor(n || 0).toLocaleString('en-US');
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- i18n ----------
const I18N = {
  ru: {
    cash: 'НАЛИЧНЫЕ', spent: 'ПОТРАЧЕНО', to_sell: 'НА ПРОДАЖУ',
    tab_match: 'Матч', tab_board: 'Рейтинг', players: 'Игроки', language: 'Язык интерфейса', lots_per_round: 'Лотов в раунде',
    buyer: 'СКУПЩИК', close: 'Закрыть', skip_sell: 'Пропустить продажу', you_took: 'ВЫ ВЗЯЛИ', total: 'Итого',
    move: 'движение', zoom: 'колесо: приближение', hide: 'скрыть', finish: 'Закончить',
    insp_top: 'Кликайте по вещам, чтобы забрать их. <b>За ними может прятаться что-то ценное.</b>',
    match_finished: 'МАТЧ ЗАВЕРШЁН', results: 'Результаты',
    lobby_idle: 'Матча пока нет — станьте первым', lobby_lobby: 'Лобби открыто', lobby_running: 'Матч идёт', lobby_ended: 'Матч только что закончился',
    host: 'ХОСТ', nobody: 'Пока никого.', off: 'выкл.', no_locations: 'нет локаций в конфиге',
    join: 'Войти в матч', leave: 'Выйти', leave_match: 'Покинуть матч', start: 'Начать матч', need_n: '(нужно %s)',
    info_start: 'Все стартуют с %s.', info_fee: 'Взнос %s.',
    info_host: 'Вы хост: выберите число лотов в раундах и язык, затем начинайте матч.', info_guest: 'Настройки меняет и запускает матч только хост.',
    loading: 'Загрузка...', board_empty: 'Матчей ещё не было.', board_row: 'Титулы %s - Лучшая находка %s - Матчей %s',
    phase_travel: 'ЕДЕМ', phase_preview: 'ОСМОТР', phase_bidding: 'ТОРГИ', phase_looting: 'ВЗЯТЬ ЛОТ', phase_between: 'СЛЕДУЮЩИЙ', phase_final: 'ПРОДАЖА',
    round_chip: 'РАУНД %s / %s', bonus_chip: 'БОНУС',
    drive_to: 'Езжайте: %s', lot_n: 'Лот %s / %s', final_sub: 'Продайте всё скупщику. Готовы: %s / %s. Нажмите G, чтобы пропустить.',
    starting_bid: 'СТАРТОВАЯ СТАВКА', current_bid: 'ТЕКУЩАЯ СТАВКА', sold: 'ПРОДАНО',
    bidding_opens: 'Торги начнутся, когда закончится таймер', no_bids_yet: 'Ставок пока нет',
    lead_you: 'Ваша ставка — лидирующая!', lead_other: 'Лидер: %s',
    hint_preview: 'Подойдите к лоту и осмотрите его — подумайте, окупится ли.',
    hint_bidding: 'Каждая новая ставка сбрасывает таймер. Раз, два...',
    hint_mine: 'Не торопитесь — и загляните за большие вещи.', hint_other: 'Победитель разбирает лот.',
    mine_lot: 'Этот лот ваш!', winner: 'Победитель: %s',
    b_round: 'РАУНД %s', b_bonus: 'БОНУС: ГАРАЖИ', b_drive: 'Езжайте: %s',
    b_lot: 'ЛОТ %s / %s', b_lot_sub: '%s - хорошенько осмотрите лот', b_bid: 'ТОРГИ ОТКРЫТЫ', b_bid_sub: 'Клавиши 1-4 повышают ставку',
    b_sold: 'ПРОДАНО: %s', b_nobids: 'СТАВОК НЕТ', b_nobids_sub: 'Лот снят с торгов',
    b_final: 'ПОСЛЕДНИЙ ШАНС', b_final_sub: 'Продайте добычу до конца времени',
    nothing_sell: 'Вам нечего продавать.', sell: 'Продать', sell_all: 'Продать всё - %s', nothing_yet: 'Пока ничего.',
    hidden: 'Под этим что-то пряталось!',
    best_find: 'ЛУЧШАЯ НАХОДКА', big_spender: 'САМЫЙ ЩЕДРЫЙ', nobody_award: 'Никто', nothing_sold: 'Ничего не продано', nothing_bought: 'Ничего не куплено',
    sold_for: '%s продан за %s', spent_lots: '%s потрачено на лоты',
    r_row: 'Наличные <b>%s</b> - Потрачено %s - Лучшая продажа %s', liquidated: 'Непроданное продано по %s%%.',
  },
  en: {
    cash: 'CASH', spent: 'SPENT', to_sell: 'TO SELL',
    tab_match: 'Match', tab_board: 'Leaderboard', players: 'Players', language: 'Interface language', lots_per_round: 'Lots per round',
    buyer: 'BUYER', close: 'Close', skip_sell: 'Skip selling', you_took: 'YOU TOOK', total: 'Total',
    move: 'move', zoom: 'wheel: zoom', hide: 'hide', finish: 'Finish',
    insp_top: 'Click items to take them out. <b>Something valuable may be hiding behind them.</b>',
    match_finished: 'MATCH FINISHED', results: 'Results',
    lobby_idle: 'No match yet - be the first to join', lobby_lobby: 'Lobby is open', lobby_running: 'Match in progress', lobby_ended: 'Match just finished',
    host: 'HOST', nobody: 'Nobody yet.', off: 'off', no_locations: 'no locations in config',
    join: 'Join match', leave: 'Leave', leave_match: 'Leave match', start: 'Start match', need_n: '(need %s)',
    info_start: 'Everyone starts with %s.', info_fee: 'Entry fee %s.',
    info_host: 'You are the host: set the lots per round and the language, then start the match.', info_guest: 'Only the host can change settings and start the match.',
    loading: 'Loading...', board_empty: 'No matches played yet.', board_row: 'Titles %s - Best find %s - Matches %s',
    phase_travel: 'DRIVING', phase_preview: 'PREVIEW', phase_bidding: 'BIDDING', phase_looting: 'LOOTING', phase_between: 'NEXT LOT', phase_final: 'SELLING',
    round_chip: 'ROUND %s / %s', bonus_chip: 'BONUS',
    drive_to: 'Drive to %s', lot_n: 'Lot %s / %s', final_sub: 'Sell everything to a buyer. Ready: %s / %s. Press G to skip.',
    starting_bid: 'STARTING BID', current_bid: 'CURRENT BID', sold: 'SOLD',
    bidding_opens: 'Bidding opens when the timer ends', no_bids_yet: 'No bids yet',
    lead_you: 'You have the highest bid!', lead_other: 'Highest bidder: %s',
    hint_preview: 'Walk up to the lot and check what is inside - think about whether it pays off.',
    hint_bidding: 'Every new bid restarts the countdown. Going once, going twice...',
    hint_mine: 'Take your time - and look behind the big things.', hint_other: 'The winner is going through the lot.',
    mine_lot: 'This lot is yours!', winner: 'Winner: %s',
    b_round: 'ROUND %s', b_bonus: 'BONUS: GARAGES', b_drive: 'Drive to %s',
    b_lot: 'LOT %s / %s', b_lot_sub: '%s - take a good look inside', b_bid: 'BIDDING OPEN', b_bid_sub: 'Press 1-4 to raise the bid',
    b_sold: 'SOLD to %s', b_nobids: 'NO BIDS', b_nobids_sub: 'The lot is withdrawn',
    b_final: 'FINAL CALL', b_final_sub: 'Sell your loot before time runs out',
    nothing_sell: 'You have nothing to sell.', sell: 'Sell', sell_all: 'Sell all - %s', nothing_yet: 'Nothing yet.',
    hidden: 'Something was hiding under it!',
    best_find: 'BEST FIND', big_spender: 'BIGGEST SPENDER', nobody_award: 'Nobody', nothing_sold: 'Nothing was sold', nothing_bought: 'Nothing was bought',
    sold_for: '%s sold for %s', spent_lots: '%s spent on lots',
    r_row: 'Cash <b>%s</b> - Spent %s - Best sale %s', liquidated: 'Unsold items were liquidated at %s%%.',
  },
};
let LANG = 'ru';
function t(key, ...a) {
  let s = (I18N[LANG] && I18N[LANG][key]) || I18N.en[key] || key;
  let i = 0;
  return s.replace(/%s/g, () => a[i++]);
}
function applyStatic() {
  $$('[data-i]').forEach(el => { el.textContent = t(el.dataset.i); });
  $$('[data-ih]').forEach(el => { el.innerHTML = t(el.dataset.ih); });
}

function post(name, data) {
  return fetch(`https://${RES}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {})
  }).then(r => r.json()).catch(() => ({}));
}

let st = {}, me = {}, endAt = 0, barTotal = 1, dist = null, lobbyInfo = null, sellCtx = null;
let found = [], foundTotal = 0;

// ---------- toasts / banner ----------
function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 4200);
  setTimeout(() => el.remove(), 4700);
}
let bannerTimer;
function banner(title, sub) {
  const b = $('#banner');
  b.classList.remove('hidden');
  b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  $('#b-title').textContent = title;
  $('#b-sub').textContent = sub || '';
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), 3200);
}

// ---------- state / HUD / auction ----------
function onState(d) {
  const prev = st;
  st = d;
  endAt = Date.now() + (d.remaining || 0) * 1000;

  const active = d.state === 'travel' || d.state === 'round';
  $('#hud').classList.toggle('hidden', !active);
  if (!active) { $('#auction').classList.add('hidden'); return; }

  $('#h-round').textContent = d.bonus ? t('bonus_chip') : t('round_chip', d.roundNo, d.roundsTotal);
  $('#h-phase').textContent = d.state === 'travel' ? t('phase_travel') : t('phase_' + d.phase);

  const amountChanged = !prev.bid || !d.bid || prev.bid.amount !== d.bid.amount;
  if (d.phase !== prev.phase || d.state !== prev.state || amountChanged) barTotal = Math.max(1, d.remaining || 1);

  if (d.state === 'travel' && (prev.state !== 'travel' || prev.round !== d.round)) {
    banner(d.bonus ? t('b_bonus') : t('b_round', d.roundNo), t('b_drive', d.locName || ''));
  } else if (d.state === 'round') {
    if (d.phase === 'preview' && (prev.phase !== 'preview' || prev.lotIdx !== d.lotIdx)) banner(t('b_lot', d.lotIdx, d.lotCount), t('b_lot_sub', d.kindName || ''));
    else if (d.phase === 'bidding' && prev.phase !== 'bidding') banner(t('b_bid'), t('b_bid_sub'));
    else if (d.phase === 'looting' && prev.phase !== 'looting') banner(t('b_sold', d.owner), money(d.bid.amount));
    else if (d.phase === 'between' && prev.phase === 'bidding') banner(t('b_nobids'), t('b_nobids_sub'));
    else if (d.phase === 'final' && prev.phase !== 'final') banner(t('b_final'), t('b_final_sub'));
  }

  renderSub();
  renderAuction(amountChanged);
}

function renderSub() {
  const d = st;
  if (d.state === 'travel') {
    const dd = dist != null ? `  -  ${dist >= 1000 ? (dist / 1000).toFixed(1) + ' km' : dist + ' m'}` : '';
    $('#h-sub').textContent = t('drive_to', d.locName || '?') + dd;
  } else if (d.phase === 'final') {
    $('#h-sub').textContent = t('final_sub', d.ready || 0, d.playersTotal || 0);
  } else {
    $('#h-sub').textContent = t('lot_n', d.lotIdx, d.lotCount);
  }
}

function renderAuction(bump) {
  const d = st, a = $('#auction');
  const show = d.state === 'round' && (d.phase === 'preview' || d.phase === 'bidding' || d.phase === 'looting');
  a.classList.toggle('hidden', !show);
  if (!show) return;

  $('#a-lot').textContent = t('lot_n', d.lotIdx, d.lotCount);
  $('#a-kind').textContent = [d.kindName, d.themeName].filter(Boolean).join(' - ');
  const amt = $('#a-amount'), who = $('#a-who'), keys = $('#a-keys'), hint = $('#a-hint');
  who.classList.remove('me');
  keys.innerHTML = '';

  if (d.phase === 'preview') {
    $('#a-label').textContent = t('starting_bid');
    amt.textContent = money(d.startPrice);
    who.textContent = t('bidding_opens');
    hint.textContent = t('hint_preview');
  } else if (d.phase === 'bidding') {
    const has = !!(d.bid && d.bid.bidder);
    $('#a-label').textContent = has ? t('current_bid') : t('starting_bid');
    amt.textContent = money(d.bid.amount);
    if (has) { who.textContent = d.lead ? t('lead_you') : t('lead_other', d.bid.bidderName); if (d.lead) who.classList.add('me'); }
    else who.textContent = t('no_bids_yet');
    (d.steps || []).forEach((s, i) => { const k = document.createElement('span'); k.innerHTML = `<kbd>${i + 1}</kbd> +${money(s)}`; keys.appendChild(k); });
    hint.textContent = t('hint_bidding');
  } else {
    $('#a-label').textContent = t('sold');
    amt.textContent = money(d.bid.amount);
    who.textContent = d.mine ? t('mine_lot') : t('winner', d.owner);
    if (d.mine) who.classList.add('me');
    hint.textContent = d.mine ? t('hint_mine') : t('hint_other');
  }
  if (bump) { amt.classList.remove('bump'); void amt.offsetWidth; amt.classList.add('bump'); }
}

function onMe(d) {
  me = d;
  $('#h-cash').textContent = money(d.cash);
  $('#h-spent').textContent = money(d.spent);
  $('#h-items').textContent = d.items;
}

function onDist(d) { dist = d.m; if (st.state === 'travel') renderSub(); }

setInterval(() => {
  if ($('#hud').classList.contains('hidden')) return;
  const ms = Math.max(0, endAt - Date.now());
  const s = Math.ceil(ms / 1000);
  $('#h-timer').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const bar = $('#a-bar');
  bar.style.width = Math.min(100, (ms / (barTotal * 1000)) * 100) + '%';
  bar.classList.toggle('low', st.phase === 'bidding' && s <= 3);
}, 200);

// ---------- lobby ----------
function onLobby(d) {
  lobbyInfo = d.info;
  $('#lobby').classList.remove('hidden');
  setTab('match');
  renderLobby();
}
function onLobbyUpdate(d) {
  lobbyInfo = d.info;
  if (!$('#lobby').classList.contains('hidden')) renderLobby();
}

function setTab(tab) {
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $('#tab-match').classList.toggle('hidden', tab !== 'match');
  $('#tab-board').classList.toggle('hidden', tab !== 'board');
  if (tab === 'board') {
    $('#l-board').innerHTML = `<div class="muted">${t('loading')}</div>`;
    post('leaderboard').then(r => {
      const rows = r.rows || [];
      $('#l-board').innerHTML = rows.length ? rows.map((x, i) =>
        `<div class="row"><span><b>${i + 1}.</b> ${esc(x.name)}</span><span class="muted small">${t('board_row', (+x.best_wins || 0) + (+x.spender_wins || 0), money(+x.best_ever || 0), +x.matches || 0)}</span></div>`
      ).join('') : `<div class="muted">${t('board_empty')}</div>`;
    });
  }
}
$$('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));

function renderLobby() {
  const i = lobbyInfo; if (!i) return;
  LANG = i.lang || LANG;
  applyStatic();
  const key = { idle: 'lobby_idle', lobby: 'lobby_lobby', travel: 'lobby_running', round: 'lobby_running', ended: 'lobby_ended' }[i.state] || 'lobby_lobby';
  $('#l-status').textContent = t(key);
  $('#l-count').textContent = `${i.count} / ${i.max}`;
  $('#l-players').innerHTML = i.players.length
    ? i.players.map(p => `<div class="row"><span>${esc(p.name)}${p.host ? `<span class="badge">${t('host')}</span>` : ''}</span></div>`).join('')
    : `<div class="muted">${t('nobody')}</div>`;

  // language switch (host only)
  const canEdit = i.isHost && i.state === 'lobby';
  $('#l-langs').innerHTML = ['ru', 'en'].map(l =>
    `<button data-lang="${l}" class="${LANG === l ? 'on' : ''}" ${canEdit ? '' : 'disabled'}>${l.toUpperCase()}</button>`).join('');
  $$('#l-langs button').forEach(b => b.addEventListener('click', () => post('setLang', { lang: b.dataset.lang })));

  // lots per round
  let html = '';
  i.rounds.forEach((r, idx) => {
    const n = idx + 1;
    let ctl;
    if (!r.available) {
      ctl = `<span class="muted small">${t('no_locations')}</span>`;
    } else {
      ctl = `<div class="step">` +
        (canEdit ? `<button data-r="${n}" data-d="-1">-</button>` : '') +
        `<span>${r.count === 0 ? t('off') : r.count}</span>` +
        (canEdit ? `<button data-r="${n}" data-d="1">+</button>` : '') + `</div>`;
    }
    html += `<div class="row"><span>${esc(r.name)}${r.bonus ? `<span class="badge">${t('bonus_chip')}</span>` : ''}</span>${ctl}</div>`;
  });
  $('#l-settings').innerHTML = html;
  $$('#l-settings button').forEach(b => b.addEventListener('click', () => {
    const n = +b.dataset.r, d = +b.dataset.d, r = i.rounds[n - 1];
    const minV = r.optional ? 0 : 1;
    post('setContainers', { round: n, value: Math.max(minV, Math.min(i.maxContainers, r.count + d)) });
  }));
  $('#l-info').textContent = t('info_start', money(i.startMoney)) + ' ' + (i.fee > 0 ? t('info_fee', money(i.fee)) + ' ' : '') +
    (i.isHost ? t('info_host') : t('info_guest'));

  const act = $('#l-actions');
  act.innerHTML = '';
  const add = (txt, cls, fn, dis) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = txt; b.disabled = !!dis; b.onclick = fn; act.appendChild(b); };
  add(t('close'), 'ghost', () => post('close'));
  if (i.joined && i.state === 'lobby') add(t('leave'), 'danger', () => post('lobbyLeave'));
  if (i.joined && i.state !== 'lobby') add(t('leave_match'), 'danger', () => post('lobbyLeave'));
  if (!i.joined && (i.state === 'idle' || i.state === 'lobby')) add(t('join'), '', () => post('lobbyJoin'));
  if (i.joined && i.isHost && i.state === 'lobby') add(`${t('start')}${i.count < i.min ? ' ' + t('need_n', i.min) : ''}`, '', () => post('lobbyStart'), i.count < i.min);
}

// ---------- sell ----------
function onSell(d) { sellCtx = d; $('#sell').classList.remove('hidden'); renderSell(); }
function renderSell() {
  const { which, inv } = sellCtx;
  if (!inv) { post('close'); return; }
  $('#s-title').textContent = inv.title;
  $('#s-mult').textContent = 'x' + Number(inv.mult).toFixed(2);
  const total = inv.items.reduce((a, b) => a + b.offer, 0);
  $('#s-list').innerHTML = inv.items.length ? inv.items.map(it =>
    `<div class="row"><span>${esc(it.label)}</span><span><b>${money(it.offer)}</b> &nbsp;<button class="sellbtn" data-uid="${it.uid}">${t('sell')}</button></span></div>`
  ).join('') : `<div class="muted">${t('nothing_sell')}</div>`;
  $('#s-all').textContent = t('sell_all', money(total));
  $('#s-all').disabled = !inv.items.length;
  $('#s-skip').classList.toggle('hidden', !inv.canSkip);
  $$('#s-list .sellbtn').forEach(b => b.addEventListener('click', () =>
    post('sell', { which, uid: +b.dataset.uid }).then(r => { sellCtx.inv = r.inv; renderSell(); })));
}
$('#s-all').addEventListener('click', () => post('sellAll', { which: sellCtx.which }).then(r => { sellCtx.inv = r.inv; renderSell(); }));
$('#s-skip').addEventListener('click', () => { post('skipSell'); post('close'); });

// ---------- inspect ----------
function onInspect(d) {
  $('#inspect').classList.toggle('hidden', !d.on);
  if (d.on) { found = []; foundTotal = 0; renderFound(); }
}
function renderFound() {
  $('#i-found').innerHTML = found.length ? found.map(f => `<div class="row found"><span>${esc(f.label)}</span><b>${money(f.value)}</b></div>`).join('')
    : `<div class="muted small">${t('nothing_yet')}</div>`;
  $('#i-total').textContent = money(foundTotal);
}
const stage = $('#stage'), tip = $('#tip');
let hoverBusy = false;
stage.addEventListener('mousemove', e => {
  tip.style.left = e.clientX + 'px'; tip.style.top = e.clientY + 'px';
  if (hoverBusy) return;
  hoverBusy = true;
  post('hover', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    hoverBusy = false;
    if (r && r.label) { tip.textContent = r.label; tip.classList.remove('hidden'); } else tip.classList.add('hidden');
  });
});
stage.addEventListener('click', e => {
  post('pick', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    if (!r || !r.ok) return;
    found.unshift({ label: r.label, value: r.value }); foundTotal += r.value; renderFound();
    toast(`${r.label} - ${money(r.value)}`, 'success');
    if (r.revealed > 0) toast(t('hidden'), 'success');
    tip.classList.add('hidden');
  });
});
stage.addEventListener('wheel', e => post('fov', { d: e.deltaY > 0 ? 1 : -1 }));
$('#i-done').addEventListener('click', () => post('done'));

// ---------- results ----------
function onResults(d) {
  $('#results').classList.remove('hidden');
  let aw = '';
  aw += d.bestItem ? `<div class="award"><label>${t('best_find')}</label><b>${esc(d.bestItem.name)}</b><span>${t('sold_for', esc(d.bestItem.label), money(d.bestItem.value))}</span></div>`
    : `<div class="award"><label>${t('best_find')}</label><b>${t('nobody_award')}</b><span>${t('nothing_sold')}</span></div>`;
  aw += d.bigSpender ? `<div class="award"><label>${t('big_spender')}</label><b>${esc(d.bigSpender.name)}</b><span>${t('spent_lots', money(d.bigSpender.spent))}</span></div>`
    : `<div class="award"><label>${t('big_spender')}</label><b>${t('nobody_award')}</b><span>${t('nothing_bought')}</span></div>`;
  $('#r-awards').innerHTML = aw;
  $('#r-table').innerHTML = d.standings.map((s, i) =>
    `<div class="row"><span><b>${i + 1}.</b> ${esc(s.name)}</span><span class="muted small">${t('r_row', money(s.cash), money(s.spent), money(s.best))}</span></div>`).join('');
  $('#r-note').textContent = t('liquidated', d.liquidation);
}

// ---------- generic ----------
function closeModals() { ['#lobby', '#sell', '#results'].forEach(s => $(s).classList.add('hidden')); }
function onReset() {
  st = {}; dist = null;
  ['#hud', '#auction', '#inspect', '#banner', '#lobby', '#sell'].forEach(s => $(s).classList.add('hidden'));
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => post('close')));

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { post('close'); return; }
  if ($('#inspect').classList.contains('hidden')) return;
  const k = e.key.toLowerCase();
  if (k === 'w') post('cam', { dx: 0, dy: 1 });
  if (k === 's') post('cam', { dx: 0, dy: -1 });
  if (k === 'a') post('cam', { dx: -1, dy: 0 });
  if (k === 'd') post('cam', { dx: 1, dy: 0 });
});

const handlers = { state: onState, me: onMe, toast: d => toast(d.msg, d.type), dist: onDist, lobby: onLobby, lobbyUpdate: onLobbyUpdate,
  sell: onSell, inspect: onInspect, results: onResults, reset: onReset, close: closeModals };
window.addEventListener('message', e => {
  const m = e.data;
  if (!m || !handlers[m.action]) return;
  if (m.data && m.data.lang && m.data.lang !== LANG) { LANG = m.data.lang; applyStatic(); }
  handlers[m.action](m.data || {});
});
applyStatic();
