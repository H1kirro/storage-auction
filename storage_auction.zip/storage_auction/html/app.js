const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'storage_auction';
const money = n => '$' + Math.floor(n || 0).toLocaleString('en-US');
const KIND = { container: 'SHIPPING CONTAINER', garage: 'GARAGE' };
const PHASE = { travel: 'DRIVING', preview: 'PREVIEW', bidding: 'BIDDING', looting: 'LOOTING', between: 'NEXT LOT', final: 'FINAL SELL' };

function post(name, data) {
  return fetch(`https://${RES}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {})
  }).then(r => r.json()).catch(() => ({}));
}
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let st = {}, me = {}, endAt = 0, barTotal = 1, last = {}, dist = null, lobbyInfo = null, sellCtx = null, lastKind = null;
let found = [], foundTotal = 0;

// ---------- toasts / banner ----------
function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 4200);
  setTimeout(() => el.remove(), 4700);
}
let bannerTimer;
function banner(title, sub) {
  const b = $('#banner');
  b.classList.remove('hidden');
  b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  $('#b-title').textContent = title;
  $('#b-sub').textContent = sub || '';
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), 3200);
}

// ---------- state / HUD / auction ----------
function onState(d) {
  const prev = st;
  st = d;
  if (d.kind) lastKind = d.kind;
  endAt = Date.now() + (d.remaining || 0) * 1000;

  const active = d.state === 'travel' || d.state === 'round';
  $('#hud').classList.toggle('hidden', !active);
  if (!active) { $('#auction').classList.add('hidden'); return; }

  $('#h-round').textContent = `ROUND ${d.round} / ${d.rounds}`;
  $('#h-phase').textContent = d.state === 'travel' ? PHASE.travel : (PHASE[d.phase] || '');

  // timer bar reference
  const amountChanged = !prev.bid || !d.bid || prev.bid.amount !== d.bid.amount;
  if (d.phase !== prev.phase || d.state !== prev.state || amountChanged) barTotal = Math.max(1, d.remaining || 1);

  // banners
  if (d.state === 'travel' && (prev.state !== 'travel' || prev.round !== d.round)) {
    banner(`ROUND ${d.round}`, `Drive to ${d.locName || 'the location'}`);
  } else if (d.state === 'round') {
    if (d.phase === 'preview' && (prev.phase !== 'preview' || prev.lotIdx !== d.lotIdx)) banner(`LOT ${d.lotIdx} / ${d.lotCount}`, `${KIND[d.kind] || ''} - take a good look inside`);
    else if (d.phase === 'bidding' && prev.phase !== 'bidding') banner('BIDDING OPEN', 'Press 1-4 to raise the bid');
    else if (d.phase === 'looting' && prev.phase !== 'looting') banner(`SOLD to ${d.owner}`, money(d.bid.amount));
    else if (d.phase === 'between' && prev.phase === 'bidding') banner('NO BIDS', 'The lot is withdrawn');
    else if (d.phase === 'final' && prev.phase !== 'final') banner('FINAL CALL', 'Sell your loot before time runs out');
  }

  renderSub();
  renderAuction(amountChanged);
}

function renderSub() {
  const d = st;
  if (d.state === 'travel') {
    $('#h-sub').textContent = `Drive to ${d.locName || '?'}` + (dist != null ? `  -  ${dist >= 1000 ? (dist / 1000).toFixed(1) + ' km' : dist + ' m'}` : '');
  } else if (d.phase === 'final') {
    $('#h-sub').textContent = 'Sell everything to a buyer';
  } else {
    $('#h-sub').textContent = `Lot ${d.lotIdx} / ${d.lotCount}`;
  }
}

function renderAuction(bump) {
  const d = st, a = $('#auction');
  const show = d.state === 'round' && (d.phase === 'preview' || d.phase === 'bidding' || d.phase === 'looting');
  a.classList.toggle('hidden', !show);
  if (!show) return;

  $('#a-lot').textContent = `LOT ${d.lotIdx} / ${d.lotCount}`;
  $('#a-kind').textContent = KIND[d.kind || lastKind] || '';
  const amt = $('#a-amount'), who = $('#a-who'), keys = $('#a-keys'), hint = $('#a-hint');
  who.classList.remove('me');
  keys.innerHTML = '';

  if (d.phase === 'preview') {
    $('#a-label').textContent = 'STARTING BID';
    amt.textContent = money(d.startPrice);
    who.textContent = 'Bidding opens when the timer ends';
    hint.textContent = 'Walk up to the lot and check what is inside - think about whether it pays off.';
  } else if (d.phase === 'bidding') {
    const has = !!(d.bid && d.bid.bidder);
    $('#a-label').textContent = has ? 'CURRENT BID' : 'STARTING BID';
    amt.textContent = money(d.bid.amount);
    if (has) { who.textContent = d.lead ? 'You have the highest bid!' : `Highest bidder: ${d.bid.bidderName}`; if (d.lead) who.classList.add('me'); }
    else who.textContent = 'No bids yet';
    (d.steps || []).forEach((s, i) => { const k = document.createElement('span'); k.innerHTML = `<kbd>${i + 1}</kbd> +${money(s)}`; keys.appendChild(k); });
    hint.textContent = 'Every new bid restarts the countdown. Going once, going twice...';
  } else {
    $('#a-label').textContent = 'SOLD';
    amt.textContent = money(d.bid.amount);
    who.textContent = d.mine ? 'This lot is yours!' : `Winner: ${d.owner}`;
    if (d.mine) who.classList.add('me');
    hint.textContent = d.mine ? 'Take your time - and look behind the big things.' : 'The winner is going through the lot.';
  }
  if (bump) { amt.classList.remove('bump'); void amt.offsetWidth; amt.classList.add('bump'); }
}

function onMe(d) {
  me = d;
  $('#h-cash').textContent = money(d.cash);
  $('#h-spent').textContent = money(d.spent);
  $('#h-items').textContent = d.items;
}

function onDist(d) { dist = d.m; renderSub(); }

setInterval(() => {
  if ($('#hud').classList.contains('hidden')) return;
  const ms = Math.max(0, endAt - Date.now());
  const s = Math.ceil(ms / 1000);
  $('#h-timer').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const bar = $('#a-bar');
  const pct = Math.min(100, (ms / (barTotal * 1000)) * 100);
  bar.style.width = pct + '%';
  bar.classList.toggle('low', st.phase === 'bidding' && s <= 3);
}, 200);

// ---------- lobby ----------
function onLobby(d) {
  lobbyInfo = d.info;
  $('#lobby').classList.remove('hidden');
  setTab('match');
  renderLobby();
}
function onLobbyUpdate(d) { lobbyInfo = d.info; if (!$('#lobby').classList.contains('hidden')) renderLobby(); }

function setTab(t) {
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
  $('#tab-match').classList.toggle('hidden', t !== 'match');
  $('#tab-board').classList.toggle('hidden', t !== 'board');
  if (t === 'board') {
    $('#l-board').innerHTML = '<div class="muted">Loading...</div>';
    post('leaderboard').then(r => {
      const rows = r.rows || [];
      $('#l-board').innerHTML = rows.length ? rows.map((x, i) =>
        `<div class="row"><span><b>${i + 1}.</b> ${esc(x.name)}</span><span class="muted small">Titles ${(+x.best_wins || 0) + (+x.spender_wins || 0)} - Best find ${money(+x.best_ever || 0)} - Matches ${+x.matches || 0}</span></div>`
      ).join('') : '<div class="muted">No matches played yet.</div>';
    });
  }
}
$$('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));

function renderLobby() {
  const i = lobbyInfo; if (!i) return;
  const names = { idle: 'No match yet - be the first to join', lobby: 'Lobby is open', travel: 'Match in progress', round: 'Match in progress', ended: 'Match just finished' };
  $('#l-status').textContent = names[i.state] || 'Lobby';
  $('#l-count').textContent = `${i.count} / ${i.max}`;
  $('#l-players').innerHTML = i.players.length
    ? i.players.map(p => `<div class="row"><span>${esc(p.name)}${p.host ? '<span class="badge">HOST</span>' : ''}</span></div>`).join('')
    : '<div class="muted">Nobody yet.</div>';

  let html = '';
  for (let r = 1; r <= i.rounds; r++) {
    const v = i.containers[r - 1];
    html += `<div class="row"><span>Round ${r}</span><div class="step">` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="-1">-</button>` : '') +
      `<span>${v}</span>` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="1">+</button>` : '') +
      `</div></div>`;
  }
  $('#l-settings').innerHTML = html;
  $$('#l-settings button').forEach(b => b.addEventListener('click', () => {
    const r = +b.dataset.r, d = +b.dataset.d;
    const v = Math.max(1, Math.min(i.maxContainers, i.containers[r - 1] + d));
    post('setContainers', { round: r, value: v });
  }));
  $('#l-info').textContent = `Everyone starts with ${money(i.startMoney)}. ` + (i.fee > 0 ? `Entry fee ${money(i.fee)}. ` : '') +
    (i.isHost ? 'You are the host: set the number of lots per round and start when everyone is ready.' : 'Only the host can change settings and start the match.');

  const act = $('#l-actions');
  act.innerHTML = '';
  const add = (txt, cls, fn, dis) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = txt; b.disabled = !!dis; b.onclick = fn; act.appendChild(b); };
  add('Close', 'ghost', () => post('close'));
  if (i.joined && (i.state === 'lobby')) add('Leave', 'danger', () => post('lobbyLeave'));
  if (i.joined && i.state !== 'lobby') add('Leave match', 'danger', () => post('lobbyLeave'));
  if (!i.joined && (i.state === 'idle' || i.state === 'lobby')) add('Join match', '', () => post('lobbyJoin'));
  if (i.joined && i.isHost && i.state === 'lobby') add(`Start match${i.count < i.min ? ` (need ${i.min})` : ''}`, '', () => post('lobbyStart'), i.count < i.min);
}

// ---------- sell ----------
function onSell(d) { sellCtx = d; $('#sell').classList.remove('hidden'); renderSell(); }
function renderSell() {
  const { which, inv } = sellCtx;
  if (!inv) { post('close'); return; }
  $('#s-title').textContent = inv.title;
  $('#s-mult').textContent = 'x' + Number(inv.mult).toFixed(2);
  const total = inv.items.reduce((a, b) => a + b.offer, 0);
  $('#s-list').innerHTML = inv.items.length ? inv.items.map(it =>
    `<div class="row"><span>${esc(it.label)}</span><span><b>${money(it.offer)}</b> &nbsp;<button class="sellbtn" data-uid="${it.uid}">Sell</button></span></div>`
  ).join('') : '<div class="muted">You have nothing to sell.</div>';
  $('#s-all').textContent = `Sell all - ${money(total)}`;
  $('#s-all').disabled = !inv.items.length;
  $$('#s-list .sellbtn').forEach(b => b.addEventListener('click', () =>
    post('sell', { which, uid: +b.dataset.uid }).then(r => { sellCtx.inv = r.inv; renderSell(); })));
}
$('#s-all').addEventListener('click', () => post('sellAll', { which: sellCtx.which }).then(r => { sellCtx.inv = r.inv; renderSell(); }));

// ---------- inspect ----------
function onInspect(d) {
  $('#inspect').classList.toggle('hidden', !d.on);
  if (d.on) { found = []; foundTotal = 0; renderFound(); }
}
function renderFound() {
  $('#i-found').innerHTML = found.length ? found.map(f => `<div class="row found"><span>${esc(f.label)}</span><b>${money(f.value)}</b></div>`).join('')
    : '<div class="muted small">Nothing yet.</div>';
  $('#i-total').textContent = money(foundTotal);
}
const stage = $('#stage'), tip = $('#tip');
let hoverBusy = false;
stage.addEventListener('mousemove', e => {
  tip.style.left = e.clientX + 'px'; tip.style.top = e.clientY + 'px';
  if (hoverBusy) return;
  hoverBusy = true;
  post('hover', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    hoverBusy = false;
    if (r && r.label) { tip.textContent = r.label; tip.classList.remove('hidden'); } else tip.classList.add('hidden');
  });
});
stage.addEventListener('click', e => {
  post('pick', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    if (!r || !r.ok) return;
    found.unshift({ label: r.label, value: r.value }); foundTotal += r.value; renderFound();
    toast(`${r.label} - ${money(r.value)}`, 'success');
    if (r.revealed > 0) toast('Something was hiding behind it!', 'success');
    tip.classList.add('hidden');
  });
});
stage.addEventListener('wheel', e => post('fov', { d: e.deltaY > 0 ? 1 : -1 }));
$('#i-done').addEventListener('click', () => post('done'));

// ---------- results ----------
function onResults(d) {
  $('#results').classList.remove('hidden');
  let aw = '';
  aw += d.bestItem ? `<div class="award"><label>BEST FIND</label><b>${esc(d.bestItem.name)}</b><span>${esc(d.bestItem.label)} sold for ${money(d.bestItem.value)}</span></div>`
    : `<div class="award"><label>BEST FIND</label><b>Nobody</b><span>Nothing was sold</span></div>`;
  aw += d.bigSpender ? `<div class="award"><label>BIGGEST SPENDER</label><b>${esc(d.bigSpender.name)}</b><span>${money(d.bigSpender.spent)} spent on lots</span></div>`
    : `<div class="award"><label>BIGGEST SPENDER</label><b>Nobody</b><span>Nothing was bought</span></div>`;
  $('#r-awards').innerHTML = aw;
  $('#r-table').innerHTML = d.standings.map((s, i) =>
    `<div class="row"><span><b>${i + 1}.</b> ${esc(s.name)}</span><span class="muted small">Cash <b>${money(s.cash)}</b> - Spent ${money(s.spent)} - Best sale ${money(s.best)}</span></div>`).join('');
  $('#r-note').textContent = `Unsold items were liquidated at ${d.liquidation}%.`;
}

// ---------- generic ----------
function closeModals() { ['#lobby', '#sell', '#results'].forEach(s => $(s).classList.add('hidden')); }
function onReset() {
  st = {}; dist = null;
  ['#hud', '#auction', '#inspect', '#banner', '#lobby', '#sell'].forEach(s => $(s).classList.add('hidden'));
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => post('close')));

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { post('close'); return; }
  if ($('#inspect').classList.contains('hidden')) return;
  const k = e.key.toLowerCase();
  if (k === 'w') post('cam', { dx: 0, dy: 1 });
  if (k === 's') post('cam', { dx: 0, dy: -1 });
  if (k === 'a') post('cam', { dx: -1, dy: 0 });
  if (k === 'd') post('cam', { dx: 1, dy: 0 });
});

const handlers = { state: onState, me: onMe, toast: d => toast(d.msg, d.type), dist: onDist, lobby: onLobby, lobbyUpdate: onLobbyUpdate,
  sell: onSell, inspect: onInspect, results: onResults, reset: onReset, close: closeModals };
window.addEventListener('message', e => { const m = e.data; if (m && handlers[m.action]) handlers[m.action](m.data || {}); });
