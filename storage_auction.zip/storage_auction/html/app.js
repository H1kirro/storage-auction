window.addEventListener('message', function(event) {
    let data = event.data;
    if (data.action === "openAuction") {
        document.getElementById('auction-title').innerText = data.title;
        document.getElementById('auction-label').innerText = data.label;
        document.getElementById('current-bid').innerText = "$" + data.currentBid;
        document.getElementById('bidder-name').innerText = data.bidder;
        document.getElementById('timer').innerText = data.timeLeft;
        document.getElementById('auction-container').classList.remove('hidden');
    } else if (data.action === "updateBid") {
        document.getElementById('current-bid').innerText = "$" + data.currentBid;
        document.getElementById('bidder-name').innerText = data.bidder;
    } else if (data.action === "closeAuction") {
        document.getElementById('auction-container').classList.add('hidden');
    }
});

document.getElementById('btn-bid').addEventListener('click', function() {
    let val = parseInt(document.getElementById('bid-input').value);
    if (val && val > 0) {
        fetch(`https://${GetParentResourceName()}/placeBid`, {
            method: 'POST',
            body: JSON.stringify({ amount: val })
        });
    }
});

document.getElementById('btn-skip').addEventListener('click', function() {
    fetch(`https://${GetParentResourceName()}/skipSale`, {
        method: 'POST',
        body: JSON.stringify({})
    });
});
