const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'storage_auction';
const money = n => '$' + Math.floor(n || 0).toLocaleString('en-US');

let T = {};              // словник інтерфейсу (приходить з locale.lua)
let SKIPKEY = 'G';
const t = (k, ...a) => String(T[k] == null ? k : T[k]).replace(/\{(\d+)\}/g, (_, i) => (a[+i] == null ? '' : a[+i]));

function post(name, data) {
  return fetch(`https://${RES}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {})
  }).then(r => r.json()).catch(() => ({}));
}
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let st = {}, me = {}, endAt = 0, barTotal = 1, dist = null, lobbyInfo = null, sellCtx = null, lastKind = null, lastKindLabel = '';
let found = [], foundTotal = 0;

function applyStatic() {
  $$('[data-t]').forEach(el => { el.textContent = t(el.dataset.t); });
  $('#i-top').innerHTML = t('inspect_top');
}
function loadLocale() {
  post('uiReady').then(r => {
    if (r && r.L && r.L.round) { T = r.L; SKIPKEY = r.skipKey || 'G'; applyStatic(); }
    else setTimeout(loadLocale, 500);   // скрипт клієнта ще не готовий — пробуємо знову
  });
}
loadLocale();

// ---------- toasts / banner ----------
function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 4200);
  setTimeout(() => el.remove(), 4700);
}
let bannerTimer;
function banner(title, sub) {
  const b = $('#banner');
  b.classList.remove('hidden');
  b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  $('#b-title').textContent = title;
  $('#b-sub').textContent = sub || '';
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), 3200);
}

// ---------- state / HUD / auction ----------
function onState(d) {
  const prev = st;
  st = d;
  if (d.kind) { lastKind = d.kind; lastKindLabel = d.kindLabel || lastKindLabel; }
  endAt = Date.now() + (d.remaining || 0) * 1000;

  const active = d.state === 'travel' || d.state === 'round';
  $('#hud').classList.toggle('hidden', !active);
  if (!active) { $('#auction').classList.add('hidden'); return; }

  $('#h-round').textContent = t(d.bonus ? 'round_bonus' : 'round', d.round, d.rounds);
  const phaseKey = d.state === 'travel' ? 'ph_travel' : ('ph_' + (d.phase || ''));
  $('#h-phase').textContent = T[phaseKey] || '';

  const amountChanged = !prev.bid || !d.bid || prev.bid.amount !== d.bid.amount;
  if (d.phase !== prev.phase || d.state !== prev.state || amountChanged) barTotal = Math.max(1, d.remaining || 1);

  if (d.state === 'travel' && (prev.state !== 'travel' || prev.round !== d.round)) {
    banner(t(d.bonus ? 'banner_bonus' : 'banner_round', d.round), t('banner_drive', d.locName || ''));
  } else if (d.state === 'round') {
    if (d.phase === 'preview' && (prev.phase !== 'preview' || prev.lotIdx !== d.lotIdx)) banner(t('banner_lot', d.lotIdx, d.lotCount), t('banner_lot_sub', d.kindLabel || ''));
    else if (d.phase === 'bidding' && prev.phase !== 'bidding') banner(t('banner_bid'), t('banner_bid_sub'));
    else if (d.phase === 'looting' && prev.phase !== 'looting') banner(t('banner_sold', d.owner), money(d.bid.amount));
    else if (d.phase === 'between' && prev.phase === 'bidding') banner(t('banner_nobids'), t('banner_nobids_sub'));
    else if (d.phase === 'final' && prev.phase !== 'final') banner(t('banner_final'), t('banner_final_sub'));
  }

  renderSub();
  renderSkip();
  renderAuction(amountChanged);
}

function renderSub() {
  const d = st;
  if (d.state === 'travel') {
    $('#h-sub').textContent = t('drive_to', d.locName || '?') + (dist != null ? `  -  ${dist >= 1000 ? (dist / 1000).toFixed(1) + ' ' + t('km') : dist + ' ' + t('m')}` : '');
  } else if (d.phase === 'final') {
    $('#h-sub').textContent = t('sell_everything');
  } else {
    $('#h-sub').textContent = t('lot_n', d.lotIdx, d.lotCount);
  }
}

function renderSkip() {
  const el = $('#h-skip'), d = st;
  const show = d.state === 'round' && d.canSkip;
  el.classList.toggle('hidden', !show);
  if (!show) return;
  el.classList.toggle('done', !!d.iReady);
  el.textContent = d.iReady ? t('skip_done', d.readyN, d.total) : t('skip_hint', d.readyN, d.total, SKIPKEY);
}

function renderAuction(bump) {
  const d = st, a = $('#auction');
  const show = d.state === 'round' && (d.phase === 'preview' || d.phase === 'bidding' || d.phase === 'looting');
  a.classList.toggle('hidden', !show);
  if (!show) return;

  $('#a-lot').textContent = t('banner_lot', d.lotIdx, d.lotCount);
  $('#a-kind').textContent = (d.kindLabel || lastKindLabel || '').toUpperCase();
  const amt = $('#a-amount'), who = $('#a-who'), keys = $('#a-keys'), hint = $('#a-hint');
  who.classList.remove('me');
  keys.innerHTML = '';

  if (d.phase === 'preview') {
    $('#a-label').textContent = t('starting_bid');
    amt.textContent = money(d.startPrice);
    who.textContent = t('bid_opens');
    hint.textContent = t('preview_hint');
  } else if (d.phase === 'bidding') {
    const has = !!(d.bid && d.bid.bidder);
    $('#a-label').textContent = has ? t('current_bid') : t('starting_bid');
    amt.textContent = money(d.bid.amount);
    if (has) { who.textContent = d.lead ? t('you_lead') : t('high_bidder', d.bid.bidderName); if (d.lead) who.classList.add('me'); }
    else who.textContent = t('no_bids_yet');
    (d.steps || []).forEach((s, i) => { const k = document.createElement('span'); k.innerHTML = `<kbd>${i + 1}</kbd> +${money(s)}`; keys.appendChild(k); });
    hint.textContent = t('bid_hint');
  } else {
    $('#a-label').textContent = t('sold');
    amt.textContent = money(d.bid.amount);
    who.textContent = d.mine ? t('mine') : t('winner', d.owner);
    if (d.mine) who.classList.add('me');
    hint.textContent = d.mine ? t('mine_hint') : t('other_hint');
  }
  if (bump) { amt.classList.remove('bump'); void amt.offsetWidth; amt.classList.add('bump'); }
}

function onMe(d) {
  me = d;
  $('#h-cash').textContent = money(d.cash);
  $('#h-spent').textContent = money(d.spent);
  $('#h-items').textContent = d.items;
}

function onDist(d) { dist = d.m; renderSub(); }

setInterval(() => {
  if ($('#hud').classList.contains('hidden')) return;
  const ms = Math.max(0, endAt - Date.now());
  const s = Math.ceil(ms / 1000);
  $('#h-timer').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const bar = $('#a-bar');
  const pct = Math.min(100, (ms / (barTotal * 1000)) * 100);
  bar.style.width = pct + '%';
  bar.classList.toggle('low', st.phase === 'bidding' && s <= 3);
}, 200);

// ---------- lobby ----------
function onLobby(d) {
  lobbyInfo = d.info;
  $('#lobby').classList.remove('hidden');
  setTab('match');
  renderLobby();
}
function onLobbyUpdate(d) { lobbyInfo = d.info; if (!$('#lobby').classList.contains('hidden')) renderLobby(); }

function setTab(tab) {
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $('#tab-match').classList.toggle('hidden', tab !== 'match');
  $('#tab-board').classList.toggle('hidden', tab !== 'board');
  if (tab === 'board') {
    $('#l-board').innerHTML = `<div class="muted">${esc(t('loading'))}</div>`;
    post('leaderboard').then(r => {
      const rows = r.rows || [];
      $('#l-board').innerHTML = rows.length ? rows.map((x, i) =>
        `<div class="row"><span><b>${i + 1}.</b> ${esc(x.name)}</span><span class="muted small">${esc(t('board_row', (+x.best_wins || 0) + (+x.spender_wins || 0), money(+x.best_ever || 0), +x.matches || 0))}</span></div>`
      ).join('') : `<div class="muted">${esc(t('no_matches'))}</div>`;
    });
  }
}
$$('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));

function renderLobby() {
  const i = lobbyInfo; if (!i) return;
  const names = { idle: t('st_idle'), lobby: t('st_lobby'), travel: t('st_run'), round: t('st_run'), ended: t('st_end') };
  $('#l-status').textContent = names[i.state] || t('lobby');
  $('#l-count').textContent = `${i.count} / ${i.max}`;
  $('#l-players').innerHTML = i.players.length
    ? i.players.map(p => `<div class="row"><span>${esc(p.name)}${p.host ? `<span class="badge">${esc(t('host'))}</span>` : ''}</span></div>`).join('')
    : `<div class="muted">${esc(t('nobody'))}</div>`;

  let html = '';
  for (let r = 1; r <= i.rounds; r++) {
    const v = i.containers[r - 1];
    const nm = (i.roundNames && i.roundNames[r - 1]) || ('#' + r);
    const bonus = i.roundBonus && i.roundBonus[r - 1];
    html += `<div class="row"><span>${esc(nm)}${bonus ? '<span class="badge bonus">BONUS</span>' : ''}</span><div class="step">` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="-1">-</button>` : '') +
      `<span>${v}</span>` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="1">+</button>` : '') +
      `</div></div>`;
  }
  $('#l-settings').innerHTML = html;
  $$('#l-settings button').forEach(b => b.addEventListener('click', () => {
    const r = +b.dataset.r, d = +b.dataset.d;
    const v = Math.max(1, Math.min(i.maxContainers, i.containers[r - 1] + d));
    post('setContainers', { round: r, value: v });
  }));
  $('#l-info').textContent = t('start_money', money(i.startMoney)) + (i.fee > 0 ? t('fee', money(i.fee)) : '') +
    (i.isHost ? t('host_info') : t('guest_info'));

  const act = $('#l-actions');
  act.innerHTML = '';
  const add = (txt, cls, fn, dis) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = txt; b.disabled = !!dis; b.onclick = fn; act.appendChild(b); };
  add(t('close'), 'ghost', () => post('close'));
  if (i.joined && (i.state === 'lobby')) add(t('leave'), 'danger', () => post('lobbyLeave'));
  if (i.joined && i.state !== 'lobby') add(t('leave_match'), 'danger', () => post('lobbyLeave'));
  if (!i.joined && (i.state === 'idle' || i.state === 'lobby')) add(t('join'), '', () => post('lobbyJoin'));
  if (i.joined && i.isHost && i.state === 'lobby') add(t('start') + (i.count < i.min ? ' ' + t('need', i.min) : ''), '', () => post('lobbyStart'), i.count < i.min);
}

// ---------- sell ----------
function onSell(d) { sellCtx = d; $('#sell').classList.remove('hidden'); renderSell(); }
function renderSell() {
  const { which, inv } = sellCtx;
  if (!inv) { post('close'); return; }
  $('#s-title').textContent = inv.title;
  $('#s-mult').textContent = 'x' + Number(inv.mult).toFixed(2);
  const total = inv.items.reduce((a, b) => a + b.offer, 0);
  $('#s-list').innerHTML = inv.items.length ? inv.items.map(it =>
    `<div class="row"><span>${esc(it.label)}</span><span><b>${money(it.offer)}</b> &nbsp;<button class="sellbtn" data-uid="${it.uid}">${esc(t('sell'))}</button></span></div>`
  ).join('') : `<div class="muted">${esc(t('nothing'))}</div>`;
  $('#s-all').textContent = t('sell_all', money(total));
  $('#s-all').disabled = !inv.items.length;
  const sk = $('#s-skip');
  sk.classList.toggle('hidden', !inv.canSkip);
  sk.disabled = !!inv.skipped;
  $$('#s-list .sellbtn').forEach(b => b.addEventListener('click', () =>
    post('sell', { which, uid: +b.dataset.uid }).then(r => { sellCtx.inv = r.inv; renderSell(); })));
}
$('#s-all').addEventListener('click', () => post('sellAll', { which: sellCtx.which }).then(r => { sellCtx.inv = r.inv; renderSell(); }));
$('#s-skip').addEventListener('click', () => post('skip', { which: sellCtx.which }).then(r => { if (r.inv) { sellCtx.inv = r.inv; renderSell(); } }));

// ---------- inspect ----------
function onInspect(d) {
  $('#inspect').classList.toggle('hidden', !d.on);
  if (d.on) { found = []; foundTotal = 0; renderFound(); }
}
function renderFound() {
  $('#i-found').innerHTML = found.length ? found.map(f => `<div class="row found"><span>${esc(f.label)}</span><b>${money(f.value)}</b></div>`).join('')
    : `<div class="muted small">${esc(t('nothing_yet'))}</div>`;
  $('#i-total').textContent = money(foundTotal);
}
const stage = $('#stage'), tip = $('#tip');
let hoverBusy = false;
stage.addEventListener('mousemove', e => {
  tip.style.left = e.clientX + 'px'; tip.style.top = e.clientY + 'px';
  if (hoverBusy) return;
  hoverBusy = true;
  post('hover', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    hoverBusy = false;
    if (r && r.label) { tip.textContent = r.label; tip.classList.remove('hidden'); } else tip.classList.add('hidden');
  });
});
stage.addEventListener('click', e => {
  post('pick', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    if (!r || !r.ok) return;
    found.unshift({ label: r.label, value: r.value }); foundTotal += r.value; renderFound();
    toast(t('found_toast', r.label, money(r.value)), 'success');
    if (r.jackpot) banner(t('banner_lucky'), t('banner_lucky_sub'));
    else if (r.revealed > 0) toast(T.hidden_found_ui || '✦', 'success');
    tip.classList.add('hidden');
  });
});
stage.addEventListener('wheel', e => post('fov', { d: e.deltaY > 0 ? 1 : -1 }));
$('#i-done').addEventListener('click', () => post('done'));

// ---------- results ----------
function onResults(d) {
  $('#results').classList.remove('hidden');
  let aw = '';
  aw += d.bestItem ? `<div class="award"><label>${esc(t('best_find'))}</label><b>${esc(d.bestItem.name)}</b><span>${esc(t('sold_for', d.bestItem.label, money(d.bestItem.value)))}</span></div>`
    : `<div class="award"><label>${esc(t('best_find'))}</label><b>—</b><span>${esc(t('none_sold'))}</span></div>`;
  aw += d.bigSpender ? `<div class="award"><label>${esc(t('big_spender'))}</label><b>${esc(d.bigSpender.name)}</b><span>${esc(t('spent_on', money(d.bigSpender.spent)))}</span></div>`
    : `<div class="award"><label>${esc(t('big_spender'))}</label><b>—</b><span>${esc(t('none_bought'))}</span></div>`;
  $('#r-awards').innerHTML = aw;
  $('#r-table').innerHTML = d.standings.map((s, i) =>
    `<div class="row"><span><b>${i + 1}.</b> ${esc(s.name)}</span><span class="muted small">${t('row_res', money(s.cash), money(s.spent), money(s.best))}</span></div>`).join('');
  $('#r-note').textContent = t('liquidated', d.liquidation);
}

// ---------- generic ----------
function closeModals() { ['#lobby', '#sell', '#results'].forEach(s => $(s).classList.add('hidden')); }
function onReset() {
  st = {}; dist = null;
  ['#hud', '#auction', '#inspect', '#banner', '#lobby', '#sell'].forEach(s => $(s).classList.add('hidden'));
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => post('close')));

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { post('close'); return; }
  if ($('#inspect').classList.contains('hidden')) return;
  const k = e.key.toLowerCase();
  if (k === 'w') post('cam', { dx: 0, dy: 1 });
  if (k === 's') post('cam', { dx: 0, dy: -1 });
  if (k === 'a') post('cam', { dx: -1, dy: 0 });
  if (k === 'd') post('cam', { dx: 1, dy: 0 });
});

const handlers = { state: onState, me: onMe, toast: d => toast(d.msg, d.type), dist: onDist, lobby: onLobby, lobbyUpdate: onLobbyUpdate,
  sell: onSell, inspect: onInspect, results: onResults, reset: onReset, close: closeModals };
window.addEventListener('message', e => { const m = e.data; if (m && handlers[m.action]) handlers[m.action](m.data || {}); });
