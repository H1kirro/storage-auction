-- loc = { coords = vec3, heading = number, [width], [depth], [kind], [existing], [far] }
-- Локальні координати: x = вправо, y = вперед (туди, куди відкривається лот), початок = двері контейнера.

function L(key, ...)
    local pack = Locales[Config.Locale] or Locales.ru
    local s = pack[key] or Locales.ru[key] or key
    if select('#', ...) > 0 then return s:format(...) end
    return s
end

function LocalToWorld(loc, lx, ly)
    local h = math.rad(loc.heading)
    local c, s = math.cos(h), math.sin(h)
    return vec3(loc.coords.x + lx * c - ly * s, loc.coords.y + lx * s + ly * c, loc.coords.z)
end

-- Розміри лоту (для гаражів на мапі можна задати width/depth прямо в локації)
function LotDims(kind, loc)
    local T = Config.LotTypes[kind]
    return (loc and loc.width) or T.width, (loc and loc.depth) or T.depth, (loc and loc.height) or T.height
end

function GetGrid(kind, loc)
    local T = Config.LotTypes[kind]
    local w, d = LotDims(kind, loc)
    return math.max(1, math.floor(w / T.cell)), math.max(2, math.floor(d / T.cell))
end

-- col 1..cols, row 1..rows (row 1 найближче до дверей)
function GetSlotPos(kind, col, row, loc)
    local cols, rows = GetGrid(kind, loc)
    local w, d = LotDims(kind, loc)
    local lx = (col - (cols + 1) / 2) * (w / cols)
    local ly = (row - 0.5) * (d / rows)
    return lx, ly
end

function GetAuctioneerPos(loc)
    local a = Config.Layout.auctioneer
    return LocalToWorld(loc, a.x, a.y)
end

function GetBuyerPos(loc)
    local b = Config.Layout.buyer
    return LocalToWorld(loc, b.x, b.y)
end

-- Колекціонер стоїть недалеко від лоту (або в точці loc.far, якщо задана)
function GetFarPos(loc)
    local p
    if loc.far then
        p = vec3(loc.far.x, loc.far.y, loc.far.z)
    else
        local o = Config.Layout.far
        p = LocalToWorld(loc, o.x, o.y)
    end
    local dx, dy = loc.coords.x - p.x, loc.coords.y - p.y
    local heading = (math.deg(math.atan(-dx, dy))) % 360.0
    return p, heading
end
