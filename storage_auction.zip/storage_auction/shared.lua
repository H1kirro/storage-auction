-- loc = { coords = vec3, heading = number }
-- Local space: x = right, y = forward (the direction the lot opens INTO), origin = lot door.

function LocalToWorld(loc, lx, ly)
    local h = math.rad(loc.heading)
    local c, s = math.cos(h), math.sin(h)
    return vec3(loc.coords.x + lx * c - ly * s, loc.coords.y + lx * s + ly * c, loc.coords.z)
end

-- d = { width, depth, cell }
function GetGrid(d)
    return math.max(1, math.floor(d.width / d.cell)), math.max(2, math.floor(d.depth / d.cell))
end

-- col 1..cols, row 1..rows (row 1 is nearest to the door)
function GetSlotPos(d, col, row)
    local cols, rows = GetGrid(d)
    local lx = (col - (cols + 1) / 2) * (d.width / cols)
    local ly = (row - 0.5) * (d.depth / rows)
    return lx, ly
end

-- The collector stands close to the lot (default: behind the crowd). Returns vec3, heading
function GetCollectorPos(loc)
    if loc.collector then
        return vec3(loc.collector.x, loc.collector.y, loc.collector.z), (loc.collector.w or loc.heading)
    end
    local o = Config.CollectorOffset
    return LocalToWorld(loc, o.x, o.y), loc.heading + 180.0
end

function LocName(loc, lang)
    return (lang == 'ru' and loc.ru) or loc.name
end
