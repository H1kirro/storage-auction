-- Deterministic layout so server and clients agree on where every storage is.
-- loc = { coords = vec3, heading = number }, index = 1..count

function GetLayoutPos(loc, index, count)
    local cols = math.min(Config.Layout.columns, count)
    local col = (index - 1) % cols
    local row = math.floor((index - 1) / cols)
    local lx = (col - (cols - 1) / 2) * Config.Layout.spacing
    local ly = row * Config.Layout.spacing
    local h = math.rad(loc.heading)
    local c, s = math.cos(h), math.sin(h)
    return vec3(loc.coords.x + lx * c - ly * s, loc.coords.y + lx * s + ly * c, loc.coords.z)
end

function GetBuyerPos(loc)
    local h = math.rad(loc.heading)
    local ly = -Config.Layout.buyerOffset
    return vec3(loc.coords.x - ly * math.sin(h), loc.coords.y + ly * math.cos(h), loc.coords.z)
end
