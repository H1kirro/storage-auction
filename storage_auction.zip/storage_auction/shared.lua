Shared = Shared or {}

Shared.Lang = {
    currency = '$',
    auction_title = 'АУКЦИОН КОНТЕЙНЕРОВ',
    bonus_auction_title = 'БОНУСНЫЙ РАУНД: ГАРАЖ',
    current_bid = 'Текущая ставка:',
    bid_by = 'Сделал:',
    time_left = 'Осталось времени:',
    place_bid = 'Сделать ставку',
    skip_sale = 'Пропустить продажу / Готово',
    sold_out = 'Все вещи успешно проданы!',
    no_bids = 'Ставок нет',
    winner_announcement = 'Контейнер выиграл: ',
    garage_winner = 'Бонусный гараж выиграл: ',
    cover_secret = 'Часть содержимого скрыта тентом!',
    closet_secret = 'Внутри находится секретный объект!'
}

Shared.CoverProps = {
    `prop_tarps_01`,
    `prop_tarps_02`,
    `prop_canvas_01`,
    `prop_boxpile_06b`
}

Shared.ClosetProps = {
    `prop_cabinet_01`,
    `prop_cabinet_02`,
    `prop_rub_cabinet_01`,
    `p_office_rub_cov_01`
}

Shared.FastVehicleUpgrades = function(vehicle)
    SetVehicleModKit(vehicle, 0)
    SetVehicleMod(vehicle, 11, GetNumVehicleMods(vehicle, 11) - 1, false) -- Engine
    SetVehicleMod(vehicle, 12, GetNumVehicleMods(vehicle, 12) - 1, false) -- Brakes
    SetVehicleMod(vehicle, 13, GetNumVehicleMods(vehicle, 13) - 1, false) -- Transmission
    ToggleVehicleMod(vehicle, 18, true) -- Turbo
    SetVehicleTyresCanBurst(vehicle, false)
end
