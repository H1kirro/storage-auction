-- Version check: all files must come from the same zip
if Config.Version ~= '4.2' then
    print('^1[storage_auction] OLD or WRONG config.lua (version: ' .. tostring(Config.Version) .. '). Replace ALL files with the ones from storage_auction.zip!^0')
end

Locales = {}

Locales.en = {
    join_running = 'A match is already running.',
    join_already = 'You already joined.',
    join_full = 'The lobby is full.',
    join_fee = 'You cannot afford the entry fee.',
    joined = 'You joined the lobby.',
    only_host = 'Only the host can start the match.',
    need_players = 'You need at least %d players.',
    no_rounds = 'No active rounds. Set at least one lot.',
    travel = 'Round %d: drive to %s. The round starts when everyone has arrived.',
    travel_bonus = 'BONUS round: drive to %s. The round starts when everyone has arrived.',
    collector_hint = 'The collector (pays x%.1f) is near the lot and marked on your map.',
    arrived = 'You arrived. Waiting for the others...',
    lot_won = '%s won the lot for $%d!',
    no_bids = 'No bids. The lot is withdrawn.',
    final_call = 'Final call! Sell your loot. Press G to skip selling.',
    bid_closed = 'Bidding is not open.',
    bid_far = 'You are too far from the auction.',
    bid_leader = 'You already have the highest bid.',
    bid_cash = 'Not enough money.',
    car_wait = 'Wait a bit before requesting another car.',
    sold_big = '%s sold %s for $%d!',
    ready_skip = 'You skipped selling.',
    admin_only = 'Admins only.',
    test_on = 'Test lot shown. Use /storagetestend to remove it.',
    ride_here = 'Your ride is here. Good luck!',
    buyer_far = 'The buyer is too far away.',
    left_match = 'You left the match.',
    sold_one = 'Sold for %s',
    sold_all = 'Sold everything for %s',
    hidden_found = 'Something was hiding under it!',
    help_lobby = 'Press ~INPUT_CONTEXT~ to open Storage Wars',
    help_sell = 'Press ~INPUT_CONTEXT~ to sell your items',
    help_collector = 'Press ~INPUT_CONTEXT~ to sell to the collector (x%.1f)',
    help_inspect = 'Press ~INPUT_CONTEXT~ to inspect your lot',
    blip_lobby = 'Storage Wars',
    blip_lot = 'Storage Wars: lot',
    blip_bonus = 'Storage Wars: BONUS garage',
    blip_collector = 'Collector (x%.1f)',
    npc_lobby = 'STORAGE WARS',
    npc_auctioneer = 'AUCTIONEER',
    npc_buyer = 'BUYER (x%.1f)',
    npc_collector = 'COLLECTOR (x%.1f)',
    buyer_local = 'Local buyer',
    buyer_collector = 'Collector',
    sign_lot = 'LOT %d / %d  -  %s',
}

Locales.ru = {
    join_running = 'Матч уже идёт.',
    join_already = 'Вы уже в лобби.',
    join_full = 'Лобби заполнено.',
    join_fee = 'Не хватает денег на взнос.',
    joined = 'Вы вошли в лобби.',
    only_host = 'Только хост может начать матч.',
    need_players = 'Нужно минимум %d игрока(ов).',
    no_rounds = 'Нет активных раундов. Задайте хотя бы один лот.',
    travel = 'Раунд %d: езжайте в %s. Раунд начнётся, когда все приедут.',
    travel_bonus = 'БОНУСНЫЙ раунд: езжайте в %s. Раунд начнётся, когда все приедут.',
    collector_hint = 'Скупщик (платит x%.1f) стоит рядом с лотом и отмечен на карте.',
    arrived = 'Вы на месте. Ждём остальных...',
    lot_won = '%s выиграл лот за $%d!',
    no_bids = 'Ставок нет. Лот снят с торгов.',
    final_call = 'Последний шанс! Продайте добычу. Нажмите G, чтобы пропустить продажу.',
    bid_closed = 'Торги сейчас закрыты.',
    bid_far = 'Вы слишком далеко от аукциона.',
    bid_leader = 'Вы уже лидируете.',
    bid_cash = 'Не хватает денег.',
    car_wait = 'Подождите немного перед новой машиной.',
    sold_big = '%s продал «%s» за $%d!',
    ready_skip = 'Вы пропустили продажу.',
    admin_only = 'Только для админов.',
    test_on = 'Тестовый лот показан. Уберите его командой /storagetestend.',
    ride_here = 'Ваша машина готова. Удачи!',
    buyer_far = 'Скупщик слишком далеко.',
    left_match = 'Вы покинули матч.',
    sold_one = 'Продано за %s',
    sold_all = 'Всё продано за %s',
    hidden_found = 'Под этим что-то пряталось!',
    help_lobby = 'Нажмите ~INPUT_CONTEXT~, чтобы открыть Storage Wars',
    help_sell = 'Нажмите ~INPUT_CONTEXT~, чтобы продать вещи',
    help_collector = 'Нажмите ~INPUT_CONTEXT~, чтобы продать коллекционеру (x%.1f)',
    help_inspect = 'Нажмите ~INPUT_CONTEXT~, чтобы осмотреть свой лот',
    blip_lobby = 'Storage Wars',
    blip_lot = 'Storage Wars: лот',
    blip_bonus = 'Storage Wars: БОНУС гараж',
    blip_collector = 'Скупщик (x%.1f)',
    npc_lobby = 'STORAGE WARS',
    npc_auctioneer = 'АУКЦИОНИСТ',
    npc_buyer = 'СКУПЩИК (x%.1f)',
    npc_collector = 'КОЛЛЕКЦИОНЕР (x%.1f)',
    buyer_local = 'Местный скупщик',
    buyer_collector = 'Коллекционер',
    sign_lot = 'ЛОТ %d / %d  -  %s',
}

function T(lang, key, ...)
    local s = (Locales[lang] and Locales[lang][key]) or Locales.en[key] or key
    if select('#', ...) > 0 then return s:format(...) end
    return s
end


-- loc = { coords = vec3, heading = number }
-- Local space: x = right, y = forward (the direction the lot opens INTO), origin = lot door.

function LocalToWorld(loc, lx, ly)
    local h = math.rad(loc.heading)
    local c, s = math.cos(h), math.sin(h)
    return vec3(loc.coords.x + lx * c - ly * s, loc.coords.y + lx * s + ly * c, loc.coords.z)
end

-- d = { width, depth, cell }
function GetGrid(d)
    return math.max(1, math.floor(d.width / d.cell)), math.max(2, math.floor(d.depth / d.cell))
end

-- col 1..cols, row 1..rows (row 1 is nearest to the door)
function GetSlotPos(d, col, row)
    local cols, rows = GetGrid(d)
    local lx = (col - (cols + 1) / 2) * (d.width / cols)
    local ly = (row - 0.5) * (d.depth / rows)
    return lx, ly
end

-- The collector stands close to the lot (default: behind the crowd). Returns vec3, heading
function GetCollectorPos(loc)
    if loc.collector then
        return vec3(loc.collector.x, loc.collector.y, loc.collector.z), (loc.collector.w or loc.heading)
    end
    local o = Config.CollectorOffset
    return LocalToWorld(loc, o.x, o.y), loc.heading + 180.0
end

function LocName(loc, lang)
    return (lang == 'ru' and loc.ru) or loc.name
end
