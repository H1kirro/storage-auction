Config = {}

-- ============ General ============
-- Real server money is OPTIONAL (entry fee + prizes). Match money is always virtual.
-- 'none' | 'esx' | 'qb'
Config.Framework = 'none'
Config.QBAccount = 'cash'
Config.EntryFee = 0                       -- real money, paid when joining (refunded if you leave the lobby)
Config.Prizes = { bestItem = 0, bigSpender = 0 }   -- real money paid to the award winners

-- Needs OneSync. Server checks that players really are near storages/buyer.
-- Set to false only if you do not use OneSync.
Config.ServerDistanceChecks = true

-- ============ Match ============
Config.MinPlayers = 2
Config.MaxPlayers = 8
Config.LobbySeconds = 30                  -- countdown starts when MinPlayers is reached
Config.StartMoney = 10000                 -- same for every player (virtual match money)
Config.ArrivalRadius = 60.0               -- how close you must get to the new location
Config.InteractRadius = 2.5
Config.LiquidationRate = 0.5              -- unsold items at the end are auto-sold at this rate (they don't count for "best item")
Config.ResultsSeconds = 20
Config.BigSaleAnnounce = 1500             -- sales at/above this are announced to all players

Config.OpenTimeMs = 6000                  -- time to open a storage
Config.SearchTimeMs = 9000                -- time to search for hidden compartments
Config.PreviewItems = 2                   -- items visible from outside before buying

-- Price noise so the price never gives away the contents (0.25 = +-25%)
Config.PriceNoise = 0.25

-- ============ Lobby (where players join / see leaderboard) ============
Config.Lobby = {
    coords = vec4(195.2, -934.0, 30.7, 144.0),
    ped = 's_m_m_dockwork_01',
    blip = { sprite = 478, colour = 5, text = 'Storage Wars' }
}

-- ============ Layout of storages at a location ============
Config.Layout = {
    columns = 5,        -- storages per row
    spacing = 4.0,      -- metres between storages
    buyerOffset = 8.0   -- buyer NPC stands this far behind the first row
}
Config.BuyerPed = 'a_m_m_business_01'
-- Prop used for the storages in each round (falls back to a cardboard box if the model is invalid)
Config.Props = { 'prop_cs_cardbox_01', 'prop_box_wood05a', 'prop_container_ld2' }

-- ============ Rounds ============
-- Each round picks ONE random location from its list. Players must DRIVE there.
-- Later rounds: more storages, more items, higher prices, more valuable stuff, more hidden things.
-- Storages per round are always between 3 and 20.
-- IMPORTANT: coords are approximate. Stand at the spot you want in-game, grab your coords and
-- adjust. Pick flat, open ground with room for rows of storages. heading = direction the rows grow.
Config.Rounds = {
    {
        seconds = 360, travelSeconds = 120,
        storageMin = 3, storageMax = 8,
        itemsMin = 2, itemsMax = 4,
        priceMin = 500, priceMax = 1200,
        valueScale = 1.0,
        concealedChance = 0.10,      -- chance a storage has a hidden compartment
        locations = {
            { name = 'Sandy Shores Airfield', coords = vec3(1747.0, 3273.7, 41.1), heading = 30.0 },
            { name = 'McKenzie Airfield',     coords = vec3(2122.0, 4805.0, 41.2), heading = 90.0 },
        }
    },
    {
        seconds = 420, travelSeconds = 180,
        storageMin = 6, storageMax = 14,
        itemsMin = 3, itemsMax = 6,
        priceMin = 1000, priceMax = 2400,
        valueScale = 1.6,
        concealedChance = 0.25,
        locations = {
            { name = 'Maze Bank Arena Lot', coords = vec3(-250.0, -2025.0, 30.1), heading = 50.0 },
            { name = 'Cypress Flats Yard',  coords = vec3(1009.0, -2500.0, 28.4), heading = 80.0 },
        }
    },
    {
        seconds = 480, travelSeconds = 240,
        storageMin = 10, storageMax = 20,
        itemsMin = 4, itemsMax = 8,
        priceMin = 2000, priceMax = 4800,
        valueScale = 2.4,
        concealedChance = 0.45,
        locations = {
            { name = 'Paleto Sawmill Yard', coords = vec3(-550.0, 5325.0, 70.4), heading = 160.0 },
            { name = 'Grapeseed Farmland',  coords = vec3(2440.0, 4975.0, 46.0), heading = 45.0 },
        }
    },
}

-- ============ Storage quality tiers (hidden from players) ============
-- luck: multiplies the chance of rare loot. priceMul: slightly correlates price with quality.
Config.Tiers = {
    { name = 'junk',    chance = 35, luck = 0.2, priceMul = 0.6 },
    { name = 'average', chance = 40, luck = 1.0, priceMul = 0.9 },
    { name = 'good',    chance = 20, luck = 2.5, priceMul = 1.2 },
    { name = 'jackpot', chance = 5,  luck = 6.0, priceMul = 1.5 },
}

Config.Teasers = {
    'Dusty boxes stacked to the ceiling',
    'Locked chest and a tarp-covered shape',
    'Old furniture and a few sealed crates',
    'Smells like mold, lots of cardboard',
    'Looks like someone left in a hurry',
    'Neatly packed, label-less crates',
    'Garage sale leftovers',
    'Heavy metal cases in the back',
}

-- ============ Loot ============
-- value is multiplied by the round's valueScale. rare = true items are the only
-- ones that can show up in hidden compartments.
Config.Loot = {
    { label = 'Broken Lamp',            min = 10,   max = 60,   weight = 30 },
    { label = 'Box of Old Magazines',   min = 20,   max = 90,   weight = 30 },
    { label = 'Rusty Toolbox',          min = 40,   max = 150,  weight = 25 },
    { label = 'Vintage Radio',          min = 120,  max = 400,  weight = 18 },
    { label = 'Crate of Old Vinyl',     min = 150,  max = 500,  weight = 15 },
    { label = 'Antique Clock',          min = 250,  max = 700,  weight = 10 },
    { label = 'Designer Handbag',       min = 400,  max = 1100, weight = 6,  rare = true },
    { label = 'Signed Sports Jersey',   min = 500,  max = 1400, weight = 5,  rare = true },
    { label = 'Gold Pocket Watch',      min = 900,  max = 2200, weight = 3,  rare = true },
    { label = 'Original Oil Painting',  min = 1500, max = 4000, weight = 2,  rare = true },
    { label = 'Mystery Safe (cracked)', min = 2500, max = 6000, weight = 1,  rare = true },
}
