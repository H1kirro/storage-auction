Config = {}
Config.Version = '4.4'

-- ============ General ============
-- Real server money is OPTIONAL (entry fee + prizes). Match money is always virtual.
-- 'none' | 'esx' | 'qb'
Config.Framework = 'none'
Config.QBAccount = 'cash'
Config.EntryFee = 0
Config.Prizes = { bestItem = 0, bigSpender = 0 }

Config.Language = 'ru'               -- default interface language: 'ru' or 'en' (the lobby host can switch it when creating the game)
Config.SpawnAtLobby = true           -- players spawn next to the game start when they join the server (turn off if you use a multicharacter / spawn selector)
Config.DebugCommands = true          -- /storagetest, /storagecheck, /storagecoords (admins only for /storagetest)

-- Needs OneSync. The server checks that players really are near the auction / buyers.
Config.ServerDistanceChecks = true

-- ============ Match ============
Config.MinPlayers = 2
Config.MaxPlayers = 8
Config.StartMoney = 10000
Config.ArrivalRadius = 60.0
Config.InteractRadius = 2.5
Config.LiquidationRate = 0.5         -- unsold items at the very end are auto-sold at this rate (not counted for "best item")
Config.ResultsSeconds = 30
Config.BigSaleAnnounce = 2000
Config.MaxContainers = 6             -- the lobby host can pick 0/1..MaxContainers lots per round

Config.LocalBuyerMult = 1.0          -- buyer standing at the auction
Config.FarBuyerMult = 1.3            -- the collector (a bit further away) pays more

-- The collector stands this far from the lot door (local offset: x right, y forward). Closer = shorter trip.
-- You can also set `collector = vec4(...)` on any location to place him exactly.
Config.CollectorOffset = vec2(60.0, -95.0)

-- ============ Auction timing ============
Config.Auction = {
    previewSeconds = 45,
    firstBidSeconds = 20,
    resetSeconds = 8,
    bidRadius = 45.0,
    lootSeconds = 90,
    betweenSeconds = 6,
    finalSellSeconds = 120,          -- selling time after the last lot of a round...
    finalMinSeconds = 5,             -- ...it ends earlier when everybody sold everything or pressed G (skip)
}

-- ============ Travel vehicles ============
-- Every player gets ONE random car from this list at the start of every drive.
Config.SpawnTravelVehicle = true
Config.TravelVehicles = { 'zentorno', 'osiris', 'turismor', 't20', 'entityxf', 'cheetah', 'vacca', 'banshee2', 'infernus', 'adder' }
-- Extra speed: full engine/brakes/transmission/turbo upgrades + engine power boost (0 = no boost, 10-25 = very fast)
Config.TravelVehicleTuning = true
Config.TravelVehicleBoost = 15.0
-- Called on the client after the car spawns. Put your keys / fuel export here, e.g.:
-- Config.OnTravelVehicle = function(veh, plate) TriggerEvent('vehiclekeys:client:SetOwner', plate) end
Config.OnTravelVehicle = nil

-- ============ Lobby ============
Config.Lobby = {
    coords = vec4(195.2, -934.0, 30.7, 144.0),
    spawn = vec4(197.8, -931.4, 30.7, 144.0),     -- where players appear when joining the server
    ped = 's_m_m_dockwork_01',
}

-- ============ Map icons ============ (the lot icon differs from the lobby icon)
Config.Blips = {
    lobby     = { sprite = 478, colour = 5 },
    lot       = { sprite = 477, colour = 1 },
    bonus     = { sprite = 50,  colour = 3 },
    collector = { sprite = 500, colour = 2 },
}

-- ============ NPCs ============
Config.AuctioneerPed = 'a_m_m_business_01'
Config.BuyerPed = 's_m_y_dealer_01'
Config.FarBuyerPed = 'a_m_y_hipster_01'

-- Local offsets from the lot door: x = right, y = forward (into the lot)
Config.Layout = {
    auctioneer = vec2(3.8, -5.0),
    buyer = vec2(-6.5, -5.5),
}

-- ============ Lot shapes ============
-- CONTAINER lots use ONE real container prop from the game: EMPTY and OPEN, you can walk into it.
-- The open end faces the crowd, an invisible wall stops anyone from walking in.
-- Not sure which model is an open container? Stand next to one on the map and type /storagemodel:
-- it prints the model number and a ready-to-paste line for this list.
--   model    = model name OR a number (hash)
--   width / depth = free space INSIDE in metres, cell = size of one item slot
--   openBack = true if the container is open at BOTH ends (a closed container is placed behind it as the back wall)
--   flip     = true if the open end of the model looks the wrong way (turns it 180 degrees)
-- If the real container is smaller than width/depth, the items are squeezed to fit automatically.
-- Several entries = variety (different models / colours / sizes). Invalid names are skipped.
Config.ContainerModels = {
    -- known = true: a model you KNOW is open on one side. Used as the fallback when another model turns out to be closed.
    -- Models that do not exist in your game build are skipped automatically (the server only picks valid ones).
    -- The open side is detected automatically (it is turned towards the crowd).
    { en = 'Red container',      ru = 'Красный контейнер',   model = 531344027,               width = 2.2, depth = 11.0, cell = 1.15, openBack = false, weight = 60, known = true },
    { en = 'Cargo container',    ru = 'Грузовой контейнер',  model = 'prop_ctor_container_01', width = 2.2, depth = 11.0, cell = 1.15, openBack = false, weight = 15 },
    { en = 'Shipping container', ru = 'Контейнер',           model = 'prop_container_01_ld',   width = 2.2, depth = 11.0, cell = 1.15, openBack = false, weight = 15 },
    { en = 'Open container',     ru = 'Открытый контейнер',  model = 'prop_container_open_x',  width = 2.2, depth = 11.0, cell = 1.15, openBack = false, weight = 10 },
}
-- Closed containers used as the BACK WALL of open-ended containers
Config.ContainerBackModels = { 'prop_container_ld2', 'prop_container_01a', 'prop_container_05a' }

-- Invisible entrance barrier (these props are tiled across the opening and hidden)
Config.BarrierModels = { 'prop_barrier_work06a', 'prop_barrier_work05', 'prop_mp_barrier_02b' }
Config.BarrierLayers = 2

-- GARAGE lots (BONUS round) use EXISTING garages on your map: the script only puts the items inside
-- and blocks the entrance. Size can be overridden per garage location (width/depth).
Config.Garage = { en = 'Garage', ru = 'Гараж', width = 5.6, depth = 6.4, cell = 1.25 }
-- Optional: open / close the real garage door. Called on the client with the location table. Example:
-- Config.GarageDoor = { open = function(loc) exports.ox_doorlock:... end, close = function(loc) end }
Config.GarageDoor = nil

-- ============ Rounds ============
-- Each round picks ONE random location. Players must DRIVE there (travelSeconds; starts early when everyone arrived).
-- containers = default number of lots (the lobby host can change it; 0 on the bonus round = skipped).
-- steps = what keys 1-4 add to the bid. hiddenMin/Max = valuables hidden behind big things.
-- tarpChance = chance that a normal item is hidden under a tarp. carChance = chance of a super lucky hidden car.
-- Locations need a big FLAT OPEN area (never a roof!). Use /storagecheck to test a spot. Coords are APPROXIMATE.
-- heading = the direction the lot opens INTO (the crowd stands behind it).
Config.Rounds = {
    {
        nameEn = 'Round 1', nameRu = 'Раунд 1',
        containers = 3, travelSeconds = 360,
        steps = { 50, 100, 250, 500 },
        startMin = 300, startMax = 700,
        itemsMin = 5, itemsMax = 8,
        hiddenMin = 0, hiddenMax = 1,
        tarpChance = 0.10, carChance = 0.03,
        valueScale = 1.0,
        kinds = { container = 100 },
        locations = {
            { name = 'Sandy Shores Airfield', ru = 'Аэродром Сэнди-Шорс', coords = vec3(1747.0, 3273.7, 41.1), heading = 30.0 },
            { name = 'McKenzie Airfield',     ru = 'Аэродром МакКензи',   coords = vec3(2122.0, 4805.0, 41.2), heading = 90.0 },
        }
    },
    {
        nameEn = 'Round 2', nameRu = 'Раунд 2',
        containers = 3, travelSeconds = 360,
        steps = { 100, 250, 500, 1000 },
        startMin = 600, startMax = 1400,
        itemsMin = 7, itemsMax = 11,
        hiddenMin = 1, hiddenMax = 2,
        tarpChance = 0.18, carChance = 0.06,
        valueScale = 1.5,
        kinds = { container = 100 },
        locations = {
            { name = 'Maze Bank Arena Lot', ru = 'Парковка Maze Bank Arena', coords = vec3(-250.0, -2025.0, 30.1), heading = 50.0 },
            { name = 'Cypress Flats Yard',  ru = 'Склады Сайпресс-Флэтс',    coords = vec3(1009.0, -2500.0, 28.4), heading = 80.0 },
        }
    },
    {
        nameEn = 'Round 3', nameRu = 'Раунд 3',
        containers = 3, travelSeconds = 360,
        steps = { 250, 500, 1000, 2500 },
        startMin = 1200, startMax = 3000,
        itemsMin = 9, itemsMax = 14,
        hiddenMin = 2, hiddenMax = 3,
        tarpChance = 0.25, carChance = 0.10,
        valueScale = 2.2,
        kinds = { container = 100 },
        locations = {
            { name = 'Paleto Sawmill Yard', ru = 'Лесопилка Палето',       coords = vec3(-550.0, 5325.0, 70.4), heading = 160.0 },
            { name = 'Grapeseed Farmland',  ru = 'Фермерские поля Грейпсид', coords = vec3(2440.0, 4975.0, 46.0), heading = 45.0 },
        }
    },
    {
        -- BONUS ROUND in existing map garages. Disabled until a garage is added.
        -- EASIEST: stand in the garage doorway looking INTO the garage and type /storagegarage <name>
        -- (saved automatically, see /storagegaragelist and /storagegaragedel). You can also list garages below.
        bonus = true, optional = true,
        nameEn = 'Bonus: garages', nameRu = 'Бонус: гаражи',
        containers = 2, travelSeconds = 360,
        steps = { 250, 500, 1000, 2500 },
        startMin = 1500, startMax = 3500,
        itemsMin = 8, itemsMax = 12,
        hiddenMin = 2, hiddenMax = 3,
        tarpChance = 0.25, carChance = 0.15,
        valueScale = 2.4,
        kinds = { garage = 100 },
        locations = {
            -- { name = 'My Garage', ru = 'Мой гараж', coords = vec3(0.0, 0.0, 0.0), heading = 0.0, width = 5.6, depth = 6.4 },
        }
    },
}

-- ============ Lot quality tiers (hidden from players) ============
-- luck: chance of rare items. hiddenMul: scales hidden valuables. carMul: scales the hidden car chance.
Config.Tiers = {
    { name = 'junk',    chance = 35, luck = 0.2, hiddenMul = 0.5, carMul = 0.0 },
    { name = 'average', chance = 40, luck = 1.0, hiddenMul = 1.0, carMul = 0.7 },
    { name = 'good',    chance = 20, luck = 2.5, hiddenMul = 1.5, carMul = 1.6 },
    { name = 'jackpot', chance = 5,  luck = 6.0, hiddenMul = 2.0, carMul = 3.0 },
}

-- ============ Lot themes (variety): multiply the chance of items with these tags ============
Config.Themes = {
    { en = 'Mixed lot',      ru = 'Смешанный лот',        weight = 40, mult = {} },
    { en = 'Electronics',    ru = 'Электроника',          weight = 20, mult = { electronics = 4.0 } },
    { en = 'Music & hobby',  ru = 'Музыка и хобби',       weight = 15, mult = { music = 4.0, sports = 3.0 } },
    { en = 'Junk',           ru = 'Хлам',                 weight = 15, mult = { junk = 4.0 } },
    { en = 'Estate sale',    ru = 'Имущество с аукциона', weight = 10, mult = { valuables = 3.0 } },
}

-- ============ Loot (real props placed inside the lots) ============
-- Invalid model names fall back to a cardboard box. value is multiplied by the round's valueScale.
-- rare = true items are also used for HIDDEN spots.
Config.Loot = {
    { label = 'Cardboard Box',   ru = 'Картонная коробка', model = 'prop_cs_cardbox_01',  min = 20,  max = 70,  weight = 30, tags = { 'junk' } },
    { label = 'Old TV',          ru = 'Старый телевизор',  model = 'prop_tv_03',          min = 30,  max = 120, weight = 25, tags = { 'electronics' } },
    { label = 'Toolbox',         ru = 'Ящик с инструментом', model = 'prop_toolchest_01', min = 60,  max = 200, weight = 22, tags = { 'junk' } },
    { label = 'Boombox',         ru = 'Магнитофон',        model = 'prop_boombox_01',     min = 80,  max = 260, weight = 18, tags = { 'electronics', 'music' } },
    { label = 'Suitcase',        ru = 'Чемодан',           model = 'prop_ld_suitcase_01', min = 100, max = 350, weight = 18, tags = { 'junk' } },
    { label = 'Acoustic Guitar', ru = 'Гитара',            model = 'prop_acc_guitar_01',  min = 150, max = 500, weight = 12, tags = { 'music' } },
    { label = 'Golf Bag',        ru = 'Сумка для гольфа',  model = 'prop_golf_bag_01',    min = 120, max = 420, weight = 12, tags = { 'sports' } },
    { label = 'Laptop',          ru = 'Ноутбук',           model = 'prop_laptop_01a',     min = 200, max = 600, weight = 10, tags = { 'electronics' } },
    { label = 'Flat Screen TV',  ru = 'Плазменный телевизор', model = 'prop_tv_flat_01',  min = 250, max = 700, weight = 9,  tags = { 'electronics' } },
    { label = 'Big Speaker',     ru = 'Большая колонка',   model = 'prop_speaker_05',     min = 200, max = 600, weight = 9,  tags = { 'electronics', 'music' } },
    { label = 'Briefcase of Cash', ru = 'Кейс с деньгами', model = 'prop_ld_case_01',     min = 800, max = 2200, weight = 5, rare = true, tags = { 'valuables' } },
    { label = 'Money Bag',       ru = 'Мешок денег',       model = 'prop_money_bag_01',   min = 600, max = 1800, weight = 4, rare = true, tags = { 'valuables' } },
    { label = 'Signed Electric Guitar', ru = 'Электрогитара с автографом', model = 'prop_el_guitar_01', min = 700, max = 2000, weight = 4, rare = true, tags = { 'valuables', 'music' } },
    { label = 'Old Safe',        ru = 'Старый сейф',       model = 'prop_ld_int_safe_01', min = 1500, max = 4500, weight = 2, rare = true, tags = { 'valuables' } },
    { label = 'Gold Case',       ru = 'Кейс с золотом',    model = 'prop_gold_cont_01',   min = 2500, max = 6000, weight = 1, rare = true, tags = { 'valuables' } },
}

-- Big, cheap things that hide valuables standing behind them
Config.Covers = {
    { label = 'Wooden Crate',     ru = 'Деревянный ящик',  model = 'prop_box_wood05a', min = 10, max = 50 },
    { label = 'Big Wooden Crate', ru = 'Большой ящик',     model = 'prop_box_wood01a', min = 10, max = 60 },
    { label = 'Barrel',           ru = 'Бочка',            model = 'prop_barrel_02a',  min = 10, max = 40 },
    { label = 'Cabinet',          ru = 'Шкаф',             model = 'prop_cabinet_01b', min = 20, max = 80 },
    { label = 'Old Fridge',       ru = 'Старый холодильник', model = 'prop_fridge_03', min = 20, max = 80 },
}

-- A row of these can hide a WHOLE CAR (super lucky). The car is revealed when all of them are taken.
Config.Cabinets = {
    { label = 'Wardrobe', ru = 'Платяной шкаф', model = 'prop_cabinet_01b', min = 20, max = 80 },
    { label = 'Cabinet',  ru = 'Большой шкаф',  model = 'prop_cabinet_02b', min = 20, max = 80 },
}

-- Tarps: randomly cover SOME items. Click the tarp to see what is under it.
Config.Tarps = {
    { label = 'Tarp', ru = 'Брезент', model = 'prop_big_bag_01', min = 1, max = 10 },
}

-- Hidden car prizes (real frozen cars). w / l = real width and length in metres: a car only appears in a lot
-- where it PHYSICALLY FITS (inner width >= w + 0.2 and depth >= l + 3). Value is NOT scaled by round.
Config.Vehicles = {
    { label = 'Classic Coupe',    ru = 'Классическое купе', model = 'stingergt', w = 2.0, l = 4.4, min = 6000, max = 11000, weight = 3, noScale = true, isVehicle = true },
    { label = 'Vintage Roadster', ru = 'Винтажный родстер', model = 'btype',     w = 1.9, l = 4.5, min = 7000, max = 12000, weight = 2, noScale = true, isVehicle = true },
    { label = 'Sports Classic',   ru = 'Спорт-классика',    model = 'coquette2', w = 1.9, l = 4.4, min = 6500, max = 11500, weight = 2, noScale = true, isVehicle = true },
    { label = 'Old Roadster',     ru = 'Старый родстер',    model = 'jb700',     w = 1.8, l = 4.2, min = 8000, max = 13000, weight = 1, noScale = true, isVehicle = true },
}
