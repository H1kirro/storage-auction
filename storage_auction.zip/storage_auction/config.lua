Config = {}

-- ============ Загальне ============
Config.Locale = 'ru'                 -- мова інтерфейсу (locale.lua)

-- Справжні гроші сервера — ОПЦІЙНО (внесок + призи). Гроші матчу завжди віртуальні.
-- 'none' | 'esx' | 'qb'
Config.Framework = 'none'
Config.QBAccount = 'cash'
Config.EntryFee = 0
Config.Prizes = { bestItem = 0, bigSpender = 0 }

-- Потрібен OneSync. Сервер перевіряє, що гравці справді біля аукціону / покупця.
Config.ServerDistanceChecks = true

-- ============ Матч ============
Config.MinPlayers = 2
Config.MaxPlayers = 8
Config.StartMoney = 10000
Config.ArrivalRadius = 60.0          -- як близько треба під'їхати до точки
Config.InteractRadius = 2.5
Config.LiquidationRate = 0.5         -- нерозпродане наприкінці автопродається за цим коефіцієнтом
Config.ResultsSeconds = 30
Config.BigSaleAnnounce = 2000
Config.MaxContainers = 6             -- хост може обрати 1..MaxContainers лотів на раунд

Config.LocalBuyerMult = 1.0          -- скупник біля аукціону
Config.FarBuyerMult = 1.3            -- колекціонер (тепер теж поруч, але платить більше)

-- Клавіша «пропустити етап» (перегляд лоту / фінальний продаж). Гравець може змінити її в налаштуваннях FiveM.
Config.SkipKey = 'G'

-- ============ Таймінги аукціону ============
Config.Auction = {
    previewSeconds = 40,             -- підійти й подивитись усередину до торгів
    firstBidSeconds = 20,            -- час на першу ставку
    resetSeconds = 8,                -- таймер повертається до цього значення після кожної ставки
    bidRadius = 45.0,                -- наскільки близько треба бути, щоб ставити
    lootSeconds = 90,                -- час переможцю, щоб розібрати лот
    betweenSeconds = 5,
    finalSellSeconds = 90,           -- після останнього лоту раунду: час на продаж
    autoSkipDelay = 3,               -- скільки секунд мінімум триває фінальний етап, перш ніж він пропуститься автоматично
}

-- ============ Транспорт для поїздки ============
-- Кожен гравець на початку кожної поїздки отримує ОДНУ випадкову машину з цього списку.
-- Тепер це швидкі авто + підвищена потужність двигуна.
Config.SpawnTravelVehicle = true
Config.TravelVehicles = {
    'sultan', 'kuruma', 'buffalo', 'elegy2', 'comet2', 'jester', 'schafter3',
    'dominator', 'gauntlet', 'penumbra', 'sentinel', 'banshee',
}
Config.CarPower = 35.0               -- SetVehicleEnginePowerMultiplier (0 = вимкнути). 20-50 відчутно швидше.
Config.CarTorque = 1.6               -- SetVehicleEngineTorqueMultiplier (1.0 = стандарт)
-- Викликається на клієнті після спавну (ключі / паливо), напр.:
-- Config.OnTravelVehicle = function(veh, plate) TriggerEvent('vehiclekeys:client:SetOwner', plate) end
Config.OnTravelVehicle = nil

-- ============ Спавн при вході на сервер ============
-- Гравець, який щойно зайшов на сервер, з'являється біля лобі гри.
-- (Якщо у вас є свій екран вибору спавну — вимкніть його або поставте enabled = false.)
Config.JoinSpawn = {
    enabled = true,
    coords = nil,                    -- nil = біля Config.Lobby.coords
    radius = 3.5,                    -- розкид, щоб гравці не з'являлись один в одному
}

-- ============ Лобі ============
Config.Lobby = {
    coords = vec4(195.2, -934.0, 30.7, 144.0),
    ped = 's_m_m_dockwork_01',
}

-- ============ Іконки на мапі ============
-- Іконка контейнерів ВІДРІЗНЯЄТЬСЯ від іконки самої гри (lobby).
Config.Blips = {
    lobby  = { sprite = 478, colour = 5,  scale = 0.8 },   -- сама гра (жовта)
    lot    = { sprite = 477, colour = 17, scale = 1.0 },   -- точка з контейнерами (помаранчева «вантажівка»)
    garage = { sprite = 357, colour = 3,  scale = 1.0 },   -- бонус-гаражі (синя)
    far    = { sprite = 500, colour = 2,  scale = 0.8 },   -- колекціонер
}

-- ============ NPC ============
Config.AuctioneerPed = 'a_m_m_business_01'
Config.BuyerPed = 's_m_y_dealer_01'
Config.FarBuyerPed = 'a_m_y_hipster_01'
Config.FarBuyerNames = { 'Коллекционер из Вайнвуда', 'Коллекционер с побережья', 'Антиквар', 'Богатый чудак', 'Старьёвщик-эксперт' }

-- Локальні зсуви від дверей лоту: x = вправо, y = вперед (усередину лоту)
-- Усі місця продажу тепер ПОРУЧ одне з одним і з аукціоном.
Config.Layout = {
    auctioneer = vec2(4.2, -4.0),
    buyer = vec2(-6.0, -4.5),
    far = vec2(-14.0, -12.0),        -- колекціонер за ~18 м від дверей (можна задати loc.far у локації)
}

-- ============ Типи лотів ============
-- Оболонка (підлога, стіни, дах, світло) малюється скриптом, предмети всередині — справжні пропи.
-- Навколо лоту ставляться НЕВИДИМІ стінки: заходити всередину не можна.
-- width = x, depth = углиб, height = z, cell = розмір клітинки сітки для предметів.
-- doors = відкриті стулки, ribs = гофра, band = смуги/логотип, posts = рама спереду.
Config.LotTypes = {
    container20 = {
        label = 'Контейнер 20 футов',
        width = 2.4, depth = 5.9, height = 2.6, cell = 1.15,
        doors = true, ribs = true, band = true, posts = true, lights = 2, lightRange = 8.0,
        colors = { {170, 60, 40}, {40, 80, 150}, {40, 110, 70}, {175, 140, 50}, {190, 100, 40} },
        interior = {105, 105, 110},
    },
    container40 = {
        label = 'Контейнер 40 футов',
        width = 2.4, depth = 11.8, height = 2.6, cell = 1.15,
        doors = true, ribs = true, band = true, posts = true, lights = 3, lightRange = 9.0,
        colors = { {170, 60, 40}, {40, 80, 150}, {40, 110, 70}, {175, 140, 50}, {80, 85, 95} },
        interior = {105, 105, 110},
    },
    container40hc = {
        label = 'Высокий контейнер (HC)',
        width = 2.4, depth = 11.8, height = 2.9, cell = 1.15,
        doors = true, ribs = true, band = true, posts = true, lights = 3, lightRange = 9.0,
        colors = { {30, 90, 110}, {120, 40, 90}, {190, 190, 195}, {35, 35, 40} },
        interior = {110, 110, 115},
    },
    reefer = {
        label = 'Рефрижераторный контейнер',
        width = 2.5, depth = 11.5, height = 2.7, cell = 1.15,
        doors = true, ribs = false, band = true, posts = true, lights = 3, lightRange = 9.0,
        colors = { {225, 228, 232}, {190, 205, 215}, {210, 220, 225} },
        interior = {190, 195, 200},
    },
    rusty = {
        label = 'Старый ржавый контейнер',
        width = 2.4, depth = 5.9, height = 2.6, cell = 1.15,
        doors = true, ribs = true, band = false, posts = true, lights = 2, lightRange = 7.0,
        colors = { {120, 70, 45}, {105, 85, 60}, {90, 60, 50}, {110, 95, 70} },
        interior = {80, 75, 70},
    },
    trailer = {
        label = 'Фургон-прицеп',
        width = 2.5, depth = 8.0, height = 2.8, cell = 1.15,
        doors = true, ribs = false, band = true, posts = false, lights = 2, lightRange = 8.0,
        colors = { {215, 215, 220}, {60, 90, 130}, {150, 40, 40} },
        interior = {150, 150, 155},
    },
    storage_unit = {
        label = 'Бокс для хранения',
        width = 3.0, depth = 5.0, height = 2.6, cell = 1.1,
        doors = false, ribs = true, band = true, posts = true, lights = 2, lightRange = 8.0,
        colors = { {230, 140, 40}, {70, 130, 190}, {200, 200, 205} },
        interior = {135, 135, 140},
    },
    shed = {
        label = 'Деревянный сарай',
        width = 3.4, depth = 5.0, height = 2.5, cell = 1.1,
        doors = false, ribs = false, band = false, posts = false, lights = 1, lightRange = 7.0,
        colors = { {120, 85, 55}, {95, 70, 50}, {135, 105, 75} },
        interior = {110, 90, 70},
    },
    garage_single = {
        label = 'Гараж на одну машину',
        width = 3.4, depth = 6.2, height = 2.7, cell = 1.1,
        doors = false, ribs = false, band = false, posts = true, lights = 2, lightRange = 9.0,
        colors = { {150, 150, 155}, {125, 110, 100}, {110, 90, 85} },
        interior = {125, 125, 130},
    },
    garage = {
        label = 'Гараж',
        width = 5.6, depth = 6.4, height = 2.8, cell = 1.25,
        doors = false, ribs = false, band = false, posts = true, lights = 2, lightRange = 10.0,
        colors = { {150, 150, 155}, {125, 110, 100}, {110, 90, 85} },
        interior = {125, 125, 130},
    },
    garage_big = {
        label = 'Большой гараж',
        width = 7.0, depth = 8.0, height = 3.0, cell = 1.3,
        doors = false, ribs = false, band = false, posts = true, lights = 3, lightRange = 11.0,
        colors = { {140, 140, 148}, {115, 105, 100}, {100, 95, 105} },
        interior = {120, 120, 128},
    },
}

-- ============ Раунди ============
-- Кожен раунд обирає ОДНУ випадкову локацію. Гравці їдуть туди (travelSeconds; раунд стартує раніше, якщо приїхали всі).
-- containers = типова кількість лотів (хост може змінити в лобі).
-- steps = що додають клавіші 1-4. startMin/startMax = стартова ставка.
-- hiddenMin/hiddenMax = цінні речі, сховані за шафами/ящиками. valueScale = множник вартості.
-- kinds = вага типу лоту (ключі з Config.LotTypes).
-- carMul = множник шансу «машини за шафами» (див. Config.Tiers.carChance).
--
-- ЛОКАЦІЇ: тільки ВІДКРИТІ рівні майданчики (аеродроми, пустирі, поля) — НЕ дахи й не вузькі двори!
-- Лот займає ширину ~2.5-7 м і глибину до 12 м, а попереду стоїть натовп.
-- coords = де стоять ДВЕРІ лоту (z — висота землі), heading = напрям, КУДИ відкривається лот.
-- Команди для налаштування (потрібне ACE storage.admin): /storagepos  /storagedebug  /storagetp
-- Необов'язкові поля локації: far = vec4 (точка колекціонера), kind = примусовий тип лоту,
--   width/depth = свої розміри, existing = true (гараж уже є на мапі: оболонка не малюється,
--   лише невидимі стінки перед дверима і предмети всередині).
Config.Rounds = {
    {
        containers = 3, travelSeconds = 240,
        steps = { 50, 100, 250, 500 },
        startMin = 300, startMax = 700,
        itemsMin = 5, itemsMax = 8,
        hiddenMin = 0, hiddenMax = 1,
        valueScale = 1.0, carMul = 0.5,
        kinds = { container20 = 30, container40 = 25, rusty = 20, storage_unit = 15, shed = 10 },
        locations = {
            { name = 'Аэродром Сэнди-Шорс', coords = vec3(1747.0, 3273.7, 41.1), heading = 30.0 },
            { name = 'Аэродром Мак-Кензи',  coords = vec3(2122.0, 4805.0, 41.2), heading = 90.0 },
        }
    },
    {
        containers = 3, travelSeconds = 240,
        steps = { 100, 250, 500, 1000 },
        startMin = 600, startMax = 1400,
        itemsMin = 7, itemsMax = 11,
        hiddenMin = 1, hiddenMax = 2,
        valueScale = 1.5, carMul = 1.0,
        kinds = { container20 = 15, container40 = 25, container40hc = 20, reefer = 15, trailer = 15, storage_unit = 10 },
        locations = {
            { name = 'Парковка Мейз Банк Арены', coords = vec3(-250.0, -2025.0, 30.1), heading = 50.0 },
            { name = 'Двор Сайпресс-Флэтс',      coords = vec3(1009.0, -2500.0, 28.4), heading = 80.0 },
        }
    },
    {
        containers = 3, travelSeconds = 240,
        steps = { 250, 500, 1000, 2500 },
        startMin = 1200, startMax = 3000,
        itemsMin = 9, itemsMax = 14,
        hiddenMin = 2, hiddenMax = 3,
        valueScale = 2.2, carMul = 1.6,
        kinds = { container40 = 20, container40hc = 25, reefer = 20, trailer = 15, rusty = 10, shed = 10 },
        locations = {
            { name = 'Лесопилка Палето',  coords = vec3(-550.0, 5325.0, 70.4), heading = 160.0 },
            { name = 'Поля Грейпсида',    coords = vec3(2440.0, 4975.0, 46.0), heading = 45.0 },
        }
    },
    -- БОНУС-РАУНД: гаражі. Лоти тільки гаражного типу, вмісту більше, машини трапляються частіше.
    -- Якщо на вашій мапі є гаражі, що відкриваються (MLO / двері), додайте їх ТАК:
    --   { name = 'Гараж Дэвис', coords = vec3(X, Y, Z), heading = H, existing = true, kind = 'garage', width = 5.0, depth = 6.0 },
    -- coords/heading — командою /storagepos, стоячи В ДВЕРЯХ гаража і дивлячись ВСЕРЕДИНУ.
    {
        bonus = true, name = 'Бонус: гаражи',
        containers = 2, travelSeconds = 240,
        steps = { 250, 500, 1000, 2500 },
        startMin = 2000, startMax = 4500,
        itemsMin = 8, itemsMax = 13,
        hiddenMin = 2, hiddenMax = 3,
        valueScale = 2.8, carMul = 2.5,
        kinds = { garage_single = 35, garage = 40, garage_big = 25 },
        locations = {
            { name = 'Гаражи: Сэнди-Шорс', coords = vec3(1747.0, 3273.7, 41.1), heading = 210.0 },
            { name = 'Гаражи: Мак-Кензи',  coords = vec3(2122.0, 4805.0, 41.2), heading = 270.0 },
        }
    },
}

-- ============ Якість лоту (приховано від гравців) ============
-- luck: множник шансу рідкісних речей. hiddenMul: множник числа схованих цінностей.
-- carChance: шанс, що за шафами стоїть МАШИНА («суперпощастило»). tarpMul: множник числа накидок.
Config.Tiers = {
    { name = 'junk',    chance = 35, luck = 0.2, hiddenMul = 0.5, carChance = 0.00, tarpMul = 0.8 },
    { name = 'average', chance = 40, luck = 1.0, hiddenMul = 1.0, carChance = 0.04, tarpMul = 1.0 },
    { name = 'good',    chance = 20, luck = 2.5, hiddenMul = 1.5, carChance = 0.12, tarpMul = 1.2 },
    { name = 'jackpot', chance = 5,  luck = 6.0, hiddenMul = 2.0, carChance = 0.35, tarpMul = 1.5 },
}

-- ============ Лут (справжні пропи всередині лотів) ============
-- Якщо модель не існує на вашій збірці — підставляється картонна коробка (див. Config.ModelAlt).
-- Вартість множиться на valueScale раунду. rare = true — можуть бути СХОВАНІ за шафами/ящиками.
Config.Loot = {
    { label = 'Картонная коробка',     model = 'prop_cs_cardbox_01',    min = 20,   max = 70,   weight = 30 },
    { label = 'Старый телевизор',      model = 'prop_tv_03',            min = 30,   max = 120,  weight = 25 },
    { label = 'Ящик с инструментами',  model = 'prop_toolchest_01',     min = 60,   max = 200,  weight = 22 },
    { label = 'Магнитола',             model = 'prop_boombox_01',       min = 80,   max = 260,  weight = 18 },
    { label = 'Чемодан',               model = 'prop_ld_suitcase_01',   min = 100,  max = 350,  weight = 18 },
    { label = 'Акустическая гитара',   model = 'prop_acc_guitar_01',    min = 150,  max = 500,  weight = 12 },
    { label = 'Сумка для гольфа',      model = 'prop_golf_bag_01',      min = 120,  max = 420,  weight = 12 },
    { label = 'Ноутбук',               model = 'prop_laptop_01a',       min = 200,  max = 600,  weight = 10 },
    { label = 'Плоский телевизор',     model = 'prop_tv_flat_01',       min = 250,  max = 700,  weight = 9 },
    { label = 'Большая колонка',       model = 'prop_speaker_05',       min = 200,  max = 600,  weight = 9 },
    { label = 'Кейс с наличкой',       model = 'prop_ld_case_01',       min = 800,  max = 2200, weight = 5, rare = true },
    { label = 'Мешок с деньгами',      model = 'prop_money_bag_01',     min = 600,  max = 1800, weight = 4, rare = true },
    { label = 'Электрогитара с автографом', model = 'prop_el_guitar_01', min = 700, max = 2000, weight = 4, rare = true },
    { label = 'Старый сейф',           model = 'prop_ld_int_safe_01',   min = 1500, max = 4500, weight = 2, rare = true },
    { label = 'Золотой кейс',          model = 'prop_gold_cont_01',     min = 2500, max = 6000, weight = 1, rare = true },
}

-- Великі дешеві речі: за ними (на 1 клітинку глибше) ховається рідкісна цінність.
-- weight = як часто трапляється. Шафи теж можуть бути такими «прикриттями».
Config.Covers = {
    { label = 'Деревянный ящик',         model = 'prop_box_wood05a', min = 10, max = 50, weight = 25 },
    { label = 'Большой деревянный ящик', model = 'prop_box_wood01a', min = 10, max = 60, weight = 25 },
    { label = 'Бочка',                   model = 'prop_barrel_02a',  min = 10, max = 40, weight = 20 },
    { label = 'Куча коробок',            model = 'prop_boxpile_07d', min = 10, max = 60, weight = 15 },
    { label = 'Старый шкаф',             model = 'prop_cabinet_01',  min = 20, max = 90, weight = 25 },
}

-- ============ ШАФИ, що закривають МАШИНУ («суперпощастило») ============
-- Ряд шаф стоїть упритул перед дверима, а за ними — машина з Config.Cars.
-- w = ширина одного шафа (м) — за нею рахується, скільки шаф ставити впоперек.
-- heading = додатковий поворот моделі (якщо шафа «дивиться» не в той бік — змініть на 90/180/270).
Config.Wardrobes = {
    { label = 'Шкаф',        model = 'prop_cabinet_01',  w = 1.0, heading = 180.0, min = 20, max = 90 },
    { label = 'Старый шкаф', model = 'prop_cabinet_02b', w = 1.0, heading = 180.0, min = 20, max = 90 },
}

-- Машини, які можуть стояти за шафами. Невеликі авто, щоб влізли навіть у 20-футовий контейнер.
-- length/width — приблизні розміри (м). value множиться на valueScale раунду.
Config.Cars = {
    { label = 'Старенький Panto',       model = 'panto',   length = 3.0, width = 1.7, min = 3000,  max = 6000,  weight = 30 },
    { label = 'Классический Issi',      model = 'issi2',   length = 3.8, width = 1.8, min = 4000,  max = 8000,  weight = 25 },
    { label = 'Раритетный Blista',      model = 'blista',  length = 4.0, width = 1.8, min = 5000,  max = 9000,  weight = 25 },
    { label = 'Редкий Peyote',          model = 'peyote',  length = 4.0, width = 1.8, min = 7000,  max = 15000, weight = 15 },
    { label = 'Коллекционный Stinger',  model = 'stinger', length = 4.4, width = 1.9, min = 18000, max = 36000, weight = 5 },
}

-- ============ НАКИДКИ («ковдри» на речах) ============
-- Випадкові речі в лоті накриті накидкою: видно лише накидку, що під нею — невідомо.
-- Накидка накриває НЕ ВСЕ: кожна річ має шанс бути накритою, але не більше max накидок на лот.
Config.Tarp = {
    label = 'Накидка',
    chance = 0.22,                   -- шанс, що звичайна річ під накидкою (множиться на tarpMul якості)
    doubleChance = 0.30,             -- шанс, що накидка накриває ще й сусідню річ
    maxPerLot = 4,
    minValue = 5, maxValue = 25,     -- вартість самої накидки, якщо її продати
    colors = { {58, 92, 140}, {70, 110, 70}, {120, 120, 125}, {155, 112, 60}, {110, 60, 60} },
}

-- ============ Запасні моделі ============
-- Якщо model не знайдена, пробуються ці за порядком, потім картонна коробка.
Config.ModelAlt = {
    prop_cabinet_01  = { 'prop_cabinet_01b', 'prop_cabinet_02b', 'prop_boxpile_07d' },
    prop_cabinet_02b = { 'prop_cabinet_01', 'prop_cabinet_01b', 'prop_boxpile_07d' },
}

-- Невидимі стінки (колізія), якими обносяться лоти. Береться перша існуюча модель.
-- Розмір моделі вимірюється автоматично, стіни складаються з неї.
Config.BlockerModels = { 'prop_mp_barrier_02b', 'prop_barrier_work06a', 'prop_barrier_work05', 'prop_cs_cardbox_01' }

-- Права на адмін-команди: add_ace group.admin storage.admin allow
Config.AdminAce = 'storage.admin'
