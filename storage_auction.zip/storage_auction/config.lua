Config = {}

-- ============ General ============
-- Real server money is OPTIONAL (entry fee + prizes). Match money is always virtual.
-- 'none' | 'esx' | 'qb'
Config.Framework = 'none'
Config.QBAccount = 'cash'
Config.EntryFee = 0
Config.Prizes = { bestItem = 0, bigSpender = 0 }

-- Needs OneSync. The server checks that players really are near the auction / buyers.
Config.ServerDistanceChecks = true

-- ============ Match ============
Config.MinPlayers = 2
Config.MaxPlayers = 8
Config.StartMoney = 10000
Config.ArrivalRadius = 60.0          -- how close you must get to the new location
Config.InteractRadius = 2.5
Config.LiquidationRate = 0.5         -- unsold items at the very end are auto-sold at this rate (not counted for "best item")
Config.ResultsSeconds = 30
Config.BigSaleAnnounce = 2000
Config.MaxContainers = 6             -- the lobby host can pick 1..MaxContainers lots per round

Config.LocalBuyerMult = 1.0          -- buyer standing at the auction
Config.FarBuyerMult = 1.3            -- the collector far away pays more

-- ============ Auction timing ============
Config.Auction = {
    previewSeconds = 45,             -- walk up and look inside before bidding opens
    firstBidSeconds = 20,            -- time for the first bid
    resetSeconds = 8,                -- timer jumps back to this after every new bid
    bidRadius = 45.0,                -- you must be this close to the container to bid
    lootSeconds = 90,                -- winner's time to take things out of the lot
    betweenSeconds = 6,
    finalSellSeconds = 120,          -- after the last lot of a round: time to sell
}

-- ============ Travel vehicles ============
-- Every player gets ONE random car from this list at the start of every drive. Add any model you like.
Config.SpawnTravelVehicle = true
Config.TravelVehicles = { 'rebel', 'panto', 'emperor2', 'ratloader', 'tornado3', 'journey', 'trash' }
-- Called on the client after the car spawns. Put your keys / fuel export here, e.g.:
-- Config.OnTravelVehicle = function(veh, plate) TriggerEvent('vehiclekeys:client:SetOwner', plate) end
Config.OnTravelVehicle = nil

-- ============ Lobby (where players create / join the match) ============
-- The blip disappears from the map for everybody while a match is running.
Config.Lobby = {
    coords = vec4(195.2, -934.0, 30.7, 144.0),
    ped = 's_m_m_dockwork_01',
    blip = { sprite = 478, colour = 5, text = 'Storage Wars' }
}

-- ============ NPCs ============
Config.AuctioneerPed = 'a_m_m_business_01'
Config.BuyerPed = 's_m_y_dealer_01'
Config.FarBuyerPed = 'a_m_y_hipster_01'

-- Local offsets from the container door: x = right, y = forward (into the container)
Config.Layout = {
    auctioneer = vec2(3.8, -4.0),
    buyer = vec2(-6.5, -4.5),
}

-- Far collectors: one is picked at random each round. APPROXIMATE coords - adjust them!
Config.FarBuyers = {
    { name = 'Vinewood Collector',  coords = vec4(412.4, 314.8, 103.0, 205.0) },
    { name = 'Vespucci Collector',  coords = vec4(-1175.0, -1567.0, 4.4, 35.0) },
    { name = 'Grapeseed Collector', coords = vec4(2480.0, 4110.0, 38.1, 250.0) },
}

-- ============ Lot types (what the auctioned thing looks like) ============
-- The shell is drawn by the script (floor, walls, roof, lights), the props inside are real objects.
-- Container/garage opening faces the crowd. width = x, depth = into the lot, height = z.
Config.LotTypes = {
    container = {
        label = 'Shipping container',
        width = 2.4, depth = 11.0, height = 2.6, cell = 1.15,
        doors = true, ribs = true, lights = 3, lightRange = 9.0,
        colors = { {170, 60, 40}, {40, 80, 150}, {40, 110, 70}, {175, 140, 50} },
        interior = {105, 105, 110},
    },
    garage = {
        label = 'Garage',
        width = 5.6, depth = 6.4, height = 2.8, cell = 1.25,
        doors = false, ribs = false, lights = 2, lightRange = 10.0,
        colors = { {150, 150, 155}, {125, 110, 100}, {110, 90, 85} },
        interior = {125, 125, 130},
    },
}

-- ============ Rounds ============
-- Each round picks ONE random location. Players must DRIVE there (travelSeconds; the round starts early when everyone arrived).
-- containers = default number of lots in that round (the lobby host can change it per round).
-- steps = what keys 1-4 add to the bid. startMin/startMax = starting bid.
-- hiddenMin/hiddenMax = valuable items hidden behind other things. valueScale = multiplies item values.
-- Locations need a big FLAT open area: the lot is 11 m deep and the crowd stands in front of it.
-- Coords are APPROXIMATE: stand where you want the container DOOR, copy coords + heading.
-- heading = the direction the lot opens INTO (the crowd stands behind it).
Config.Rounds = {
    {
        containers = 3, travelSeconds = 360,
        steps = { 50, 100, 250, 500 },
        startMin = 300, startMax = 700,
        itemsMin = 5, itemsMax = 8,
        hiddenMin = 0, hiddenMax = 1,
        valueScale = 1.0,
        kinds = { container = 70, garage = 30 },
        locations = {
            { name = 'Sandy Shores Airfield', coords = vec3(1747.0, 3273.7, 41.1), heading = 30.0 },
            { name = 'McKenzie Airfield',     coords = vec3(2122.0, 4805.0, 41.2), heading = 90.0 },
        }
    },
    {
        containers = 3, travelSeconds = 360,
        steps = { 100, 250, 500, 1000 },
        startMin = 600, startMax = 1400,
        itemsMin = 7, itemsMax = 11,
        hiddenMin = 1, hiddenMax = 2,
        valueScale = 1.5,
        kinds = { container = 60, garage = 40 },
        locations = {
            { name = 'Maze Bank Arena Lot', coords = vec3(-250.0, -2025.0, 30.1), heading = 50.0 },
            { name = 'Cypress Flats Yard',  coords = vec3(1009.0, -2500.0, 28.4), heading = 80.0 },
        }
    },
    {
        containers = 3, travelSeconds = 360,
        steps = { 250, 500, 1000, 2500 },
        startMin = 1200, startMax = 3000,
        itemsMin = 9, itemsMax = 14,
        hiddenMin = 2, hiddenMax = 3,
        valueScale = 2.2,
        kinds = { container = 50, garage = 50 },
        locations = {
            { name = 'Paleto Sawmill Yard', coords = vec3(-550.0, 5325.0, 70.4), heading = 160.0 },
            { name = 'Grapeseed Farmland',  coords = vec3(2440.0, 4975.0, 46.0), heading = 45.0 },
        }
    },
}

-- ============ Lot quality tiers (hidden from players) ============
-- luck: multiplies the chance of rare items. hiddenMul: scales the number of hidden valuables.
Config.Tiers = {
    { name = 'junk',    chance = 35, luck = 0.2, hiddenMul = 0.5 },
    { name = 'average', chance = 40, luck = 1.0, hiddenMul = 1.0 },
    { name = 'good',    chance = 20, luck = 2.5, hiddenMul = 1.5 },
    { name = 'jackpot', chance = 5,  luck = 6.0, hiddenMul = 2.0 },
}

-- ============ Loot (real props placed inside the lots) ============
-- model = GTA prop. If a model name is not valid on your build it falls back to a cardboard box.
-- value is multiplied by the round's valueScale. rare = true items can also be HIDDEN behind covers.
Config.Loot = {
    { label = 'Cardboard Box',        model = 'prop_cs_cardbox_01',    min = 20,   max = 70,   weight = 30 },
    { label = 'Old TV',               model = 'prop_tv_03',            min = 30,   max = 120,  weight = 25 },
    { label = 'Toolbox',              model = 'prop_toolchest_01',     min = 60,   max = 200,  weight = 22 },
    { label = 'Boombox',              model = 'prop_boombox_01',       min = 80,   max = 260,  weight = 18 },
    { label = 'Suitcase',             model = 'prop_ld_suitcase_01',   min = 100,  max = 350,  weight = 18 },
    { label = 'Acoustic Guitar',      model = 'prop_acc_guitar_01',    min = 150,  max = 500,  weight = 12 },
    { label = 'Golf Bag',             model = 'prop_golf_bag_01',      min = 120,  max = 420,  weight = 12 },
    { label = 'Laptop',               model = 'prop_laptop_01a',       min = 200,  max = 600,  weight = 10 },
    { label = 'Flat Screen TV',       model = 'prop_tv_flat_01',       min = 250,  max = 700,  weight = 9 },
    { label = 'Big Speaker',          model = 'prop_speaker_05',       min = 200,  max = 600,  weight = 9 },
    { label = 'Briefcase of Cash',    model = 'prop_ld_case_01',       min = 800,  max = 2200, weight = 5, rare = true },
    { label = 'Money Bag',            model = 'prop_money_bag_01',     min = 600,  max = 1800, weight = 4, rare = true },
    { label = 'Signed Electric Guitar', model = 'prop_el_guitar_01',   min = 700,  max = 2000, weight = 4, rare = true },
    { label = 'Old Safe',             model = 'prop_ld_int_safe_01',   min = 1500, max = 4500, weight = 2, rare = true },
    { label = 'Gold Case',            model = 'prop_gold_cont_01',     min = 2500, max = 6000, weight = 1, rare = true },
}

-- Big, cheap props used to hide valuables behind them
Config.Covers = {
    { label = 'Wooden Crate',   model = 'prop_box_wood05a', min = 10, max = 50 },
    { label = 'Big Wooden Crate', model = 'prop_box_wood01a', min = 10, max = 60 },
    { label = 'Barrel',         model = 'prop_barrel_02a',  min = 10, max = 40 },
    { label = 'Old Fridge Box', model = 'prop_boxpile_07d', min = 10, max = 60 },
}
