Config = {}

Config.Locale = 'ru'
Config.DefaultBidStep = 500
Config.AuctionTimer = 30 -- seconds per container auction

-- Blip Configuration
Config.Blip = {
    Sprite = 473, -- Container Icon (distinct from main game/garage)
    Color = 5,    -- Yellow/Gold
    Scale = 0.9,
    Name = 'Аукцион Контейнеров (Зона)'
}

Config.SpawnPointOnJoin = vector4(982.5, -102.5, 74.8, 220.0)

-- Locations on flat open areas (NO ROOFS) with sale points directly next to containers
Config.Locations = {
    {
        id = 1,
        type = 'container',
        label = 'Контейнер #1 - Морской порт',
        containerModel = `prop_container_05a`,
        coords = vector4(980.2, -101.5, 74.5, 140.0),
        barrierOffset = vector3(0.0, -2.5, 0.0),
        salePoint = vector3(984.0, -99.5, 74.5),
        items = {
            { model = `prop_boxpile_02a`, price = 1200, name = 'Коробки с техникой' },
            { model = `prop_tv_flat_01`, price = 2500, name = 'Плазменный ТВ' },
            { model = `prop_tool_bench02`, price = 800, name = 'Верстак с инструментами' }
        },
        hasVehicle = true,
        vehicleModel = `elegy2`,
        vehiclePos = vector4(980.2, -101.5, 74.5, 140.0),
        hasCover = true,
        hasCloset = true
    },
    {
        id = 2,
        type = 'container',
        label = 'Контейнер #2 - Морской порт',
        containerModel = `prop_container_05a`,
        coords = vector4(995.0, -115.0, 74.5, 140.0),
        barrierOffset = vector3(0.0, -2.5, 0.0),
        salePoint = vector3(998.5, -113.0, 74.5),
        items = {
            { model = `prop_laptop_01a`, price = 1500, name = 'Ноутбуки' },
            { model = `prop_antique_chair`, price = 4500, name = 'Антикварное кресло' }
        },
        hasVehicle = true,
        vehicleModel = `jester`,
        vehiclePos = vector4(995.0, -115.0, 74.5, 140.0),
        hasCover = true,
        hasCloset = false
    },
    {
        id = 3,
        type = 'garage',
        label = 'БОНУСНЫЙ РАУНД: Забытый Гараж',
        containerModel = `prop_slotted_gatedoor`,
        coords = vector4(1012.0, -130.0, 74.5, 140.0),
        barrierOffset = vector3(0.0, -1.5, 0.0),
        salePoint = vector3(1015.0, -128.0, 74.5),
        items = {
            { model = `prop_gold_vault`, price = 15000, name = 'Слитки золота' },
            { model = `prop_safe_001`, price = 8000, name = 'Сейф с ценностями' }
        },
        hasVehicle = true,
        vehicleModel = `t20`,
        vehiclePos = vector4(1012.0, -130.0, 74.5, 140.0),
        hasCover = true,
        hasCloset = true
    }
}
