-- loc = { coords = vec3, heading = number }
-- Local space: x = right, y = forward (the direction the lot opens INTO), origin = container door.

function LocalToWorld(loc, lx, ly)
    local h = math.rad(loc.heading)
    local c, s = math.cos(h), math.sin(h)
    return vec3(loc.coords.x + lx * c - ly * s, loc.coords.y + lx * s + ly * c, loc.coords.z)
end

function GetGrid(kind)
    local T = Config.LotTypes[kind]
    return math.max(1, math.floor(T.width / T.cell)), math.max(2, math.floor(T.depth / T.cell))
end

-- col 1..cols, row 1..rows (row 1 is nearest to the door)
function GetSlotPos(kind, col, row)
    local T = Config.LotTypes[kind]
    local cols, rows = GetGrid(kind)
    local lx = (col - (cols + 1) / 2) * (T.width / cols)
    local ly = (row - 0.5) * (T.depth / rows)
    return lx, ly
end
