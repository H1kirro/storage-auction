Config = {}

-- ============ Общие настройки ============
Config.Language = 'ru'
Config.Framework = 'none' -- 'none' | 'esx' | 'qb'
Config.QBAccount = 'cash'
Config.EntryFee = 0
Config.Prizes = { bestItem = 0, bigSpender = 0 }
Config.ServerDistanceChecks = true

-- ============ Матч ============
Config.MinPlayers = 2
Config.MaxPlayers = 8
Config.StartMoney = 10000
Config.ArrivalRadius = 60.0
Config.InteractRadius = 2.5
Config.LiquidationRate = 0.5
Config.ResultsSeconds = 30
Config.BigSaleAnnounce = 2000
Config.MaxContainers = 6
Config.LocalBuyerMult = 1.0
Config.FarBuyerMult = 1.3
Config.FarBuyerOffset = vec2(0.0, -8.0) -- второй покупатель рядом с местным, но с отдельной точкой взаимодействия
Config.SpawnAtLobby = true
Config.JoinSpawn = vec4(195.2, -934.0, 30.7, 144.0)
Config.BlockLotEntry = true
Config.SkipSaleControl = 47 -- G

-- ============ Таймеры аукциона ============
Config.Auction = {
    previewSeconds = 45,
    firstBidSeconds = 20,
    resetSeconds = 8,
    bidRadius = 45.0,
    lootSeconds = 90,
    betweenSeconds = 6,
    finalSellSeconds = 120,
}

-- ============ Машины для поездок ============
Config.SpawnTravelVehicle = true
Config.TravelVehicles = { 'sultan', 'buffalo', 'tailgater', 'schafter3', 'kuruma', 'elegy2', 'comet2', 'sultanrs' }
Config.UpgradeTravelVehicles = true
Config.OnTravelVehicle = nil

-- ============ Лобби ============
Config.Lobby = {
    coords = vec4(195.2, -934.0, 30.7, 144.0),
    ped = 's_m_m_dockwork_01',
    blip = { sprite = 357, colour = 5, text = 'Storage Wars — лобби' }
}

-- ============ NPC ============
Config.AuctioneerPed = 'a_m_m_business_01'
Config.BuyerPed = 's_m_y_dealer_01'
Config.FarBuyerPed = 'a_m_y_hipster_01'
Config.Layout = {
    auctioneer = vec2(3.8, -4.0),
    buyer = vec2(-5.0, -4.5),
}
Config.FarBuyers = {
    { name = 'Коллекционер Вайнвуда' },
    { name = 'Коллекционер Веспуччи' },
    { name = 'Коллекционер Грейпсида' },
}

-- ============ Типы лотов ============
-- Лоты ставятся только на открытой земле из списка Rounds.locations.
Config.LotTypes = {
    container = {
        label = 'Стандартный контейнер', width = 2.4, depth = 11.0, height = 2.6, cell = 1.15,
        doors = true, ribs = true, lights = 3, lightRange = 9.0,
        colors = { {170,60,40}, {40,80,150}, {40,110,70}, {175,140,50}, {85,95,105}, {125,55,45} },
        interior = {105,105,110},
    },
    container_blue = {
        label = 'Синий морской контейнер', width = 2.4, depth = 11.0, height = 2.6, cell = 1.15,
        doors = true, ribs = true, lights = 3, lightRange = 9.0,
        colors = { {25,80,165}, {35,115,180}, {45,65,130}, {70,125,155} }, interior = {85,100,115},
    },
    container_rust = {
        label = 'Ржавый контейнер', width = 2.5, depth = 9.0, height = 2.55, cell = 1.15,
        doors = true, ribs = true, lights = 2, lightRange = 8.0,
        colors = { {130,60,35}, {105,65,45}, {160,85,50}, {80,75,65} }, interior = {100,85,75},
    },
    container_long = {
        label = 'Длинный грузовой контейнер', width = 2.5, depth = 12.0, height = 2.7, cell = 1.1,
        doors = true, ribs = true, lights = 4, lightRange = 10.0,
        colors = { {45,95,60}, {35,75,120}, {150,75,40}, {95,100,105} }, interior = {100,105,110},
    },
    container_small = {
        label = 'Короткий складской контейнер', width = 2.7, depth = 7.5, height = 2.45, cell = 1.0,
        doors = true, ribs = true, lights = 2, lightRange = 8.0,
        colors = { {145,70,45}, {55,95,135}, {70,115,75}, {145,125,80} }, interior = {105,100,95},
    },
    garage = {
        label = 'Бонусный гараж', width = 6.2, depth = 7.4, height = 3.0, cell = 1.25,
        doors = false, ribs = false, lights = 3, lightRange = 10.0,
        colors = { {150,150,155}, {125,110,100}, {110,90,85}, {80,105,115} }, interior = {125,125,130},
    },
}

-- ============ Раунды ============
-- Все координаты — открытые площадки/поля/аэродромы; крыши не используются.
Config.Rounds = {
    {
        containers = 3, travelSeconds = 300, steps = {50, 100, 250, 500}, startMin = 300, startMax = 700,
        itemsMin = 5, itemsMax = 8, hiddenMin = 0, hiddenMax = 1, valueScale = 1.0,
        kinds = { container = 45, container_blue = 22, container_rust = 22, container_small = 11 },
        locations = {
            { name = 'Аэродром Сэнди-Шорс', coords = vec3(1747.0, 3273.7, 41.1), heading = 30.0 },
            { name = 'Аэродром Маккензи', coords = vec3(2122.0, 4805.0, 41.2), heading = 90.0 },
            { name = 'Пустырь у Сэнди-Шорс', coords = vec3(1537.0, 3562.0, 35.4), heading = 125.0 },
        }
    },
    {
        containers = 3, travelSeconds = 300, steps = {100, 250, 500, 1000}, startMin = 600, startMax = 1400,
        itemsMin = 7, itemsMax = 11, hiddenMin = 1, hiddenMax = 2, valueScale = 1.5,
        kinds = { container = 32, container_blue = 22, container_rust = 22, container_long = 14, container_small = 10 },
        locations = {
            { name = 'Промышленная площадка Сайпресс-Флэтс', coords = vec3(1009.0, -2500.0, 28.4), heading = 80.0 },
            { name = 'Поля Грейпсида', coords = vec3(2440.0, 4975.0, 46.0), heading = 45.0 },
            { name = 'Грузовой двор аэропорта', coords = vec3(-1030.0, -3000.0, 13.0), heading = 0.0 },
        }
    },
    {
        containers = 3, travelSeconds = 300, steps = {250, 500, 1000, 2500}, startMin = 1200, startMax = 3000,
        itemsMin = 9, itemsMax = 14, hiddenMin = 2, hiddenMax = 3, valueScale = 2.2,
        kinds = { container = 28, container_blue = 22, container_rust = 22, container_long = 16, container_small = 12 },
        locations = {
            { name = 'Открытый двор лесопилки Палето', coords = vec3(-550.0, 5325.0, 70.4), heading = 160.0 },
            { name = 'Пустая площадка Грейпсида', coords = vec3(1978.0, 4625.0, 41.5), heading = 220.0 },
            { name = 'Открытая площадка Стаб-Сити', coords = vec3(39.0, 3713.0, 39.0), heading = 85.0 },
        }
    },
    {
        bonus = true, containers = 3, travelSeconds = 240, steps = {500, 1000, 2500, 5000}, startMin = 2500, startMax = 5000,
        itemsMin = 8, itemsMax = 13, hiddenMin = 2, hiddenMax = 4, valueScale = 3.0, vehicleChance = 45,
        kinds = { garage = 100 },
        locations = {
            { name = 'Бонусные гаражи Сэнди-Шорс', coords = vec3(1687.0, 3295.0, 41.1), heading = 270.0 },
            { name = 'Бонусный гараж Грейпсида', coords = vec3(2044.0, 4772.0, 41.2), heading = 135.0 },
            { name = 'Площадка бонусных гаражей Палето', coords = vec3(-393.0, 6046.0, 31.5), heading = 45.0 },
        }
    },
}

-- ============ Редкость лотов ============
Config.Tiers = {
    { name = 'junk', chance = 30, luck = 0.2, hiddenMul = 0.5 },
    { name = 'average', chance = 40, luck = 1.0, hiddenMul = 1.0 },
    { name = 'good', chance = 22, luck = 2.5, hiddenMul = 1.5 },
    { name = 'jackpot', chance = 8, luck = 6.0, hiddenMul = 2.0 },
}

-- ============ Предметы ============
Config.Loot = {
    { label = 'Картонная коробка', model = 'prop_cs_cardbox_01', min = 20, max = 70, weight = 30 },
    { label = 'Старый телевизор', model = 'prop_tv_03', min = 30, max = 120, weight = 25 },
    { label = 'Ящик с инструментами', model = 'prop_toolchest_01', min = 60, max = 200, weight = 22 },
    { label = 'Бумбокс', model = 'prop_boombox_01', min = 80, max = 260, weight = 18 },
    { label = 'Чемодан', model = 'prop_ld_suitcase_01', min = 100, max = 350, weight = 18 },
    { label = 'Акустическая гитара', model = 'prop_acc_guitar_01', min = 150, max = 500, weight = 12 },
    { label = 'Сумка для гольфа', model = 'prop_golf_bag_01', min = 120, max = 420, weight = 12 },
    { label = 'Ноутбук', model = 'prop_laptop_01a', min = 200, max = 600, weight = 10 },
    { label = 'Плоский телевизор', model = 'prop_tv_flat_01', min = 250, max = 700, weight = 9 },
    { label = 'Большая колонка', model = 'prop_speaker_05', min = 200, max = 600, weight = 9 },
    { label = 'Винтажная камера', model = 'prop_pap_camera_01', min = 180, max = 650, weight = 8 },
    { label = 'Редкий виниловый проигрыватель', model = 'prop_turntable_01', min = 300, max = 950, weight = 7 },
    { label = 'Антикварный сундук', model = 'prop_ld_int_safe_01', min = 700, max = 1800, weight = 6 },
    { label = 'Кейс с наличными', model = 'prop_ld_case_01', min = 800, max = 2200, weight = 5, rare = true },
    { label = 'Мешок денег', model = 'prop_money_bag_01', min = 600, max = 1800, weight = 4, rare = true },
    { label = 'Подписанная электрогитара', model = 'prop_el_guitar_01', min = 700, max = 2000, weight = 4, rare = true },
    { label = 'Старый сейф', model = 'prop_ld_int_safe_01', min = 1500, max = 4500, weight = 2, rare = true },
    { label = 'Золотой кейс', model = 'prop_gold_cont_01', min = 2500, max = 6000, weight = 1, rare = true },
}

-- Эти предметы случайно закрывают часть находок. После снятия предмета открывается то, что за ним.
Config.Covers = {
    { label = 'Деревянный ящик', model = 'prop_box_wood05a', min = 10, max = 50 },
    { label = 'Большой деревянный ящик', model = 'prop_box_wood01a', min = 10, max = 60 },
    { label = 'Бочка', model = 'prop_barrel_02a', min = 10, max = 40 },
    { label = 'Стопка старых коробок', model = 'prop_boxpile_07d', min = 10, max = 60 },
    { label = 'Шкаф', model = 'prop_rub_cabinet01', min = 20, max = 75 },
    { label = 'Складской тент', model = 'prop_tarp_01', min = 10, max = 45 },
}

-- Редкий автомобиль появляется ТОЛЬКО в бонусном гараже и изначально скрыт за шкафом.
Config.JackpotVehicles = {
    { label = 'Редкий автомобиль (суперудача)', vehicleModel = 'sultanrs', min = 9000, max = 22000 },
    { label = 'Спортивный автомобиль (суперудача)', vehicleModel = 'comet2', min = 10000, max = 25000 },
    { label = 'Редкий маслкар (суперудача)', vehicleModel = 'dominator', min = 8500, max = 21000 },
}
