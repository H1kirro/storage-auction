local S, Me = nil, { cash = 0, spent = 0, items = 0, best = 0 }
local focused, inspecting, lobbyOpen, resultsOpen = false, false, false, false
local cam, camLocal, camFov = nil, { x = 0.0, y = -2.2 }, 55.0
local LotProps, PropInfo = {}, {}      -- uid -> entity / label
local lotId, shellGz = nil, nil
local autoInspected = {}
local hoverEnt = nil
local Npcs, Labels = {}, {}
local blips = { lobby = nil, far = nil, farIdx = nil, lot = nil, travel = {} }
local travelVeh = nil
local initialSpawnDone = false
local myId = GetPlayerServerId(PlayerId())

-- ===== Helpers =====
local function ui(action, data) SendNUIMessage({ action = action, data = data }) end

local function toast(msg, t) ui('toast', { msg = msg, type = t or 'info' }) end

local function money(n)
    local s = tostring(math.floor(n or 0))
    s = s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    return '$' .. s
end

local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

local function curLoc()
    if not S or not S.round or S.round < 1 or not S.locIdx or S.locIdx < 1 then return nil end
    return Config.Rounds[S.round].locations[S.locIdx]
end

local function groundZ(x, y, z)
    local found, gz = GetGroundZFor_3dCoord(x, y, z + 100.0, false)
    if found then return gz end
    return z
end

local function Draw3D(coords, text)
    SetDrawOrigin(coords.x, coords.y, coords.z, 0)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 230)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function helpText(msg)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

local function openFocus() focused = true SetNuiFocus(true, true) end
local function closeFocus() focused = false SetNuiFocus(false, false) end

-- ===== Blips =====
local function setLobbyBlip(on)
    if on and not blips.lobby then
        local L = Config.Lobby
        local b = AddBlipForCoord(L.coords.x, L.coords.y, L.coords.z)
        SetBlipSprite(b, L.blip.sprite)
        SetBlipColour(b, L.blip.colour)
        SetBlipScale(b, 0.8)
        SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(L.blip.text)
        EndTextCommandSetBlipName(b)
        blips.lobby = b
    elseif not on and blips.lobby then
        RemoveBlip(blips.lobby)
        blips.lobby = nil
    end
end

local function clearTravelBlips()
    if #blips.travel == 0 then return end
    for _, b in ipairs(blips.travel) do RemoveBlip(b) end
    blips.travel = {}
    DeleteWaypoint()
end

local function startTravelBlips()
    if #blips.travel > 0 then return end
    local loc = curLoc()
    if not loc then return end
    local b = AddBlipForCoord(loc.coords.x, loc.coords.y, loc.coords.z)
    SetBlipSprite(b, 1)
    SetBlipColour(b, 5)
    SetBlipScale(b, 1.0)
    SetBlipRoute(b, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Аукцион: ' .. loc.name)
    EndTextCommandSetBlipName(b)
    local r = AddBlipForRadius(loc.coords.x, loc.coords.y, loc.coords.z, Config.ArrivalRadius)
    SetBlipColour(r, 5)
    SetBlipAlpha(r, 120)
    blips.travel = { b, r }
    SetNewWaypoint(loc.coords.x, loc.coords.y)
end

local function getFarBuyer()
    if not S or (S.state ~= 'travel' and S.state ~= 'round') then return nil end
    local data = Config.FarBuyers[S.farIdx]
    local loc = curLoc()
    if not data or not loc then return nil end
    local coords = S.farPos or LocalToWorld(loc, Config.FarBuyerOffset.x, Config.FarBuyerOffset.y)
    return { name = S.farName or data.name, coords = coords }
end

local function updateLotBlip()
    local loc = curLoc()
    local active = S and S.state == 'round' and S.phase ~= 'final' and S.phase ~= nil and loc
    if active and not blips.lot then
        local b = AddBlipForCoord(loc.coords.x, loc.coords.y, loc.coords.z)
        SetBlipSprite(b, 478) -- отдельная иконка аукционного контейнера/гаража
        SetBlipColour(b, 5)
        SetBlipScale(b, 0.9)
        SetBlipAsShortRange(b, false)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString('Аукционный контейнер / гараж')
        EndTextCommandSetBlipName(b)
        blips.lot = b
    elseif not active and blips.lot then
        RemoveBlip(blips.lot)
        blips.lot = nil
    end
end

local function updateFarBlip()
    local fb = getFarBuyer()
    if fb and (not blips.far or blips.farIdx ~= S.farIdx) then
        if blips.far then RemoveBlip(blips.far) end
        local c = fb.coords
        local b = AddBlipForCoord(c.x, c.y, c.z)
        SetBlipSprite(b, 500)
        SetBlipColour(b, 2)
        SetBlipScale(b, 0.8)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(('%s (x%.1f)'):format(fb.name, Config.FarBuyerMult))
        EndTextCommandSetBlipName(b)
        blips.far, blips.farIdx = b, S.farIdx
    elseif not fb and blips.far then
        RemoveBlip(blips.far)
        blips.far, blips.farIdx = nil, nil
    elseif fb and blips.far then
        local c = fb.coords
        SetBlipCoords(blips.far, c.x, c.y, c.z)
    end
end


-- Одноразовый стартовый спавн рядом с лобби Storage Wars.
local function moveToInitialSpawn()
    if initialSpawnDone or not Config.SpawnAtLobby then return end
    initialSpawnDone = true
    local sp = Config.JoinSpawn or Config.Lobby.coords
    local ped = PlayerPedId()
    if not DoesEntityExist(ped) then return end
    local z = groundZ(sp.x, sp.y, sp.z)
    SetEntityCoordsNoOffset(ped, sp.x, sp.y, z + 0.2, false, false, false)
    SetEntityHeading(ped, sp.w or 0.0)
end

AddEventHandler('playerSpawned', function()
    if initialSpawnDone or not Config.SpawnAtLobby then return end
    CreateThread(function() Wait(700); moveToInitialSpawn() end)
end)

CreateThread(function()
    Wait(8000)
    if not initialSpawnDone and NetworkIsPlayerActive(PlayerId()) then moveToInitialSpawn() end
end)

-- ===== NPCs =====
local function spawnNpc(key, model, x, y, z, heading, scenario, label)
    -- NPCs must follow the active auction when the next round moves to another yard.
    if Npcs[key] and DoesEntityExist(Npcs[key]) then
        local old = GetEntityCoords(Npcs[key])
        if #(old - vec3(x, y, z)) < 8.0 then
            Labels[key] = label
            return
        end
        DeleteEntity(Npcs[key])
        Npcs[key], Labels[key] = nil, nil
    end
    local m = joaat(model)
    if not IsModelInCdimage(m) then m = joaat('a_m_m_business_01') end
    lib.requestModel(m)
    local ped = CreatePed(0, m, x, y, z, heading, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    if scenario then TaskStartScenarioInPlace(ped, scenario, 0, true) end
    FreezeEntityPosition(ped, true)
    SetModelAsNoLongerNeeded(m)
    Npcs[key] = ped
    Labels[key] = label
end

local function clearNpc(key)
    if Npcs[key] then
        if DoesEntityExist(Npcs[key]) then DeleteEntity(Npcs[key]) end
        Npcs[key], Labels[key] = nil, nil
    end
end

local function manageNpcs()
    local ppos = GetEntityCoords(cache.ped)
    local loc = curLoc()
    if S and S.state == 'round' and loc and #(ppos - loc.coords) < 160.0 then
        local a, b = Config.Layout.auctioneer, Config.Layout.buyer
        local aw = LocalToWorld(loc, a.x, a.y)
        local bw = LocalToWorld(loc, b.x, b.y)
        spawnNpc('auctioneer', Config.AuctioneerPed, aw.x, aw.y, groundZ(aw.x, aw.y, aw.z), loc.heading + 180.0, 'WORLD_HUMAN_CLIPBOARD', 'АУКЦИОНЕР')
        spawnNpc('buyer', Config.BuyerPed, bw.x, bw.y, groundZ(bw.x, bw.y, bw.z), loc.heading + 180.0, nil,
            ('ПОКУПАТЕЛЬ (x%.1f)'):format(Config.LocalBuyerMult))
    else
        clearNpc('auctioneer')
        clearNpc('buyer')
    end

    local fb = getFarBuyer()
    if fb and #(ppos - fb.coords) < 160.0 then
        spawnNpc('far', Config.FarBuyerPed, fb.coords.x, fb.coords.y, groundZ(fb.coords.x, fb.coords.y, fb.coords.z) - 1.0, 0.0, nil,
            ('%s (x%.1f)'):format(fb.name:upper(), Config.FarBuyerMult))
    else
        clearNpc('far')
    end
end

-- ===== Lot props =====
local function clearLot()
    for _, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then DeleteEntity(ent) end
    end
    LotProps, PropInfo = {}, {}
    lotId = nil
end

local function spawnItem(it, loc)
    local w = LocalToWorld(loc, it.lx, it.ly)
    local obj
    if it.vehicleModel then
        local model = joaat(it.vehicleModel)
        if not IsModelInCdimage(model) or not IsModelAVehicle(model) then model = joaat('sultanrs') end
        lib.requestModel(model, 10000)
        obj = CreateVehicle(model, w.x, w.y, shellGz or w.z, loc.heading + (it.heading or 0.0), false, false)
        if DoesEntityExist(obj) then
            SetVehicleOnGroundProperly(obj)
            SetVehicleDoorsLocked(obj, 2)
            SetVehicleEngineOn(obj, false, true, true)
            SetVehicleUndriveable(obj, true)
            SetVehicleCanBeVisiblyDamaged(obj, false)
            FreezeEntityPosition(obj, true)
        end
        SetModelAsNoLongerNeeded(model)
    else
        local model = joaat(it.model or 'prop_cs_cardbox_01')
        if not IsModelInCdimage(model) then model = joaat('prop_cs_cardbox_01') end
        lib.requestModel(model)
        obj = CreateObject(model, w.x, w.y, shellGz or w.z, false, false, false)
        SetEntityHeading(obj, loc.heading + it.heading)
        PlaceObjectOnGroundProperly(obj)
        FreezeEntityPosition(obj, true)
        SetModelAsNoLongerNeeded(model)
    end
    LotProps[it.uid] = obj
    PropInfo[it.uid] = it.label
end

local function removeProp(uid)
    local ent = LotProps[uid]
    LotProps[uid], PropInfo[uid] = nil, nil
    if not ent then return end
    if hoverEnt == ent then hoverEnt = nil end
    CreateThread(function()
        if not DoesEntityExist(ent) then return end
        local c = GetEntityCoords(ent)
        for i = 1, 12 do
            SetEntityCoordsNoOffset(ent, c.x, c.y, c.z + i * 0.08, false, false, false)
            SetEntityAlpha(ent, 255 - i * 20, false)
            Wait(20)
        end
        DeleteEntity(ent)
    end)
end

local function ensureLot()
    local loc = curLoc()
    local lot = S and S.state == 'round' and S.lot or nil
    if not lot or not loc then
        if lotId then clearLot() end
        return
    end
    local dist = #(GetEntityCoords(cache.ped) - loc.coords)
    if dist > 240.0 then
        if lotId then clearLot() end
        return
    end
    if dist > 160.0 then return end

    if lotId ~= lot.id then
        clearLot()
        lotId = lot.id
        shellGz = groundZ(loc.coords.x, loc.coords.y, loc.coords.z)
    end
    local want = {}
    for _, it in ipairs(lot.items) do
        want[it.uid] = true
        if not LotProps[it.uid] then spawnItem(it, loc) end
    end
    for uid in pairs(LotProps) do
        if not want[uid] then removeProp(uid) end
    end
end

-- ===== Shell (container / garage) drawn every frame =====
local function drawShell(loc, lot)
    local T = Config.LotTypes[lot.kind]
    local oc = T.colors[lot.colorIdx] or T.colors[1]
    local ic = T.interior
    local W, D, H = T.width / 2, T.depth, T.height
    local dark = { math.floor(oc[1] * 0.7), math.floor(oc[2] * 0.7), math.floor(oc[3] * 0.7) }

    local function P(lx, ly, lz)
        local w = LocalToWorld(loc, lx, ly)
        return vec3(w.x, w.y, shellGz + lz)
    end
    local function quad(a, b, c, d, col)
        DrawPoly(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z, col[1], col[2], col[3], 255)
        DrawPoly(a.x, a.y, a.z, c.x, c.y, c.z, b.x, b.y, b.z, col[1], col[2], col[3], 255)
        DrawPoly(a.x, a.y, a.z, c.x, c.y, c.z, d.x, d.y, d.z, col[1], col[2], col[3], 255)
        DrawPoly(a.x, a.y, a.z, d.x, d.y, d.z, c.x, c.y, c.z, col[1], col[2], col[3], 255)
    end

    -- outside
    quad(P(-W, 0, 0), P(-W, D, 0), P(-W, D, H), P(-W, 0, H), oc)
    quad(P(W, 0, 0), P(W, D, 0), P(W, D, H), P(W, 0, H), oc)
    quad(P(-W, D, 0), P(W, D, 0), P(W, D, H), P(-W, D, H), oc)
    quad(P(-W, 0, H), P(W, 0, H), P(W, D, H), P(-W, D, H), oc)
    quad(P(-W, 0, H - 0.4), P(W, 0, H - 0.4), P(W, 0, H), P(-W, 0, H), dark)
    -- Единый непрозрачный пол. Внутренние стены не перерисовываем поверх наружных:
    -- иначе предметы визуально просвечивают через оболочку.
    quad(P(-W + 0.08, 0, 0.04), P(W - 0.08, 0, 0.04), P(W - 0.08, D - 0.08, 0.04), P(-W + 0.08, D - 0.08, 0.04),
        { math.floor(ic[1] * 0.65), math.floor(ic[2] * 0.65), math.floor(ic[3] * 0.65) })

    if T.doors then
        quad(P(-W, 0, 0), P(-W, 0, H), P(-W - 0.5, -1.15, H), P(-W - 0.5, -1.15, 0), oc)
        quad(P(W, 0, 0), P(W, 0, H), P(W + 0.5, -1.15, H), P(W + 0.5, -1.15, 0), oc)
    end
    if T.ribs then
        local y = 0.4
        while y < D - 0.2 do
            local a, b = P(-W - 0.01, y, 0.05), P(-W - 0.01, y, H - 0.05)
            DrawLine(a.x, a.y, a.z, b.x, b.y, b.z, dark[1], dark[2], dark[3], 255)
            local c, d = P(W + 0.01, y, 0.05), P(W + 0.01, y, H - 0.05)
            DrawLine(c.x, c.y, c.z, d.x, d.y, d.z, dark[1], dark[2], dark[3], 255)
            y = y + 0.4
        end
    end

    for n = 1, T.lights do
        local p = P(0, D * n / (T.lights + 1), H - 0.3)
        DrawLightWithRange(p.x, p.y, p.z, 255, 235, 200, T.lightRange, 6.0)
    end

    Draw3D(P(0, -0.3, H + 0.6), ('ЛОТ %d / %d  —  %s'):format(S.lotIdx, S.lotCount, T.label:upper()))
end

CreateThread(function()
    while true do
        local lot = S and S.state == 'round' and S.lot or nil
        local loc = curLoc()
        if lot and loc and shellGz and lotId == lot.id and #(GetEntityCoords(cache.ped) - loc.coords) < 90.0 then
            drawShell(loc, lot)
            Wait(0)
        else
            Wait(300)
        end
    end
end)

-- NPC labels
CreateThread(function()
    while true do
        local any = false
        local ppos = GetEntityCoords(cache.ped)
        for key, ped in pairs(Npcs) do
            if Labels[key] and DoesEntityExist(ped) then
                local pc = GetEntityCoords(ped)
                if #(ppos - pc) < 14.0 then
                    any = true
                    Draw3D(pc + vec3(0.0, 0.0, 1.15), Labels[key])
                end
            end
        end
        Wait(any and 0 or 300)
    end
end)

-- ===== Travel vehicle =====
RegisterNetEvent('storage:spawnCar', function(modelName)
    if not Config.SpawnTravelVehicle then return end
    CreateThread(function()
        local model = joaat(modelName)
        if not IsModelInCdimage(model) or not IsModelAVehicle(model) then return end
        lib.requestModel(model, 10000)

        if travelVeh and DoesEntityExist(travelVeh) then
            SetEntityAsMissionEntity(travelVeh, true, true)
            DeleteVehicle(travelVeh)
        end
        local ped = PlayerPedId()
        local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 5.0, 0.0)
        local spawn, heading = pos, GetEntityHeading(ped)
        local ok, node, nodeH = GetClosestVehicleNodeWithHeading(pos.x, pos.y, pos.z, 1, 3.0, 0)
        if ok and #(node - pos) < 30.0 then spawn, heading = node, nodeH end

        local veh = CreateVehicle(model, spawn.x, spawn.y, spawn.z, heading, true, false)
        SetEntityAsMissionEntity(veh, true, true)
        SetVehicleOnGroundProperly(veh)
        SetVehicleDirtLevel(veh, 3.0)
        SetVehicleNumberPlateText(veh, ('WARS%03d'):format(math.random(0, 999)))
        if Config.UpgradeTravelVehicles then
            SetVehicleModKit(veh, 0)
            for _, modType in ipairs({11, 12, 13, 15}) do
                local n = GetNumVehicleMods(veh, modType)
                if n and n > 0 then SetVehicleMod(veh, modType, n - 1, false) end
            end
            ToggleVehicleMod(veh, 18, true) -- turbo
            SetVehicleEnginePowerMultiplier(veh, 45.0)
            SetVehicleEngineTorqueMultiplier(veh, 1.45)
        end
        TaskWarpPedIntoVehicle(ped, veh, -1)
        SetModelAsNoLongerNeeded(model)
        travelVeh = veh
        if Config.OnTravelVehicle then Config.OnTravelVehicle(veh, GetVehicleNumberPlateText(veh)) end
        toast('Машина готова! Удачной поездки.', 'success')
    end)
end)

-- ===== Inspect mode (winner takes things out of the lot) =====
local function updateCam()
    local loc, lot = curLoc(), S and S.lot
    if not cam or not loc or not lot then return end
    local T = Config.LotTypes[lot.kind]
    camLocal.x = clamp(camLocal.x, -T.width / 2 + 0.3, T.width / 2 - 0.3)
    camLocal.y = clamp(camLocal.y, -4.0, T.depth * 0.7)
    local w = LocalToWorld(loc, camLocal.x, camLocal.y)
    SetCamCoord(cam, w.x, w.y, (shellGz or w.z) + 1.55)
    SetCamRot(cam, -12.0, 0.0, loc.heading + 0.0, 2)
    SetCamFov(cam, camFov)
end

local function setHover(ent)
    if hoverEnt == ent then return end
    if hoverEnt and DoesEntityExist(hoverEnt) then SetEntityDrawOutline(hoverEnt, false) end
    hoverEnt = ent
    if ent and DoesEntityExist(ent) then
        SetEntityDrawOutlineColor(255, 183, 3, 255)
        SetEntityDrawOutline(ent, true)
    end
end

local function startInspect()
    if inspecting then return end
    inspecting = true
    FreezeEntityPosition(PlayerPedId(), true)
    cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    camLocal, camFov = { x = 0.0, y = -2.2 }, 55.0
    updateCam()
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 800, true, true)
    openFocus()
    ui('inspect', { on = true })
end

local function stopInspect()
    if not inspecting then return end
    inspecting = false
    setHover(nil)
    RenderScriptCams(false, true, 600, true, true)
    local c = cam
    cam = nil
    CreateThread(function()
        Wait(700)
        if c then DestroyCam(c, false) end
    end)
    FreezeEntityPosition(PlayerPedId(), false)
    closeFocus()
    ui('inspect', { on = false })
end

-- Screen-space picking: nearest prop whose projected bounding sphere contains the cursor.
local function pickAt(nx, ny)
    if not cam then return nil end
    local w, h = GetActiveScreenResolution()
    local camPos = GetCamCoord(cam)
    local yaw = math.rad(GetCamRot(cam, 2).z)
    local right = vec3(math.cos(yaw), math.sin(yaw), 0.0)
    local best, bd = nil, 1e9
    for uid, ent in pairs(LotProps) do
        if DoesEntityExist(ent) then
            local mn, mx = GetModelDimensions(GetEntityModel(ent))
            local size = math.max(mx.x - mn.x, mx.y - mn.y, mx.z - mn.z)
            local r = size * 0.5 * 0.75
            local c = GetOffsetFromEntityInWorldCoords(ent, (mn.x + mx.x) / 2, (mn.y + mx.y) / 2, (mn.z + mx.z) / 2)
            local on, sx, sy = GetScreenCoordFromWorldCoord(c.x, c.y, c.z)
            if on then
                local on2, sx2 = GetScreenCoordFromWorldCoord(c.x + right.x * r, c.y + right.y * r, c.z)
                local rpx = on2 and math.abs(sx2 - sx) * w or 40.0
                local dx, dy = (nx - sx) * w, (ny - sy) * h
                if dx * dx + dy * dy <= rpx * rpx then
                    local d = #(c - camPos)
                    if d < bd then best, bd = uid, d end
                end
            end
        end
    end
    return best
end

RegisterNUICallback('hover', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    setHover(uid and LotProps[uid] or nil)
    cb({ label = uid and PropInfo[uid] or nil })
end)

RegisterNUICallback('pick', function(d, cb)
    if not inspecting then return cb({}) end
    local uid = pickAt(d.x, d.y)
    if not uid then return cb({}) end
    local ok, item, revealed = lib.callback.await('storage:pickup', false, uid)
    if ok then PlaySoundFrontend(-1, 'PICK_UP', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
    cb({ ok = ok, label = item and item.label, value = item and item.value, revealed = revealed or 0 })
end)

RegisterNUICallback('cam', function(d, cb)
    if inspecting then
        camLocal.x = camLocal.x + (d.dx or 0) * 0.35
        camLocal.y = camLocal.y + (d.dy or 0) * 0.35
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('fov', function(d, cb)
    if inspecting then
        camFov = clamp(camFov + (d.d or 0) * 3.0, 30.0, 70.0)
        updateCam()
    end
    cb({})
end)

RegisterNUICallback('done', function(_, cb)
    lib.callback.await('storage:finishLoot', false)
    stopInspect()
    cb({})
end)

-- ===== Lobby / sell / generic UI callbacks =====
local function openLobby()
    local info = lib.callback.await('storage:lobbyInfo', false)
    lobbyOpen = true
    openFocus()
    ui('lobby', { info = info })
end

local function openSell(which)
    local inv = lib.callback.await('storage:getInv', false, which)
    if not inv then return toast('Покупатель слишком далеко.', 'error') end
    openFocus()
    ui('sell', { which = which, inv = inv, canSkip = S and S.state == 'round' and S.phase == 'final' })
end

RegisterNUICallback('close', function(_, cb)
    if inspecting then
        stopInspect()
    else
        lobbyOpen, resultsOpen = false, false
        closeFocus()
    end
    ui('close')
    cb({})
end)

RegisterNUICallback('lobbyJoin', function(_, cb)
    local ok, msg = lib.callback.await('storage:join', false)
    toast(msg, ok and 'success' or 'error')
    cb({ ok = ok })
end)

RegisterNUICallback('lobbyLeave', function(_, cb)
    lib.callback.await('storage:leave', false)
    lobbyOpen = false
    closeFocus()
    ui('close')
    toast('Вы вышли из матча.')
    cb({})
end)

RegisterNUICallback('lobbyStart', function(_, cb)
    local ok, msg = lib.callback.await('storage:start', false)
    if not ok and msg then toast(msg, 'error') end
    cb({ ok = ok })
end)

RegisterNUICallback('setContainers', function(d, cb)
    lib.callback.await('storage:setContainers', false, d.round, d.value)
    cb({})
end)

RegisterNUICallback('leaderboard', function(_, cb)
    cb({ rows = lib.callback.await('storage:leaderboard', false) or {} })
end)

RegisterNUICallback('sell', function(d, cb)
    local ok, paid = lib.callback.await('storage:sell', false, d.which, d.uid)
    if ok then toast('Продано за ' .. money(paid), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)

RegisterNUICallback('sellAll', function(d, cb)
    local ok, paid = lib.callback.await('storage:sellAll', false, d.which)
    if ok then toast('Всё продано за ' .. money(paid), 'success') end
    cb({ ok = ok, inv = lib.callback.await('storage:getInv', false, d.which) })
end)


RegisterNUICallback('skipSale', function(_, cb)
    local ok, msg = lib.callback.await('storage:skipSale', false)
    if ok then
        toast('Этап продажи пропущен. Непроданные вещи останутся у вас.', 'success')
        closeFocus()
        ui('close')
    elseif msg then
        toast(msg, 'error')
    end
    cb({ ok = ok })
end)


-- ===== Events from the server =====
local function sendState()
    if not S then return end
    local loc = curLoc()
    ui('state', {
        state = S.state, phase = S.phase, round = S.round, rounds = S.rounds, remaining = S.remaining,
        lotIdx = S.lotIdx, lotCount = S.lotCount, steps = S.steps, bid = S.bid,
        kind = S.lot and S.lot.kind, startPrice = S.lot and S.lot.startPrice,
        owner = S.lotOwnerName, mine = (S.lotOwner == myId), lead = (S.bid and S.bid.bidder == myId),
        locName = loc and loc.name, bonusRound = Config.Rounds[S.round] and Config.Rounds[S.round].bonus or false,
    })
end

RegisterNetEvent('storage:snapshot', function(snap)
    local prev = S
    S = snap
    if snap.state == 'travel' then startTravelBlips() else clearTravelBlips() end
    updateFarBlip()
    updateLotBlip()
    if prev and snap.phase == 'bidding' and prev.bid and snap.bid.amount ~= prev.bid.amount then
        PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    end
    if prev and prev.phase == 'bidding' and snap.phase == 'looting' then
        PlaySoundFrontend(-1, 'PURCHASE', 'HUD_LIQUOR_STORE_SOUNDSET', true)
    end
    if lobbyOpen and snap.state ~= 'lobby' and snap.state ~= 'idle' then
        lobbyOpen = false
        closeFocus()
        ui('close')
    end
    sendState()
end)

RegisterNetEvent('storage:me', function(me)
    Me = me
    ui('me', me)
end)

RegisterNetEvent('storage:toast', function(msg, t) toast(msg, t) end)

RegisterNetEvent('storage:lobbyUpdate', function(info) ui('lobbyUpdate', { info = info }) end)

RegisterNetEvent('storage:joinable', function(on) setLobbyBlip(on) end)

RegisterNetEvent('storage:results', function(res)
    resultsOpen = true
    if inspecting then stopInspect() end
    openFocus()
    ui('results', res)
end)

RegisterNetEvent('storage:reset', function()
    S = nil
    Me = { cash = 0, spent = 0, items = 0, best = 0 }
    lobbyOpen = false
    if inspecting then stopInspect() end
    if not resultsOpen then closeFocus() end
    clearLot()
    clearNpc('auctioneer'); clearNpc('buyer'); clearNpc('far')
    clearTravelBlips()
    updateFarBlip()
    updateLotBlip()
    if travelVeh and DoesEntityExist(travelVeh) and GetPedInVehicleSeat(travelVeh, -1) ~= PlayerPedId() then
        SetEntityAsMissionEntity(travelVeh, true, true)
        DeleteVehicle(travelVeh)
    end
    travelVeh = nil
    ui('reset')
end)

-- ===== Bidding keys: 1-4 =====
CreateThread(function()
    local keys = { 157, 158, 160, 164 }
    local last = 0
    while true do
        if S and S.state == 'round' and S.phase == 'bidding' and not focused and not inspecting then
            for i, k in ipairs(keys) do
                DisableControlAction(0, k, true)
                if IsDisabledControlJustPressed(0, k) and GetGameTimer() - last > 250 then
                    last = GetGameTimer()
                    CreateThread(function()
                        local ok, msg = lib.callback.await('storage:bid', false, i)
                        if not ok and msg then toast(msg, 'error') end
                    end)
                end
            end
            Wait(0)
        else
            Wait(250)
        end
    end
end)

-- ===== Lobby ped, lobby blip, joinable state =====
CreateThread(function()
    local L = Config.Lobby
    spawnNpc('lobby', L.ped, L.coords.x, L.coords.y, L.coords.z - 1.0, L.coords.w, nil, 'СКЛАДСКОЙ АУКЦИОН')
    Wait(1500)
    setLobbyBlip(lib.callback.await('storage:isJoinable', false) and true or false)
end)

-- ===== Slow loop: props, NPCs, auto inspect, distance =====
CreateThread(function()
    while true do
        Wait(500)
        ensureLot()
        manageNpcs()

        if S and S.state == 'round' and S.phase == 'looting' and S.lotOwner == myId and S.lot then
            if not inspecting and not autoInspected[S.lot.id] and lotId == S.lot.id and next(LotProps) then
                autoInspected[S.lot.id] = true
                startInspect()
            end
        elseif inspecting then
            stopInspect()
        end

        local loc = curLoc()
        if S and S.state == 'travel' and loc then
            ui('dist', { m = math.floor(#(GetEntityCoords(cache.ped) - loc.coords)) })
            if S.reported ~= S.round and #(GetEntityCoords(cache.ped) - loc.coords) < Config.ArrivalRadius then
                S.reported = S.round
                TriggerServerEvent('storage:arrived')
            end
        end
    end
end)


-- Физически не даём зайти внутрь нарисованного лота или встать на его крышу.
CreateThread(function()
    while true do
        Wait(120)
        local loc = curLoc()
        local lot = S and S.state == 'round' and S.phase ~= 'final' and S.phase ~= 'between' and S.lot or nil
        if Config.BlockLotEntry and loc and lot and not inspecting then
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            if #(pos - loc.coords) < 35.0 then
                local dx, dy = pos.x - loc.coords.x, pos.y - loc.coords.y
                local h = math.rad(loc.heading)
                local lx = dx * math.cos(h) + dy * math.sin(h)
                local ly = -dx * math.sin(h) + dy * math.cos(h)
                local T = Config.LotTypes[lot.kind]
                local gz = shellGz or groundZ(loc.coords.x, loc.coords.y, loc.coords.z)
                local zInside = pos.z >= gz - 0.6 and pos.z <= gz + T.height + 1.4
                local footprint = math.abs(lx) <= (T.width / 2 + 0.1) and ly >= -0.15 and ly <= (T.depth + 0.1)
                if zInside and footprint then
                    local out = LocalToWorld(loc, 0.0, -8.0)
                    local entity = IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) or ped
                    SetEntityCoordsNoOffset(entity, out.x, out.y, groundZ(out.x, out.y, out.z) + 0.25, false, false, false)
                    SetEntityHeading(entity, loc.heading + 180.0)
                    if entity ~= ped then SetPedCoordsKeepVehicle(ped, out.x, out.y, out.z + 0.25) end
                end
            end
        end
    end
end)

-- ===== Interaction (E) =====
CreateThread(function()
    while true do
        local sleep = 500
        if not focused and not inspecting then
            if S and S.state == 'round' and S.phase == 'final' then
                sleep = 0
                helpText('Нажмите ~INPUT_DETONATE~ (G), чтобы пропустить этап продажи')
                if IsControlJustReleased(0, Config.SkipSaleControl) then
                    CreateThread(function()
                        local ok, msg = lib.callback.await('storage:skipSale', false)
                        if ok then toast('Вы пропустили этап продажи.', 'success') elseif msg then toast(msg, 'error') end
                    end)
                end
            end
            local ppos = GetEntityCoords(cache.ped)
            local target, text
            if #(ppos - Config.Lobby.coords.xyz) < 2.5 then
                target, text = 'lobby', 'Нажмите ~INPUT_CONTEXT~ чтобы открыть Storage Wars'
            end
            if Npcs.buyer and DoesEntityExist(Npcs.buyer) and #(ppos - GetEntityCoords(Npcs.buyer)) < 2.8 then
                target, text = 'local', 'Нажмите ~INPUT_CONTEXT~ чтобы продать вещи'
            end
            if Npcs.far and DoesEntityExist(Npcs.far) and #(ppos - GetEntityCoords(Npcs.far)) < 2.8 then
                target, text = 'far', ('Нажмите ~INPUT_CONTEXT~ чтобы продать коллекционеру (x%.1f)'):format(Config.FarBuyerMult)
            end
            local loc = curLoc()
            if not target and S and S.phase == 'looting' and S.lotOwner == myId and loc and #(ppos - loc.coords) < 60.0 then
                target, text = 'inspect', 'Нажмите ~INPUT_CONTEXT~ чтобы осмотреть лот'
            end
            if target then
                sleep = 0
                helpText(text)
                if IsControlJustReleased(0, 38) then
                    CreateThread(function()
                        if target == 'lobby' then openLobby()
                        elseif target == 'inspect' then startInspect()
                        else openSell(target) end
                    end)
                end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if inspecting then
        RenderScriptCams(false, false, 0, true, true)
        FreezeEntityPosition(PlayerPedId(), false)
    end
    SetNuiFocus(false, false)
    clearLot()
    for k in pairs(Npcs) do clearNpc(k) end
    clearTravelBlips()
    if blips.lobby then RemoveBlip(blips.lobby) end
    if blips.far then RemoveBlip(blips.far) end
    if blips.lot then RemoveBlip(blips.lot) end
end)
