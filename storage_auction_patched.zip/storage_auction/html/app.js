const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'storage_auction';
const money = n => '$' + Math.floor(n || 0).toLocaleString('ru-RU');
const KIND = { container: 'КОНТЕЙНЕР', container_blue: 'СИНИЙ КОНТЕЙНЕР', container_rust: 'РЖАВЫЙ КОНТЕЙНЕР', container_long: 'ДЛИННЫЙ КОНТЕЙНЕР', container_small: 'КОРОТКИЙ КОНТЕЙНЕР', garage: 'БОНУСНЫЙ ГАРАЖ' };
const PHASE = { travel: 'В ПУТИ', preview: 'ОСМОТР', bidding: 'ТОРГИ', looting: 'ПОИСК ДОБЫЧИ', between: 'СЛЕДУЮЩИЙ ЛОТ', final: 'ФИНАЛЬНАЯ ПРОДАЖА' };

function post(name, data) {
  return fetch(`https://${RES}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {})
  }).then(r => r.json()).catch(() => ({}));
}
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let st = {}, me = {}, endAt = 0, barTotal = 1, last = {}, dist = null, lobbyInfo = null, sellCtx = null, lastKind = null;
let found = [], foundTotal = 0;

// ---------- toasts / banner ----------
function toast(msg, type) {
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 4200);
  setTimeout(() => el.remove(), 4700);
}
let bannerTimer;
function banner(title, sub) {
  const b = $('#banner');
  b.classList.remove('hidden');
  b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  $('#b-title').textContent = title;
  $('#b-sub').textContent = sub || '';
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), 3200);
}

// ---------- state / HUD / auction ----------
function onState(d) {
  const prev = st;
  st = d;
  if (d.kind) lastKind = d.kind;
  endAt = Date.now() + (d.remaining || 0) * 1000;

  const active = d.state === 'travel' || d.state === 'round';
  $('#hud').classList.toggle('hidden', !active);
  if (!active) { $('#auction').classList.add('hidden'); return; }

  $('#h-round').textContent = `${d.bonusRound ? 'БОНУС · ' : ''}РАУНД ${d.round} / ${d.rounds}`;
  $('#h-phase').textContent = d.state === 'travel' ? PHASE.travel : (PHASE[d.phase] || '');

  // timer bar reference
  const amountChanged = !prev.bid || !d.bid || prev.bid.amount !== d.bid.amount;
  if (d.phase !== prev.phase || d.state !== prev.state || amountChanged) barTotal = Math.max(1, d.remaining || 1);

  // banners
  if (d.state === 'travel' && (prev.state !== 'travel' || prev.round !== d.round)) {
    banner(d.bonusRound ? `БОНУСНЫЙ РАУНД ${d.round}` : `РАУНД ${d.round}`, `Езжайте на площадку: ${d.locName || 'место аукциона'}`);
  } else if (d.state === 'round') {
    if (d.phase === 'preview' && (prev.phase !== 'preview' || prev.lotIdx !== d.lotIdx)) banner(`ЛОТ ${d.lotIdx} / ${d.lotCount}`, `${KIND[d.kind] || ''} — внимательно осмотрите содержимое`);
    else if (d.phase === 'bidding' && prev.phase !== 'bidding') banner('ТОРГИ ОТКРЫТЫ', 'Нажимайте 1–4, чтобы повысить ставку');
    else if (d.phase === 'looting' && prev.phase !== 'looting') banner(`ЛОТ У ИГРОКА: ${d.owner}`, money(d.bid.amount));
    else if (d.phase === 'between' && prev.phase === 'bidding') banner('СТАВОК НЕТ', 'Лот снят с торгов');
    else if (d.phase === 'final' && prev.phase !== 'final') banner('ФИНАЛЬНАЯ ПРОДАЖА', 'Продайте находки или нажмите G, чтобы пропустить этап');
  }

  renderSub();
  renderAuction(amountChanged);
}

function renderSub() {
  const d = st;
  if (d.state === 'travel') {
    $('#h-sub').textContent = `Езжайте: ${d.locName || '?'}` + (dist != null ? `  -  ${dist >= 1000 ? (dist / 1000).toFixed(1) + ' км' : dist + ' м'}` : '');
  } else if (d.phase === 'final') {
    $('#h-sub').textContent = 'Продайте вещи покупателю или нажмите G для пропуска';
  } else {
    $('#h-sub').textContent = `Лот ${d.lotIdx} / ${d.lotCount}`;
  }
}

function renderAuction(bump) {
  const d = st, a = $('#auction');
  const show = d.state === 'round' && (d.phase === 'preview' || d.phase === 'bidding' || d.phase === 'looting');
  a.classList.toggle('hidden', !show);
  if (!show) return;

  $('#a-lot').textContent = `ЛОТ ${d.lotIdx} / ${d.lotCount}`;
  $('#a-kind').textContent = KIND[d.kind || lastKind] || '';
  const amt = $('#a-amount'), who = $('#a-who'), keys = $('#a-keys'), hint = $('#a-hint');
  who.classList.remove('me');
  keys.innerHTML = '';

  if (d.phase === 'preview') {
    $('#a-label').textContent = 'СТАРТОВАЯ СТАВКА';
    amt.textContent = money(d.startPrice);
    who.textContent = 'Торги начнутся после окончания таймера';
    hint.textContent = 'Осмотрите лот и оцените, стоит ли он своих денег.';
  } else if (d.phase === 'bidding') {
    const has = !!(d.bid && d.bid.bidder);
    $('#a-label').textContent = has ? 'ТЕКУЩАЯ СТАВКА' : 'СТАРТОВАЯ СТАВКА';
    amt.textContent = money(d.bid.amount);
    if (has) { who.textContent = d.lead ? 'Вы лидируете в торгах!' : `Лидер торгов: ${d.bid.bidderName}`; if (d.lead) who.classList.add('me'); }
    else who.textContent = 'Пока нет ставок';
    (d.steps || []).forEach((s, i) => { const k = document.createElement('span'); k.innerHTML = `<kbd>${i + 1}</kbd> +${money(s)}`; keys.appendChild(k); });
    hint.textContent = 'Каждая новая ставка обновляет таймер.';
  } else {
    $('#a-label').textContent = 'ПРОДАНО';
    amt.textContent = money(d.bid.amount);
    who.textContent = d.mine ? 'Этот лот ваш!' : `Победитель: ${d.owner}`;
    if (d.mine) who.classList.add('me');
    hint.textContent = d.mine ? 'Не спешите: загляните за крупные предметы.' : 'Победитель осматривает лот.';
  }
  if (bump) { amt.classList.remove('bump'); void amt.offsetWidth; amt.classList.add('bump'); }
}

function onMe(d) {
  me = d;
  $('#h-cash').textContent = money(d.cash);
  $('#h-spent').textContent = money(d.spent);
  $('#h-items').textContent = d.items;
}

function onDist(d) { dist = d.m; renderSub(); }

setInterval(() => {
  if ($('#hud').classList.contains('hidden')) return;
  const ms = Math.max(0, endAt - Date.now());
  const s = Math.ceil(ms / 1000);
  $('#h-timer').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const bar = $('#a-bar');
  const pct = Math.min(100, (ms / (barTotal * 1000)) * 100);
  bar.style.width = pct + '%';
  bar.classList.toggle('low', st.phase === 'bidding' && s <= 3);
}, 200);

// ---------- lobby ----------
function onLobby(d) {
  lobbyInfo = d.info;
  $('#lobby').classList.remove('hidden');
  setTab('match');
  renderLobby();
}
function onLobbyUpdate(d) { lobbyInfo = d.info; if (!$('#lobby').classList.contains('hidden')) renderLobby(); }

function setTab(t) {
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
  $('#tab-match').classList.toggle('hidden', t !== 'match');
  $('#tab-board').classList.toggle('hidden', t !== 'board');
  if (t === 'board') {
    $('#l-board').innerHTML = '<div class="muted">Загрузка...</div>';
    post('leaderboard').then(r => {
      const rows = r.rows || [];
      $('#l-board').innerHTML = rows.length ? rows.map((x, i) =>
        `<div class="row"><span><b>${i + 1}.</b> ${esc(x.name)}</span><span class="muted small">Победы: ${(+x.best_wins || 0) + (+x.spender_wins || 0)} · Лучшая находка: ${money(+x.best_ever || 0)} · Матчи: ${+x.matches || 0}</span></div>`
      ).join('') : '<div class="muted">Сыгранных матчей пока нет.</div>';
    });
  }
}
$$('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));

function renderLobby() {
  const i = lobbyInfo; if (!i) return;
  const names = { idle: 'Матч ещё не создан — присоединяйтесь первым', lobby: 'Лобби открыто', travel: 'Матч уже идёт', round: 'Матч уже идёт', ended: 'Матч только что завершён' };
  $('#l-status').textContent = names[i.state] || 'Лобби';
  $('#l-count').textContent = `${i.count} / ${i.max}`;
  $('#l-players').innerHTML = i.players.length
    ? i.players.map(p => `<div class="row"><span>${esc(p.name)}${p.host ? '<span class="badge">СОЗДАТЕЛЬ</span>' : ''}</span></div>`).join('')
    : '<div class="muted">Пока никого нет.</div>';

  let html = '';
  for (let r = 1; r <= i.rounds; r++) {
    const v = i.containers[r - 1];
    html += `<div class="row"><span>Раунд ${r}</span><div class="step">` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="-1">-</button>` : '') +
      `<span>${v}</span>` +
      (i.isHost && i.state === 'lobby' ? `<button data-r="${r}" data-d="1">+</button>` : '') +
      `</div></div>`;
  }
  $('#l-settings').innerHTML = html;
  $$('#l-settings button').forEach(b => b.addEventListener('click', () => {
    const r = +b.dataset.r, d = +b.dataset.d;
    const v = Math.max(1, Math.min(i.maxContainers, i.containers[r - 1] + d));
    post('setContainers', { round: r, value: v });
  }));
  $('#l-info').textContent = `У каждого игрока ${money(i.startMoney)}. ` + (i.fee > 0 ? `Вход: ${money(i.fee)}. ` : '') +
    (i.isHost ? 'Вы создатель лобби: настройте количество лотов и запустите матч.' : 'Настраивать матч и запускать его может только создатель лобби.');

  const act = $('#l-actions');
  act.innerHTML = '';
  const add = (txt, cls, fn, dis) => { const b = document.createElement('button'); b.className = 'btn ' + cls; b.textContent = txt; b.disabled = !!dis; b.onclick = fn; act.appendChild(b); };
  add('Закрыть', 'ghost', () => post('close'));
  if (i.joined && (i.state === 'lobby')) add('Выйти', 'danger', () => post('lobbyLeave'));
  if (i.joined && i.state !== 'lobby') add('Покинуть матч', 'danger', () => post('lobbyLeave'));
  if (!i.joined && (i.state === 'idle' || i.state === 'lobby')) add('Присоединиться', '', () => post('lobbyJoin'));
  if (i.joined && i.isHost && i.state === 'lobby') add(`Начать матч${i.count < i.min ? ` (нужно ${i.min})` : ''}`, '', () => post('lobbyStart'), i.count < i.min);
}

// ---------- sell ----------
function onSell(d) { sellCtx = d; $('#sell').classList.remove('hidden'); $('#s-skip').classList.toggle('hidden', !d.canSkip); renderSell(); }
function renderSell() {
  const { which, inv } = sellCtx;
  if (!inv) { post('close'); return; }
  $('#s-title').textContent = inv.title;
  $('#s-mult').textContent = 'x' + Number(inv.mult).toFixed(2);
  const total = inv.items.reduce((a, b) => a + b.offer, 0);
  $('#s-list').innerHTML = inv.items.length ? inv.items.map(it =>
    `<div class="row"><span>${esc(it.label)}</span><span><b>${money(it.offer)}</b> &nbsp;<button class="sellbtn" data-uid="${it.uid}">Продать</button></span></div>`
  ).join('') : '<div class="muted">У вас нет вещей для продажи.</div>';
  $('#s-all').textContent = `Продать всё — ${money(total)}`;
  $('#s-all').disabled = !inv.items.length;
  $$('#s-list .sellbtn').forEach(b => b.addEventListener('click', () =>
    post('sell', { which, uid: +b.dataset.uid }).then(r => { sellCtx.inv = r.inv; if (!r.inv) { closeModals(); return; } renderSell(); })));
}
$('#s-all').addEventListener('click', () => post('sellAll', { which: sellCtx.which }).then(r => { sellCtx.inv = r.inv; if (!r.inv) { closeModals(); return; } renderSell(); }));
$('#s-skip').addEventListener('click', () => post('skipSale').then(r => { if (r && r.ok) closeModals(); }));

// ---------- inspect ----------
function onInspect(d) {
  $('#inspect').classList.toggle('hidden', !d.on);
  if (d.on) { found = []; foundTotal = 0; renderFound(); }
}
function renderFound() {
  $('#i-found').innerHTML = found.length ? found.map(f => `<div class="row found"><span>${esc(f.label)}</span><b>${money(f.value)}</b></div>`).join('')
    : '<div class="muted small">Пока ничего.</div>';
  $('#i-total').textContent = money(foundTotal);
}
const stage = $('#stage'), tip = $('#tip');
let hoverBusy = false;
stage.addEventListener('mousemove', e => {
  tip.style.left = e.clientX + 'px'; tip.style.top = e.clientY + 'px';
  if (hoverBusy) return;
  hoverBusy = true;
  post('hover', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    hoverBusy = false;
    if (r && r.label) { tip.textContent = r.label; tip.classList.remove('hidden'); } else tip.classList.add('hidden');
  });
});
stage.addEventListener('click', e => {
  post('pick', { x: e.clientX / innerWidth, y: e.clientY / innerHeight }).then(r => {
    if (!r || !r.ok) return;
    found.unshift({ label: r.label, value: r.value }); foundTotal += r.value; renderFound();
    toast(`${r.label} — ${money(r.value)}`, 'success');
    if (r.revealed > 0) toast('За этим предметом что-то скрывалось!', 'success');
    tip.classList.add('hidden');
  });
});
stage.addEventListener('wheel', e => post('fov', { d: e.deltaY > 0 ? 1 : -1 }));
$('#i-done').addEventListener('click', () => post('done'));

// ---------- results ----------
function onResults(d) {
  $('#results').classList.remove('hidden');
  let aw = '';
  aw += d.bestItem ? `<div class="award"><label>ЛУЧШАЯ НАХОДКА</label><b>${esc(d.bestItem.name)}</b><span>${esc(d.bestItem.label)} продан за ${money(d.bestItem.value)}</span></div>`
    : `<div class="award"><label>ЛУЧШАЯ НАХОДКА</label><b>Нет победителя</b><span>Ничего не продано</span></div>`;
  aw += d.bigSpender ? `<div class="award"><label>БОЛЬШЕ ВСЕХ ПОТРАТИЛ</label><b>${esc(d.bigSpender.name)}</b><span>Потрачено на лоты: ${money(d.bigSpender.spent)}</span></div>`
    : `<div class="award"><label>БОЛЬШЕ ВСЕХ ПОТРАТИЛ</label><b>Нет победителя</b><span>Ничего не куплено</span></div>`;
  $('#r-awards').innerHTML = aw;
  $('#r-table').innerHTML = d.standings.map((s, i) =>
    `<div class="row"><span><b>${i + 1}.</b> ${esc(s.name)}</span><span class="muted small">Деньги <b>${money(s.cash)}</b> · Потрачено ${money(s.spent)} · Лучшая продажа ${money(s.best)}</span></div>`).join('');
  $('#r-note').textContent = `Непроданные вещи автоматически оценены в ${d.liquidation}% от стоимости.`;
}

// ---------- generic ----------
function closeModals() { ['#lobby', '#sell', '#results'].forEach(s => $(s).classList.add('hidden')); }
function onReset() {
  st = {}; dist = null;
  ['#hud', '#auction', '#inspect', '#banner', '#lobby', '#sell', '#results'].forEach(s => $(s).classList.add('hidden'));
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => post('close')));

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { post('close'); return; }
  if ($('#inspect').classList.contains('hidden')) return;
  const k = e.key.toLowerCase();
  if (k === 'w') post('cam', { dx: 0, dy: 1 });
  if (k === 's') post('cam', { dx: 0, dy: -1 });
  if (k === 'a') post('cam', { dx: -1, dy: 0 });
  if (k === 'd') post('cam', { dx: 1, dy: 0 });
});

const handlers = { state: onState, me: onMe, toast: d => toast(d.msg, d.type), dist: onDist, lobby: onLobby, lobbyUpdate: onLobbyUpdate,
  sell: onSell, inspect: onInspect, results: onResults, reset: onReset, close: closeModals };
window.addEventListener('message', e => { const m = e.data; if (m && handlers[m.action]) handlers[m.action](m.data || {}); });
