-- Match history (same table as before, safe to run again).
CREATE TABLE IF NOT EXISTS `storage_results` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `license` VARCHAR(80) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `spent` INT NOT NULL DEFAULT 0,
  `final_cash` INT NOT NULL DEFAULT 0,
  `sold_total` INT NOT NULL DEFAULT 0,
  `best_item_label` VARCHAR(80) DEFAULT NULL,
  `best_item_value` INT NOT NULL DEFAULT 0,
  `won_best_item` TINYINT(1) NOT NULL DEFAULT 0,
  `won_big_spender` TINYINT(1) NOT NULL DEFAULT 0,
  `played_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `license` (`license`)
);
