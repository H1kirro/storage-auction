fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'storage_auction'
description 'Storage Wars: multiplayer container auction match'
version '3.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'shared.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

client_script 'client.lua'

dependencies {
    'ox_lib',
    'oxmysql'
}
